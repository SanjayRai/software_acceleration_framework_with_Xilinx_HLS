/********************************************************************
*Copyright (C) 2014 � 2015 Xilinx, Inc.  All rights reserved.
*
*Permission is hereby granted, free of charge, to any person obtaining
*a copy of this software and associated documentation files (the
*"Software"), to deal in the Software without restriction, including
*without limitation the rights to use, copy, modify, merge, publish,
*distribute, sublicense, and/or sell copies of the Software, and to
*permit persons to whom the Software is furnished to do so, subject to
*the following conditions:
*
*The above copyright notice and this permission notice shall be 
*included in all copies or substantial portions of the Software.
*
*Use of the Software is limited solely to applications: (a) running 
*on a Xilinx device, or (b) that interact with a Xilinx device 
*through a bus or interconnect.  
*
*THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*NONINFRINGEMENT. IN NO EVENT SHALL XILINX BE LIABLE FOR ANY CLAIM, 
*DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
*OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
*OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*Except as contained in this notice, the name of the Xilinx shall
*not be used in advertising or otherwise to promote the sale, use or
*other dealings in this Software without prior written authorization
*from Xilinx.
*********************************************************************/

#include <evntrace.h> // For TRACE_LEVEL definitions

//
// If software tracing is defined in the sources file..
// WPP_DEFINE_CONTROL_GUID specifies the GUID used for this driver.
// WPP_DEFINE_BIT allows setting debug bit masks to selectively print.
// The names defined in the WPP_DEFINE_BIT call define the actual names
// that are used to control the level of tracing for the control guid
// specified.
//
// Name of the logger is MCAP and the guid is
//   {03B9D9BB-72EB-4a5b-89D8-AB4A9BC7CD74}
//   (0x3b9d9bb, 0x72eb, 0x4a5b, { 0x89, 0xd8, 0xab, 0x4a, 0x9b, 0xc7, 0xcd, 0x74);
//

#define WPP_CHECK_FOR_NULL_STRING  //to prevent exceptions due to NULL strings

#define WPP_CONTROL_GUIDS \
    WPP_DEFINE_CONTROL_GUID(MCAPTraceGuid, (03B9D9BB, 72EB, 4a5b,89D8, AB4A9BC7CD74),\
        WPP_DEFINE_BIT(DBG_INIT)             /* bit  0 = 0x00000001 */ \
        WPP_DEFINE_BIT(DBG_PNP)              /* bit  1 = 0x00000002 */ \
        WPP_DEFINE_BIT(DBG_POWER)            /* bit  2 = 0x00000004 */ \
        WPP_DEFINE_BIT(DBG_WMI)              /* bit  3 = 0x00000008 */ \
        WPP_DEFINE_BIT(DBG_CREATE_CLOSE)     /* bit  4 = 0x00000010 */ \
        WPP_DEFINE_BIT(DBG_IOCTLS)           /* bit  5 = 0x00000020 */ \
        WPP_DEFINE_BIT(DBG_WRITE)            /* bit  6 = 0x00000040 */ \
        WPP_DEFINE_BIT(DBG_READ)             /* bit  7 = 0x00000080 */ \
        WPP_DEFINE_BIT(DBG_DPC)              /* bit  8 = 0x00000100 */ \
        WPP_DEFINE_BIT(DBG_INTERRUPT)        /* bit  9 = 0x00000200 */ \
        WPP_DEFINE_BIT(DBG_LOCKS)            /* bit 10 = 0x00000400 */ \
        WPP_DEFINE_BIT(DBG_QUEUEING)         /* bit 11 = 0x00000800 */ \
        WPP_DEFINE_BIT(DBG_HW_ACCESS)        /* bit 12 = 0x00001000 */ \
        /* You can have up to 32 defines. If you want more than that,\
            you have to provide another trace control GUID */\
        )


#define WPP_LEVEL_FLAGS_LOGGER(lvl,flags) WPP_LEVEL_LOGGER(flags)
#define WPP_LEVEL_FLAGS_ENABLED(lvl, flags) (WPP_LEVEL_ENABLED(flags) && WPP_CONTROL(WPP_BIT_ ## flags).Level  >= lvl)

#if 0
// To use Debug Print open Regedit on the machine running the drivers.
//  Goto HKLM\SYSTEM\CurrentControlSet\Control\Session Manager
//    if the "Debug Print Filter" key does not exist create it.
//    In the HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Debug Print Filter 
//       section add a 32 bit DWORD value called "IHVDRIVER" or "IHVNETWORK" for NDIS
//       drivers.  Set the value to:
//			1 for ERRORs only,
//			2 for ERRORs and WARNINGs,
//			3 for ERRORs, WARNINGs and Info,
//			4 to recieve all messages
//
extern unsigned long DbgComponentID;

#define	DEBUG_VERBOSE	DPFLTR_INFO_LEVEL + 1
#define	DEBUG_INFO		DPFLTR_INFO_LEVEL
#define	DEBUG_TRACE		DPFLTR_TRACE_LEVEL
#define	DEBUG_WARN		DPFLTR_WARNING_LEVEL
#define	DEBUG_ERROR		DPFLTR_ERROR_LEVEL
#define	DEBUG_ALWAYS	DPFLTR_ERROR_LEVEL

#define DEBUGP(level, ...) \
{\
	KdPrintEx((DbgComponentID, level, "MCAP.SYS:")); \
    KdPrintEx((DbgComponentID, level, __VA_ARGS__)); \
	KdPrintEx((DbgComponentID, level, "\n")); \
} 
#endif