/********************************************************************
*Copyright (C) 2014 � 2015 Xilinx, Inc.  All rights reserved.
*
*Permission is hereby granted, free of charge, to any person obtaining
*a copy of this software and associated documentation files (the
*"Software"), to deal in the Software without restriction, including
*without limitation the rights to use, copy, modify, merge, publish,
*distribute, sublicense, and/or sell copies of the Software, and to
*permit persons to whom the Software is furnished to do so, subject to
*the following conditions:
*
*The above copyright notice and this permission notice shall be 
*included in all copies or substantial portions of the Software.
*
*Use of the Software is limited solely to applications: (a) running 
*on a Xilinx device, or (b) that interact with a Xilinx device 
*through a bus or interconnect.  
*
*THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*NONINFRINGEMENT. IN NO EVENT SHALL XILINX BE LIABLE FOR ANY CLAIM, 
*DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
*OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
*OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*Except as contained in this notice, the name of the Xilinx shall
*not be used in advertising or otherwise to promote the sale, use or
*other dealings in this Software without prior written authorization
*from Xilinx.
*********************************************************************/

#include "precomp.h"

#include "mcapInit.tmh"

#ifdef ALLOC_PRAGMA
#pragma alloc_text (PAGE, MCAPInitializeDeviceExtension)
#pragma alloc_text (PAGE, MCAPPrepareHardware)
#endif

NTSTATUS
MCAPInitializeDeviceExtension(
    IN PDEVICE_EXTENSION DevExt
    )
/*++
Routine Description:

    This routine initializes the device extension.
	This includes the Locks, Queues, Interrupts, Interfaces.

Arguments:

    DevExt     Pointer to the Device Extension

Return Value:

     NTSTATUS

--*/
{
    NTSTATUS    status;
    WDF_IO_QUEUE_CONFIG  queueConfig;
    WDF_OBJECT_ATTRIBUTES attributes;
	ULONG i = 0;

	ULONG Next_Cap = PCIE_EXTENDED_CAPABILITY_START_REGISTER;
	ULONG DataRead = 0x00;
	ULONG VSEC_DataRead = 0x00;

	PAGED_CODE();

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP, "MCAPInitializeDeviceExtension -->");

    //
    // This a lock to synchonize access to the device.
    //
    WDF_OBJECT_ATTRIBUTES_INIT(&attributes);
	attributes.ParentObject = DevExt->Device;
	status = WdfSpinLockCreate(&attributes, &DevExt->RegisterLock);
    if(!NT_SUCCESS(status))
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
                    "WdfSpinLockCreate failed: %!STATUS!", status);
        return status;
    }

    //
    // This a lock to synchonize operations on the device.
    //
    WDF_OBJECT_ATTRIBUTES_INIT(&attributes);
	attributes.ParentObject = DevExt->Device;
	status = WdfSpinLockCreate(&attributes, &DevExt->ExOperationLock);
    if(!NT_SUCCESS(status))
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
                    "WdfSpinLockCreate failed: %!STATUS!", status);
        return status;
    }

	// Initialize the Reset Flag
	DevExt->ResetInProgress = FALSE;

	//Initialize saved ControlReg
	DevExt->SavedCtrlReg.regval = INVALID_VALUE; 

	//
    // Get the BUS_INTERFACE_STANDARD for our device so that we can
    // read & write to PCI config space.
    //
    status = WdfFdoQueryForInterface(DevExt->Device,
                                   &GUID_BUS_INTERFACE_STANDARD,
                                   (PINTERFACE) &DevExt->BusInterface,
                                   sizeof(BUS_INTERFACE_STANDARD),
                                   1, // Version
                                   NULL); //InterfaceSpecificData
    if (!NT_SUCCESS (status))
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
                    "WdfFdoQueryForInterface failed: %!STATUS!", status);
        return status;
    }

	// Read PCI Config Space Information
	ReadMCAP_PCIRegisters(
					DevExt,
					FIELD_OFFSET(PCI_COMMON_CONFIG, VendorID), // First Register
					&DevExt->MCAPPCIEConfigSpace,
					sizeof(PCI_COMMON_CONFIG) // Complete Config Space
					);

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP,
		"ReadMCAP_PCIRegisters VID:0x%x, PID:0x%x", 
		DevExt->MCAPPCIEConfigSpace.VendorID,
		DevExt->MCAPPCIEConfigSpace.DeviceID);
/*
	DevExt->MCAP_Enabled = 0;
	DevExt->MCAP_Register_Base = 0;

	Next_Cap = PCIE_EXTENDED_CAPABILITY_START_REGISTER;
	// Check if MCAP is Enabled
	while(Next_Cap)
	{
		// Read First 4 Bytes
		// Read the PCI Entended Capability Register
		ReadMCAP_PCIRegisters(
						DevExt,
						Next_Cap, // First Register
						&DataRead,
						sizeof(ULONG)
						);


		TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP, "Data:0x%x read at Cap_Offset: 0x%x ", DataRead, Next_Cap);

		if(PCIE_EXTENDED_CAPABILITY_ID == (DataRead & 0xFFFF))
		{
			// Read Next 4 Bytes
			// Read the VSEC Register
			ReadMCAP_PCIRegisters(
							DevExt,
							Next_Cap + MCAP_REGISTER_SIZE, // Next Register
							&VSEC_DataRead,
							sizeof(ULONG)
							);

			if (VSEC_ID == (VSEC_DataRead & 0xFFFF))
			{
				DevExt->MCAP_Enabled = 1;
				DevExt->MCAP_Register_Base = Next_Cap;
				break;
			}
		}

		// Next Capability Offset
		Next_Cap = DataRead >> 20;
	}

	if(DevExt->MCAP_Enabled)
	{
		// MCAP Enabled
		// Next_Cap is the Starting Offset
		TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP,
			"MCAP_Enabled:%d, Enabled at Offset: 0x%x ", 
			DevExt->MCAP_Enabled, DevExt->MCAP_Register_Base);
	}
	else
	{
		// MCAP Disabled
		TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
			"MCAP_Enabled:%d, Disabled ", 
			DevExt->MCAP_Enabled);

		status = STATUS_UNSUCCESSFUL;
		return status;
	}
*/
	DevExt->MCAP_Enabled = 1;
	DevExt->MCAP_Register_Base = 0x340;

	// Read MCAP Registers
	ReadMCAP_PCIRegisters(
					DevExt,
					DevExt->MCAP_Register_Base, // First Register
					DevExt->Regs.mcapregvals,
					MCAP_REGISTER_SIZE*MCAP_REGISTERS_COUNT
					);

	for(i = 0;i < MCAP_REGISTERS_COUNT;i++)
	{
		TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP,
			"Register:%d: 0x%x ", 
			i, DevExt->Regs.mcapregvals[i]);
	}


	//
	// This is a queue for Write Requests in sequential mode.
    //
    WDF_IO_QUEUE_CONFIG_INIT ( &queueConfig,
                              WdfIoQueueDispatchSequential);

    queueConfig.EvtIoWrite = MCAPEvtIoWrite;

    __analysis_assume(queueConfig.EvtIoStop != 0);
    status = WdfIoQueueCreate( DevExt->Device,
                               &queueConfig,
                               WDF_NO_OBJECT_ATTRIBUTES,
                               &DevExt->WriteQueue );
    __analysis_assume(queueConfig.EvtIoStop == 0);
    
    if(!NT_SUCCESS(status))
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
                    "WdfIoQueueCreate failed: %!STATUS!", status);
        return status;
    }

    //
    // Set the Write Queue
    //
    status = WdfDeviceConfigureRequestDispatching( DevExt->Device,
                                       DevExt->WriteQueue,
                                       WdfRequestTypeWrite);

    if(!NT_SUCCESS(status))
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
                    "DeviceConfigureRequestDispatching failed: %!STATUS!", status);
        return status;
    }


    //
    // This is a queue for Read Requests in sequential mode.
    //
    WDF_IO_QUEUE_CONFIG_INIT( &queueConfig,
                              WdfIoQueueDispatchSequential);

    queueConfig.EvtIoRead = MCAPEvtIoRead;

	__analysis_assume(queueConfig.EvtIoStop != 0);
    status = WdfIoQueueCreate( DevExt->Device,
                               &queueConfig,
                               WDF_NO_OBJECT_ATTRIBUTES,
                               &DevExt->ReadQueue );
    __analysis_assume(queueConfig.EvtIoStop == 0);
    
    if(!NT_SUCCESS(status))
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
                    "WdfIoQueueCreate failed: %!STATUS!", status);
        return status;
    }

    //
    // Set the Read Queue.
    //
    status = WdfDeviceConfigureRequestDispatching( DevExt->Device,
                                       DevExt->ReadQueue,
                                       WdfRequestTypeRead);

    if(!NT_SUCCESS(status))
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
                    "DeviceConfigureRequestDispatching failed: %!STATUS!", status);
        return status;
    }

    //
	// This is a queue for Write Requests in sequential mode.
    //
    WDF_IO_QUEUE_CONFIG_INIT(
        &queueConfig,
        WdfIoQueueDispatchSequential
        );

    queueConfig.EvtIoDeviceControl = MCAPEvtIoDeviceControl;

	__analysis_assume(queueConfig.EvtIoStop != 0);
    status = WdfIoQueueCreate (
                   DevExt->Device,
                   &queueConfig,
                   WDF_NO_OBJECT_ATTRIBUTES,
                   &DevExt->IoctlQueue
                   );
	__analysis_assume(queueConfig.EvtIoStop == 0);

    if(!NT_SUCCESS (status))
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP, 
			"WdfIoQueueCreate failed: %!STATUS!", status);
        return status;
    }

    //
    // Set the Ioctl Queue.
    //
    status = WdfDeviceConfigureRequestDispatching(
                    DevExt->Device,
                    DevExt->IoctlQueue,
                    WdfRequestTypeDeviceControl);

    if(!NT_SUCCESS (status))
	{
        ASSERT(NT_SUCCESS(status));
        TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP, 
			"DeviceConfigureRequestDispatching failed: %!STATUS!", status);
        return status;
    }

// NEO 
   /*
    // Create a WDFINTERRUPT object.
    //
    status = MCAPInterruptCreate(DevExt);

    if (!NT_SUCCESS(status))
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
                    "InterruptCreate failed %!STATUS!", status);
		return status;
    }
    */
// NEO

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP, "<-- MCAPInitializeDeviceExtension");
	return status;
}

VOID
MCAPHardwareReset(
    IN PDEVICE_EXTENSION DevExt
    )
/*++
Routine Description:

    This is Hardware reset function called when we want to
    put the device in a known initial state.

Arguments:

    DevExt     Pointer to Device Extension

Return Value:

--*/
{
    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP, "--> MCAPIssueFullReset");

	// Perform Full Reset
	MCAPFullReset(DevExt);
	
	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP, "<-- MCAPIssueFullReset");
}
