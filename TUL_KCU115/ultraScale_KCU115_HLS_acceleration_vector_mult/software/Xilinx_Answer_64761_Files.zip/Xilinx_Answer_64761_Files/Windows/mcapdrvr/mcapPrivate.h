/********************************************************************
*Copyright (C) 2014 � 2015 Xilinx, Inc.  All rights reserved.
*
*Permission is hereby granted, free of charge, to any person obtaining
*a copy of this software and associated documentation files (the
*"Software"), to deal in the Software without restriction, including
*without limitation the rights to use, copy, modify, merge, publish,
*distribute, sublicense, and/or sell copies of the Software, and to
*permit persons to whom the Software is furnished to do so, subject to
*the following conditions:
*
*The above copyright notice and this permission notice shall be 
*included in all copies or substantial portions of the Software.
*
*Use of the Software is limited solely to applications: (a) running 
*on a Xilinx device, or (b) that interact with a Xilinx device 
*through a bus or interconnect.  
*
*THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*NONINFRINGEMENT. IN NO EVENT SHALL XILINX BE LIABLE FOR ANY CLAIM, 
*DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
*OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
*OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*Except as contained in this notice, the name of the Xilinx shall
*not be used in advertising or otherwise to promote the sale, use or
*other dealings in this Software without prior written authorization
*from Xilinx.
*********************************************************************/


#ifndef _MCAPPVT_H_
#define _MCAPPVT_H_


#define VSEC_ID									0xFEED
#define PCIE_EXTENDED_CAPABILITY_START_REGISTER	0x100
#define PCIE_EXTENDED_CAPABILITY_ID				0x000B

#define MAX_LOOP_COUNT	5
#define MAX_EOS_RETRY_COUNT 10
#define MAX_EOS_LOOP_COUNT	100
#define MCAP_NOOP_VAL       0x2000000
#define MCAP_MAX_FIFO_DEPTH	16 // Olympus Devices
#define MCAP_MAX_READ_REGS	4

#define MCAP_CTRL_DEFAULT_VALUE 0x00000100

#define INVALID_VALUE 0xDEADDEAD

//
// The device extension for the device object
//
typedef struct _DEVICE_EXTENSION {

    WDFDEVICE               Device;

    // Following fields are specific to the hardware
    // Configuration

    // HW Resources
    MCAP_REGS               Regs;             // Registers address

    PUCHAR                  RegsBase;         // Registers base address
    ULONG                   RegsLength;       // Registers base length

    PUCHAR                  PortBase;         // Registers base address
    ULONG                   PortLength;       // Registers base length

	WDFINTERRUPT            Interrupt;     // Returned by InterruptCreate

	// MCAP Base Addess
	ULONG                   MCAP_Register_Base;

	// MCAP Status
	ULONG                   MCAP_Enabled;

    // Write
    WDFQUEUE                WriteQueue;

    // Read
    WDFQUEUE                ReadQueue;

    // Ioctl
    WDFQUEUE                IoctlQueue;

	ULONG                   HwErrCount;

    // Spin Locks for protecting HW Register Access
    WDFSPINLOCK             RegisterLock;

    // Spin Locks for Performing Exclusive Operation
    WDFSPINLOCK             ExOperationLock;

	// Reset in Progress flag
	BOOLEAN                 ResetInProgress;

	CTRL_REG                SavedCtrlReg;

	// To Read PCIe Config Space
	BUS_INTERFACE_STANDARD BusInterface;

	PCI_COMMON_CONFIG      MCAPPCIEConfigSpace;

}  DEVICE_EXTENSION, *PDEVICE_EXTENSION;

//
// This macro creates an accessor method with a specified name for 
// a driver's object-specific context space, which is the DEVICE_EXTENSION pointer. 
//
WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(DEVICE_EXTENSION, MCAPGetDeviceContext)

#pragma warning(disable:4214)  // Bit fields other than int warning
#pragma warning(disable:4201)  // nameless struct/union warning

typedef struct  _USER_WRITE_BUFFER {
    union {
        unsigned long type;
        struct {
			unsigned long FIELD_UPDATE:1;
            unsigned long MULTIPLE_BITSTREAM:1;
            unsigned long CLEAR_BITSTREAM:1;
            unsigned long FULL_BITSTREAM:1;
			unsigned long :28;
        } BIT;
    } USER_SPACE_BITSTREAM_TYPE;
	unsigned long clear_bitstream_length;
	unsigned long full_bitstream_length;
} USER_WRITE_BUFFER, *PUSER_WRITE_BUFFER;

typedef PVOID PCLEAR_BIT_STREAM;
typedef PVOID PFULL_BIT_STREAM ;

typedef enum _PARTIAL_BITSTREAM_TYPE
{
         CLEAR,    //Clear Bit Stream
         DATA      //Partial Bit Stream
}PARTIAL_BITSTREAM_TYPE;
//
// Function prototypes
//
DRIVER_INITIALIZE DriverEntry;

EVT_WDF_DRIVER_DEVICE_ADD MCAPEvtDeviceAdd;

EVT_WDF_OBJECT_CONTEXT_CLEANUP MCAPEvtDriverContextCleanup;

EVT_WDF_DEVICE_D0_ENTRY MCAPEvtDeviceD0Entry;
EVT_WDF_DEVICE_D0_EXIT MCAPEvtDeviceD0Exit;
EVT_WDF_DEVICE_PREPARE_HARDWARE MCAPEvtDevicePrepareHardware;
EVT_WDF_DEVICE_RELEASE_HARDWARE MCAPEvtDeviceReleaseHardware;

EVT_WDF_IO_QUEUE_IO_READ  MCAPEvtIoRead;
EVT_WDF_IO_QUEUE_IO_WRITE MCAPEvtIoWrite;

EVT_WDF_INTERRUPT_ISR MCAPEvtInterruptIsr;
EVT_WDF_INTERRUPT_DPC MCAPEvtInterruptDpc;
EVT_WDF_INTERRUPT_ENABLE MCAPEvtInterruptEnable;
EVT_WDF_INTERRUPT_DISABLE MCAPEvtInterruptDisable;

EVT_WDF_IO_QUEUE_IO_DEVICE_CONTROL MCAPEvtIoDeviceControl;


NTSTATUS
MCAPInitializeDeviceExtension(
    IN PDEVICE_EXTENSION DevExt
    );

NTSTATUS
MCAPPrepareHardware(
    IN PDEVICE_EXTENSION DevExt,
    IN WDFCMRESLIST     ResourcesTranslated
    );

//
// WDFINTERRUPT Support
//
NTSTATUS
MCAPInterruptCreate(
    IN PDEVICE_EXTENSION DevExt
    );

VOID
MCAPHardwareReset(
    IN PDEVICE_EXTENSION    DevExt
    );

ULONG
ReadMCAP_PCIRegisters(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG Register,
	IN  PVOID PValue,
	IN  ULONG Length
	);

ULONG
WriteMCAP_PCIRegisters(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG Register,
	IN  PVOID PValue,
	IN  ULONG Length
	);

ULONG
ReadMCAP_ReadDataRegisters(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG RegIndex
	);

ULONG
ReadMCAP_Registers(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG RegIndex
	);

VOID
WriteMCAP_Registers(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG RegIndex,
	IN  ULONG Value
	);

ULONG
ReadIOBAR_Registers(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG RegIndex
	);

VOID
WriteIOBAR_Registers(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG RegIndex,
	IN  ULONG Value
	);

ULONG
ReadMEMBAR_Registers(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG RegIndex
	);

VOID
WriteMEMBAR_Registers(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG RegIndex,
	IN  ULONG Value
	);

VOID
WriteMCAP_ControlReg(
    IN  PDEVICE_EXTENSION DevExt,
	ULONG CtrlRegVal
	);

ULONG
ReadMCAP_ControlReg(
    IN  PDEVICE_EXTENSION DevExt
	);

ULONG
ReadMCAP_StatusReg(
    IN  PDEVICE_EXTENSION DevExt
	);

NTSTATUS
MCAPReset(
    IN  PDEVICE_EXTENSION DevExt
		);

NTSTATUS
MCAPModuleReset(
    IN  PDEVICE_EXTENSION DevExt
			);

NTSTATUS
MCAPFullReset(
    IN  PDEVICE_EXTENSION DevExt
			);

NTSTATUS
ReadBitStream(
    IN  PDEVICE_EXTENSION DevExt,
	IN  PVOID Buffer,
	IN  ULONG BufferLength
			);

NTSTATUS
WriteBitStream(
    IN  PDEVICE_EXTENSION DevExt,
	IN  PVOID Buffer,
	IN  ULONG BufferLength
		);

NTSTATUS
WritePartialBitStream(
    IN  PDEVICE_EXTENSION DevExt,
	IN  PVOID Buffer,
	IN  ULONG BufferLength,
	IN  PARTIAL_BITSTREAM_TYPE  Type
		);

NTSTATUS
WriteBitStreamHT(
    IN  PDEVICE_EXTENSION DevExt,
	IN  PVOID Buffer,
	IN  ULONG BufferLength
			);

NTSTATUS WritePartialBitStreamHT(
    IN  PDEVICE_EXTENSION DevExt,
	IN  PVOID Buffer,
	IN  ULONG BufferLength,
	IN  PARTIAL_BITSTREAM_TYPE type
				   );
/*
NTSTATUS
WriteBitStreamFIFOCheck(
    IN  PDEVICE_EXTENSION DevExt,
	IN  PVOID Buffer,
	IN  ULONG BufferLength
					);
*/
#pragma warning(disable:4127) // avoid conditional expression is constant error with W4

#endif  // _MCAPPVT_H_
