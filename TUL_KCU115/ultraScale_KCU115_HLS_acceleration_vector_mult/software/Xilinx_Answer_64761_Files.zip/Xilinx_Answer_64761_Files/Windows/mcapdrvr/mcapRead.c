/********************************************************************
*Copyright (C) 2014 � 2015 Xilinx, Inc.  All rights reserved.
*
*Permission is hereby granted, free of charge, to any person obtaining
*a copy of this software and associated documentation files (the
*"Software"), to deal in the Software without restriction, including
*without limitation the rights to use, copy, modify, merge, publish,
*distribute, sublicense, and/or sell copies of the Software, and to
*permit persons to whom the Software is furnished to do so, subject to
*the following conditions:
*
*The above copyright notice and this permission notice shall be 
*included in all copies or substantial portions of the Software.
*
*Use of the Software is limited solely to applications: (a) running 
*on a Xilinx device, or (b) that interact with a Xilinx device 
*through a bus or interconnect.  
*
*THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*NONINFRINGEMENT. IN NO EVENT SHALL XILINX BE LIABLE FOR ANY CLAIM, 
*DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
*OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
*OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*Except as contained in this notice, the name of the Xilinx shall
*not be used in advertising or otherwise to promote the sale, use or
*other dealings in this Software without prior written authorization
*from Xilinx.
*********************************************************************/

#include "precomp.h"
#include "mcapRead.tmh"


//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
VOID
MCAPEvtIoRead(
    IN WDFQUEUE         Queue,
    IN WDFREQUEST       Request,
    IN size_t           Length
    )
/*++

Description:

    This Event Callback function processes a specified read request.

Arguments:

    Queue   - Read requests queue handle.
    Request - Read request handle.
    Length  - Length of the request

Return Value:

--*/
{
    NTSTATUS                NtStatus = STATUS_UNSUCCESSFUL;
    PDEVICE_EXTENSION       DevExt;
	PMDL			        Mdl;
	PVOID                   Buffer;
	ULONG                   BufferLength;

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_READ,
                "--> MCAPEvtIoRead: Request %p", Request);

    //
    // Get the DevExt from the Queue handle
    //
    DevExt = MCAPGetDeviceContext(WdfIoQueueGetDevice(Queue));

	// We do not want any other operation to interrupt our operation
	WdfSpinLockAcquire(DevExt->ExOperationLock);

    do {

		if(DevExt->ResetInProgress)
		{
			NtStatus = STATUS_UNSUCCESSFUL;
			TraceEvents(TRACE_LEVEL_ERROR, DBG_READ,
						"Device Reset in Progress %!STATUS!", NtStatus);
			goto CleanUp;
		}

		NtStatus = WdfRequestRetrieveInputWdmMdl(Request, &Mdl);
		if (!NT_SUCCESS(NtStatus))
		{
			TraceEvents(TRACE_LEVEL_ERROR, DBG_READ,
						"WdfRequestRetrieveInputWdmMdl failed: %!STATUS!", NtStatus);
			goto CleanUp;
		}

		Buffer = MmGetMdlVirtualAddress(Mdl);
		BufferLength = MmGetMdlByteCount(Mdl);

		NtStatus = ReadBitStream(DevExt, Buffer, BufferLength);
		if (!NT_SUCCESS(NtStatus))
		{
			TraceEvents(TRACE_LEVEL_ERROR, DBG_READ,
						"ReadBitStream failed: %!STATUS!", NtStatus);
			goto CleanUp;
		}
	
		//
		// Complete this Request.
		//
		WdfRequestCompleteWithInformation(Request, NtStatus, BufferLength);

		NtStatus = STATUS_SUCCESS;

    } while (0);

CleanUp:

	WdfSpinLockRelease(DevExt->ExOperationLock);

    //
    // If there are errors, then clean up and complete the Request.
    //
    if (!NT_SUCCESS(NtStatus ))
	{
		//
        WdfRequestComplete(Request, NtStatus);
    }

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_READ,
                "<-- MCAPEvtIoRead: status %!STATUS!", NtStatus);

    return;
}

NTSTATUS ReadBitStream(
    IN  PDEVICE_EXTENSION DevExt,
	IN  PVOID Buffer,
	IN  ULONG BufferLength
				   )
/*++

Routine Description:

    Called by the EvtIoRead as soon as it receives a read request.
    Read the data from the device and complete the request

Arguments:

    DevExt     - Device Extension
    Buffer     - Buffer in which the data is to be read.
    BufferLength - The size of the Buffer Passed.

Return Value:

    NTSTATUS

--*/
{
	NTSTATUS NtStatus = STATUS_UNSUCCESSFUL;

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_READ,	"ReadBitStream -->");

	if(!DevExt)
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_READ,
			"ReadBitStream: DevExt is NULL");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	if(!Buffer)
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_READ,
			"ReadBitStream: Buffer is NULL");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	if(!BufferLength)
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_READ,
			"ReadBitStream: BufferLength is 0");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	// To Do
	// To Read the Programmed BitStream from the Device

	NtStatus = STATUS_SUCCESS;
	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_READ,	"<-- ReadBitStream");
	return NtStatus;
}