/********************************************************************
*Copyright (C) 2014 � 2015 Xilinx, Inc.  All rights reserved.
*
*Permission is hereby granted, free of charge, to any person obtaining
*a copy of this software and associated documentation files (the
*"Software"), to deal in the Software without restriction, including
*without limitation the rights to use, copy, modify, merge, publish,
*distribute, sublicense, and/or sell copies of the Software, and to
*permit persons to whom the Software is furnished to do so, subject to
*the following conditions:
*
*The above copyright notice and this permission notice shall be 
*included in all copies or substantial portions of the Software.
*
*Use of the Software is limited solely to applications: (a) running 
*on a Xilinx device, or (b) that interact with a Xilinx device 
*through a bus or interconnect.  
*
*THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*NONINFRINGEMENT. IN NO EVENT SHALL XILINX BE LIABLE FOR ANY CLAIM, 
*DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
*OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
*OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*Except as contained in this notice, the name of the Xilinx shall
*not be used in advertising or otherwise to promote the sale, use or
*other dealings in this Software without prior written authorization
*from Xilinx.
*********************************************************************/
/*
Module Name:

    mcap.c

Abstract:

    This File contains all the entry point functions defined for this driver.

Environment:

    Kernel mode

--*/

#include "precomp.h"
#include "mcap.tmh"


#ifdef ALLOC_PRAGMA
#pragma alloc_text (INIT, DriverEntry)
#pragma alloc_text (PAGE, MCAPEvtDeviceAdd)
#pragma alloc_text (PAGE, MCAPEvtDevicePrepareHardware)
#pragma alloc_text (PAGE, MCAPEvtDeviceReleaseHardware)
#pragma alloc_text (PAGE, MCAPEvtDeviceD0Exit)
#pragma alloc_text (PAGE, MCAPEvtDriverContextCleanup)
#endif


NTSTATUS
DriverEntry(
    IN PDRIVER_OBJECT  DriverObject,
    IN PUNICODE_STRING RegistryPath
    )
/*++

Routine Description:

    DriverEntry is the first routine called after a driver is loaded, 
	and is responsible for initializing the driver.

Arguments:

    DriverObject - A pointer to a DRIVER_OBJECT structure. 
					This is the driver's driver object.
    RegistryPath - A pointer to a counted Unicode string specifying 
					the path to the driver's registry key.

Return Value:

    NTSTATUS

--*/
{
    NTSTATUS            status = STATUS_SUCCESS;
    WDF_DRIVER_CONFIG   config;
    WDF_OBJECT_ATTRIBUTES attributes;

	//
    // This macro registers the provider GUID and initializes the 
	// structures that are needed for software tracing.
    //
    WPP_INIT_TRACING( DriverObject, RegistryPath );

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_INIT, "DriverEntry -->");

	//
    // TraceEvents function is mapped to DoTraceMessage provided by
    // WPP by using a directive in the sources file.
    //
    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_INIT, "Xilinx MCAP PCIe Driver.");

    //
    // This function initializes a driver's WDF_DRIVER_CONFIG structure.
    //
    WDF_DRIVER_CONFIG_INIT( &config, MCAPEvtDeviceAdd );

    //
    // Register a cleanup callback so as to call WPP_CLEANUP when driver is unloaded.
    //
    WDF_OBJECT_ATTRIBUTES_INIT(&attributes);
    attributes.EvtCleanupCallback = MCAPEvtDriverContextCleanup;

    status = WdfDriverCreate( DriverObject,
                              RegistryPath,
                              &attributes,
                              &config,
                              WDF_NO_HANDLE);

    if (!NT_SUCCESS(status))
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
                    "WdfDriverCreate failed with status %!STATUS!", status);
        WPP_CLEANUP(DriverObject);
    }

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_INIT, "<-- DriverEntry");
    return status;
}


NTSTATUS
MCAPEvtDeviceAdd(
    IN WDFDRIVER        Driver,
    IN PWDFDEVICE_INIT  DeviceInit
    )
/*++

Routine Description:

    A driver's EvtDriverDeviceAdd event callback function performs
	device initialization operations when the Plug and Play (PnP)
	manager reports the existence of a device.

Arguments:

Return Value:

--*/
{
    NTSTATUS                     status = STATUS_SUCCESS;
    WDF_PNPPOWER_EVENT_CALLBACKS pnpPowerCallbacks;
    WDF_OBJECT_ATTRIBUTES       attributes;
    WDFDEVICE                   device;
    PDEVICE_EXTENSION           DevExt = NULL;

    UNREFERENCED_PARAMETER( Driver );

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP,  "--> MCAPEvtDeviceAdd");

    PAGED_CODE();

    WdfDeviceInitSetIoType(DeviceInit, WdfDeviceIoDirect);

    //
	// This function initializes a driver's PnpPowerCallbacks structure.
    //
    WDF_PNPPOWER_EVENT_CALLBACKS_INIT(&pnpPowerCallbacks);

	// Prepare and Release Hardware callbacks
	pnpPowerCallbacks.EvtDevicePrepareHardware = MCAPEvtDevicePrepareHardware;
    pnpPowerCallbacks.EvtDeviceReleaseHardware = MCAPEvtDeviceReleaseHardware;

	// Power up and Power down callbacks
    pnpPowerCallbacks.EvtDeviceD0Entry         = MCAPEvtDeviceD0Entry;
    pnpPowerCallbacks.EvtDeviceD0Exit          = MCAPEvtDeviceD0Exit;

    //
	// This method registers a driver's Plug and Play 
	// and power management event callback functions.
    //
    WdfDeviceInitSetPnpPowerEventCallbacks(DeviceInit, &pnpPowerCallbacks);

	//
	// This function initializes a driver's WDF_OBJECT_ATTRIBUTES structure and 
	// inserts an object's driver-defined context information into the structure.
	//
    WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&attributes, DEVICE_EXTENSION);

    //
	// The framework synchronizes execution of the event callback functions 
	// of all queue and file objects that are underneath a device object in 
	// the driver's object hierarchy. 
	//
	attributes.SynchronizationScope = WdfSynchronizationScopeDevice;

    //
    // Create the device
    //
    status = WdfDeviceCreate( &DeviceInit, &attributes, &device );

    if (!NT_SUCCESS(status))
	{
        //
        // Device Initialization failed.
        //
        TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
                    "DeviceCreate failed %!STATUS!", status);
        return status;
    }

    //
    // Get the DeviceExtension and initialize it. 
    //
    DevExt = MCAPGetDeviceContext(device);

    DevExt->Device = device;

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP,
                "     AddDevice PDO (0x%p) FDO (0x%p), DevExt (0x%p)",
                WdfDeviceWdmGetPhysicalDevice(device),
                WdfDeviceWdmGetDeviceObject(device), DevExt);

    //
    // Create Device Interface
	//

    status = WdfDeviceCreateDeviceInterface( device,
                                             (LPGUID) &GUID_MCAP_INTERFACE,
                                             NULL );

    if (!NT_SUCCESS(status))
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
                    "<-- DeviceCreateDeviceInterface "
                    "failed %!STATUS!", status);
        return status;
    }

	//
    // Initalize the Device Extension.
    //
    status = MCAPInitializeDeviceExtension(DevExt);

    if (!NT_SUCCESS(status))
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
                    "<-- InitializeDeviceExtension "
                    "failed %!STATUS!", status);
		return status;
    }

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP,
                "<-- MCAPEvtDeviceAdd %!STATUS!", status);

    return status;
}

NTSTATUS
MCAPEvtDevicePrepareHardware (
    WDFDEVICE       Device,
    WDFCMRESLIST   Resources,
    WDFCMRESLIST   ResourcesTranslated
    )
/*++

Routine Description:

    Maps the IO and Memory resources.

Arguments:

    Device - A handle to the WDFDEVICE
    Resources - The raw PnP resources.
    ResourcesTranslated - The translated PnP resources.

Return Value:

    NT status code - failure will result in the device stack being torn down

--*/
{
    NTSTATUS            status = STATUS_SUCCESS;
    PDEVICE_EXTENSION   DevExt;
    ULONG               i;
    CHAR               *bar;

    BOOLEAN             foundRegs      = FALSE;
    PHYSICAL_ADDRESS    regsBasePA     = {0};
    ULONG               regsLength     = 0;

    BOOLEAN             foundPorts      = FALSE;
	PHYSICAL_ADDRESS    portBasePA     = {0};
    ULONG               portLength     = 0;

    PCM_PARTIAL_RESOURCE_DESCRIPTOR  desc;
	UNREFERENCED_PARAMETER(Resources);

    PAGED_CODE();

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP,
                "--> MCAPEvtDevicePrepareHardware");

    DevExt = MCAPGetDeviceContext(Device);

	//
    // Parse the resource list and save the resource information.
    //
    for (i=0; i < WdfCmResourceListGetCount(ResourcesTranslated); i++)
	{
        desc = WdfCmResourceListGetDescriptor( ResourcesTranslated, i );

        if(!desc)
		{
            TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
                        "WdfResourceCmGetDescriptor failed");
            return STATUS_DEVICE_CONFIGURATION_ERROR;
        }

        switch (desc->Type)
		{
            case CmResourceTypeMemory:

                bar = NULL;

				regsBasePA = desc->u.Memory.Start;
                regsLength = desc->u.Memory.Length;
                foundRegs = TRUE;
                bar = "BAR0";

                TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP,
                            " - Memory Resource [%I64X-%I64X] %s",
                            desc->u.Memory.Start.QuadPart,
                            desc->u.Memory.Start.QuadPart +
                            desc->u.Memory.Length,
                            (bar) ? bar : "<unrecognized>" );
                break;

            case CmResourceTypePort:

                bar = NULL;

				portBasePA = desc->u.Port.Start;
				portLength = desc->u.Port.Length;
				foundPorts = TRUE;
                bar = "BAR2";

                TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP,
                            " - Port   Resource [%08I64X-%08I64X] %s",
                            desc->u.Port.Start.QuadPart,
                            desc->u.Port.Start.QuadPart +
                            desc->u.Port.Length,
                            (bar) ? bar : "<unrecognized>" );
                break;

            default:
                //
                // Ignore all other descriptors
                //
                break;
        }
    }

    if (!foundRegs)
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
                    "MCAPEvtDevicePrepareHardware: Memory Resources Not Available");
		
		DevExt->RegsBase = NULL;
		DevExt->RegsLength = 0;

        return STATUS_SUCCESS;
    }
	else
	{
		//
		// Map in the Registers Memory resource: BAR0
		//
		DevExt->RegsBase = (PUCHAR) MmMapIoSpace( regsBasePA,
												  regsLength,
												  MmNonCached );

		if (!DevExt->RegsBase)
		{
			TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
				"MCAPEvtDevicePrepareHardware: - Unable to map Registers memory %08I64X, length %d",
						regsBasePA.QuadPart, regsLength);
			return STATUS_INSUFFICIENT_RESOURCES;
		}

		DevExt->RegsLength = regsLength;

		TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP,
					" - Registers %p, length %d",
					DevExt->RegsBase, DevExt->RegsLength );
	}

    if (!foundPorts)
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
                    "MCAPEvtDevicePrepareHardware: Port Resources Not Available");

		DevExt->PortBase = NULL;
		DevExt->PortLength = 0;

        return STATUS_SUCCESS;
    }
	else
	{
		//
		// Map in the Registers IO resource: BAR2
		//
		DevExt->PortBase = (PUCHAR) MmMapIoSpace( portBasePA, 
												  portLength, 
												  MmNonCached );

		if (!DevExt->PortBase)
		{
			TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
				"MCAPEvtDevicePrepareHardware: - Unable to map Registers memory %08I64X, length %d",
						portBasePA.QuadPart, portLength);
			return STATUS_INSUFFICIENT_RESOURCES;
		}

		DevExt->PortLength = portLength;

		TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP,
					" - Ports %p, length %d",
					DevExt->PortBase, DevExt->PortLength );
	}

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP,
                "<-- MCAPEvtDevicePrepareHardware, status %!STATUS!", status);

    return status;
}

NTSTATUS
MCAPEvtDeviceReleaseHardware(
    IN  WDFDEVICE Device,
    IN  WDFCMRESLIST ResourcesTranslated
    )
/*++

Routine Description:

    Unmap the resources that got mapped in MCAPEvtDevicePrepareHardware.

Arguments:

    Device - A handle to the WDFDEVICE
    ResourcesTranslated - The translated PnP resources.

Return Value:

    NT status code - failure will result in the device stack being torn down

--*/
{
    PDEVICE_EXTENSION   DevExt;
    NTSTATUS status = STATUS_SUCCESS;

    UNREFERENCED_PARAMETER(ResourcesTranslated);

    PAGED_CODE();

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP,
                "--> MCAPEvtDeviceReleaseHardware");

    DevExt = MCAPGetDeviceContext(Device);

	// Unmap the IO Resources
    if (DevExt->RegsBase)
	{
        MmUnmapIoSpace(DevExt->RegsBase, DevExt->RegsLength);
        DevExt->RegsBase = NULL;
    }

	// Unmap the Memory Resources
    if (DevExt->PortBase)
	{
        MmUnmapIoSpace(DevExt->PortBase, DevExt->PortLength);
        DevExt->PortBase = NULL;
    }

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP,
                "<-- MCAPEvtDeviceReleaseHardware");

    return status;
}


NTSTATUS
MCAPEvtDeviceD0Entry(
    IN  WDFDEVICE Device,
    IN  WDF_POWER_DEVICE_STATE PreviousState
    )
/*++

Routine Description:

    Handle device when entering to D0 State.
	when the device is entering D0 from any of the Low power state, this call back is invoked.
	So handle everything related coming back from low power state of the device here.

Arguments:

    Device  - The handle to the WDF device
    PreviousState - The state the device was in before this callback was invoked.

Return Value:

    NTSTATUS

    Success implies that the device can be used.
    Failure will result in the    device stack being torn down.

--*/
{
    PDEVICE_EXTENSION   DevExt;
    NTSTATUS            status = STATUS_SUCCESS;

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_INIT, "MCAPEvtDeviceD0Entry -->");

    UNREFERENCED_PARAMETER(PreviousState);

    DevExt = MCAPGetDeviceContext(Device);

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_INIT, "<-- MCAPEvtDeviceD0Entry");
    return status;
}

NTSTATUS
MCAPEvtDeviceD0Exit(
    IN  WDFDEVICE Device,
    IN  WDF_POWER_DEVICE_STATE TargetState
    )
/*++

Routine Description:

    Handle device when leaving from D0 State.
	when the device is leaving D0 to any of the Low power state, this call back is invoked.
	So handle everything related to low power state	of the device here.

Arguments:

    Device  - The handle to the WDF device
    TargetState - The State of the device after this callback.

Return Value:

    Success implies that the device can be used.  Failure will result in the
    device stack being torn down.

--*/
{
    PDEVICE_EXTENSION   DevExt;

    PAGED_CODE();

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_INIT, "MCAPEvtDeviceD0Exit -->");

    DevExt = MCAPGetDeviceContext(Device);

    switch (TargetState)
	{
		case WdfPowerDeviceD1:
		case WdfPowerDeviceD2:
		case WdfPowerDeviceD3:

			//
			// Fill in any code to save hardware state here.
			//

			//
			// Fill in any code to put the device in a low-power state here.
			//
			break;

		case WdfPowerDeviceD3Final:
		default:

			//
			// Reset the hardware
			//
			MCAPHardwareReset(DevExt);
			break;
	}

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_INIT, "<-- MCAPEvtDeviceD0Exit");
    return STATUS_SUCCESS;
}


// _Use_decl_annotations_
VOID
MCAPEvtDriverContextCleanup(
    WDFOBJECT Driver
    )
/*++
Routine Description:

    Free all the resources allocated in DriverEntry.

Arguments:

    Driver - handle to a WDF Driver object.

Return Value:

    VOID.

--*/
{
    PAGED_CODE ();

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_INIT,
                    "MCAPEvtDriverContextCleanup: enter");

    WPP_CLEANUP( WdfDriverWdmGetDriverObject( Driver ) );

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_INIT,
                    "MCAPEvtDriverContextCleanup: exit");
}
