/********************************************************************
*Copyright (C) 2014 � 2015 Xilinx, Inc.  All rights reserved.
*
*Permission is hereby granted, free of charge, to any person obtaining
*a copy of this software and associated documentation files (the
*"Software"), to deal in the Software without restriction, including
*without limitation the rights to use, copy, modify, merge, publish,
*distribute, sublicense, and/or sell copies of the Software, and to
*permit persons to whom the Software is furnished to do so, subject to
*the following conditions:
*
*The above copyright notice and this permission notice shall be 
*included in all copies or substantial portions of the Software.
*
*Use of the Software is limited solely to applications: (a) running 
*on a Xilinx device, or (b) that interact with a Xilinx device 
*through a bus or interconnect.  
*
*THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*NONINFRINGEMENT. IN NO EVENT SHALL XILINX BE LIABLE FOR ANY CLAIM, 
*DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
*OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
*OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*Except as contained in this notice, the name of the Xilinx shall
*not be used in advertising or otherwise to promote the sale, use or
*other dealings in this Software without prior written authorization
*from Xilinx.
*********************************************************************/

#include "precomp.h"
#include "mcapWrite.tmh"


//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
VOID
MCAPEvtIoWrite(
    IN WDFQUEUE         Queue,
    IN WDFREQUEST       Request,
    IN size_t           Length
    )
/*++

Description:

    This Event Callback function processes a specified write request.

Arguments:

    Queue   - Wtite requests queue handle.
    Request - Write request handle.
    Length  - Length of the request

Return Value:

--*/
{
    NTSTATUS          NtStatus = STATUS_UNSUCCESSFUL;
    PDEVICE_EXTENSION DevExt = NULL;
	PUCHAR             Buffer = NULL;
	USER_WRITE_BUFFER WriteBuffer;
    PARTIAL_BITSTREAM_TYPE  Type;
	ULONG             BufferLength = 0;
	WDFMEMORY         Memory;

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_WRITE,
                "--> MCAPEvtIoWrite: Request %p", Request);

    //
    // Get the DevExt from the Queue handle
    //
    DevExt = MCAPGetDeviceContext(WdfIoQueueGetDevice(Queue));

	// We do not want any other operation to interrupt our operation
	WdfSpinLockAcquire(DevExt->ExOperationLock);

	if(DevExt->ResetInProgress)
	{
		NtStatus = STATUS_UNSUCCESSFUL;
        TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
                    "Device Reset in Progress : %!STATUS!", NtStatus);
		goto CleanUp;
	}

    NtStatus = WdfRequestRetrieveInputMemory(Request, &Memory);
    if (!NT_SUCCESS(NtStatus))
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
                    "WdfRequestRetrieveInputMemory failed: %!STATUS!", NtStatus);
        goto CleanUp;
    }

	Buffer = (PUCHAR)WdfMemoryGetBuffer(Memory, (size_t *)&BufferLength);

	memcpy(&WriteBuffer,Buffer,sizeof(USER_WRITE_BUFFER));

	if(WriteBuffer.USER_SPACE_BITSTREAM_TYPE.BIT.FIELD_UPDATE != 1)
	{
		// Write Bit Stream
		NtStatus = WriteBitStream(DevExt, (PVOID)((PUCHAR)(Buffer) + sizeof(USER_WRITE_BUFFER)),\
			                                  WriteBuffer.full_bitstream_length);
		if (!NT_SUCCESS(NtStatus))
		{
			TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
				"WriteBitStream failed: %!STATUS!", NtStatus);
			goto CleanUp;
		}
	}
	else
	{
		if(WriteBuffer.USER_SPACE_BITSTREAM_TYPE.BIT.MULTIPLE_BITSTREAM == 1)
		{
			if((WriteBuffer.USER_SPACE_BITSTREAM_TYPE.BIT.CLEAR_BITSTREAM == 1) && 
				((WriteBuffer.USER_SPACE_BITSTREAM_TYPE.BIT.FULL_BITSTREAM == 1)))
			{
				// Write ClearBit Stream
				Type = CLEAR;
				NtStatus = WritePartialBitStream(DevExt, (PVOID)((PUCHAR)(Buffer) + sizeof(USER_WRITE_BUFFER)),\
					                                      WriteBuffer.clear_bitstream_length,Type);
				if (!NT_SUCCESS(NtStatus))
				{
					TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
						"WritePartialBitStream Clear failed: %!STATUS!", NtStatus);
					goto CleanUp;
				}
				// Write PartialBit Stream
				Type = DATA; 
				NtStatus = WritePartialBitStream(DevExt, (PVOID)((PUCHAR)(Buffer) + sizeof(USER_WRITE_BUFFER) + WriteBuffer.clear_bitstream_length),\
					                                      WriteBuffer.full_bitstream_length,Type);
				if (!NT_SUCCESS(NtStatus))
				{
					TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
						"WritePartialBitStream Data failed: %!STATUS!", NtStatus);
					goto CleanUp;
				}
			}
			else
			{
				goto CleanUp;
			}
		}
		else
		{
			if(WriteBuffer.USER_SPACE_BITSTREAM_TYPE.BIT.CLEAR_BITSTREAM == 1)
			{
				// Write ClearBit Stream
				Type = CLEAR;
				NtStatus = WritePartialBitStream(DevExt, (PVOID)((PUCHAR)(Buffer) + sizeof(USER_WRITE_BUFFER)),\
					                                   WriteBuffer.clear_bitstream_length,Type);
				if (!NT_SUCCESS(NtStatus))
				{
					TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
						"WritePartialBitStream Clear failed: %!STATUS!", NtStatus);
					goto CleanUp;
				}
			}
			if(WriteBuffer.USER_SPACE_BITSTREAM_TYPE.BIT.FULL_BITSTREAM == 1)
			{
				// Write PartialBit Stream
				Type = DATA; 
				NtStatus = WritePartialBitStream(DevExt, (PVOID)((PUCHAR)(Buffer) + sizeof(USER_WRITE_BUFFER)),\
					                             WriteBuffer.full_bitstream_length,Type);
				if (!NT_SUCCESS(NtStatus))
				{
					TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
						"WritePartialBitStream Data failed: %!STATUS!", NtStatus);
					goto CleanUp;
				}
			}
		}
	}

	WdfRequestCompleteWithInformation( Request, NtStatus, BufferLength);

	NtStatus = STATUS_SUCCESS;

CleanUp:

	WdfSpinLockRelease(DevExt->ExOperationLock);

    //
    // If there are errors, then complete the Request.
    //
    if (!NT_SUCCESS(NtStatus))
	{
        WdfRequestComplete(Request, NtStatus);
    }

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_WRITE,
                "<-- MCAPEvtIoWrite: %!STATUS!", NtStatus);

    return;
}

NTSTATUS WriteBitStream(
    IN  PDEVICE_EXTENSION DevExt,
	IN  PVOID Buffer,
	IN  ULONG BufferLength
				   )
/*++

Routine Description:

    Called by the EvtIoWrite as soon as it receives a write request.
    It will write the Data available in the Buffer to the device 
	DWORD by DWORD and completes the request.

Arguments:

    DevExt - Device Extension.
    Buffer - Buffer from which the data to be read.
    BufferLength - Size of the Buffer Passed.

Return Value:

    NTSTATUS

--*/
{
	NTSTATUS NtStatus = STATUS_UNSUCCESSFUL;

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_WRITE,	"WriteBitStream -->");

	if(!DevExt)
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WriteBitStream: DevExt is NULL");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	if(!Buffer)
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WriteBitStream: Buffer is NULL");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	if(!BufferLength)
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WriteBitStream: BufferLength is 0");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	/*
		Steps to Perform this Operation
		-	Perform a Write Bitstream: High-Throughput
			.	If this generates a FIFO Overflow error 
				@	Print a message identifying the FIFO Overflow and that a bitstream write retry will be attempted
				@	Perform �Write Bitstream: With FIFO Occupancy Check�
					*	If this generates an error, issue an error
		-	Terminate with appropriate messages and status
	*/

	// Perform a �Write Bitstream: High-Throughput� operation
	NtStatus = WriteBitStreamHT(DevExt, Buffer, BufferLength);
    if (NT_SUCCESS(NtStatus))
	{
		// Write Success
		return NtStatus;
	}

    TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
		"WriteBitStream: WriteBitStreamHT Failed");

	return NtStatus;
}

NTSTATUS WritePartialBitStream(
    IN  PDEVICE_EXTENSION DevExt,
	IN  PVOID Buffer,
	IN  ULONG BufferLength,
	IN  PARTIAL_BITSTREAM_TYPE type
				   )
/*++

Routine Description:

    Called by the EvtIoWrite as soon as it receives a write request.
    It will write the Data available in the Buffer to the device 
	DWORD by DWORD and completes the request.

Arguments:

    DevExt - Device Extension.
    Buffer - Buffer from which the data to be read.
    BufferLength - Size of the Buffer Passed.

Return Value:

    NTSTATUS

--*/
{
	NTSTATUS NtStatus = STATUS_UNSUCCESSFUL;

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_WRITE,	"WriteBitStream -->");

	if(!DevExt)
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WriteBitStream: DevExt is NULL");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	if(!Buffer)
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WriteBitStream: Buffer is NULL");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	if(!BufferLength)
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WriteBitStream: BufferLength is 0");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	/*
		Steps to Perform this Operation
		-	Perform a Write Bitstream: High-Throughput
			.	If this generates a FIFO Overflow error 
				@	Print a message identifying the FIFO Overflow and that a bitstream write retry will be attempted
				@	Perform �Write Bitstream: With FIFO Occupancy Check�
					*	If this generates an error, issue an error
		-	Terminate with appropriate messages and status
	*/

	// Perform a �Write Bitstream: High-Throughput� operation
	NtStatus = WritePartialBitStreamHT(DevExt, Buffer, BufferLength,type);
    if (NT_SUCCESS(NtStatus))
	{
		// Write Success
		return NtStatus;
	}

    TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
		"WriteBitStream: WriteBitStreamHT Failed");

	return NtStatus;
}

NTSTATUS WriteBitStreamHT(
    IN  PDEVICE_EXTENSION DevExt,
	IN  PVOID Buffer,
	IN  ULONG BufferLength
				   )
/*++

Routine Description:

    This Function Writes the Bit Stream in High throughput Mode.

Arguments:

    DevExt - Device Extension.
    Buffer - Buffer from which the data to be read.
    BufferLength - Size of the Buffer Passed.

Return Value:

    NTSTATUS

--*/
{
	NTSTATUS NtStatus = STATUS_UNSUCCESSFUL;
	CTRL_REG CtrlReg;
	CTRL_REG OldCtrlReg;
	STAT_REG StatReg;
	ULONG LoopCount = 0;
	ULONG RetryCount = 0;
	LARGE_INTEGER    delay;
	PULONG DataBuffer = (PULONG)Buffer;

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_WRITE,	"WriteBitStreamHT -->");

	if(!DevExt)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WriteBitStreamHT: DevExt is NULL");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	if(!Buffer)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WriteBitStreamHT: Buffer is NULL");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	if(!BufferLength)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WriteBitStreamHT: BufferLength is NULL");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	/*
		Steps to Perform this Operation
		-	Perform a �Control and Status Register Read�
			.	If (Configure MCAP Request by Configure = 1)
				@	Modify the appropriate values in the control register data structure
					*	MCAP Mode = 1
					*	MCAP Configure In Use by PCIe = 1
				@	Poll Configure MCAP Request by Configure, If this does not got to 0
					*	Perform a �Control Register Write� operation to restore the original values
					*	 issue an error and return
		-	Verify current contents of the control and status registers
			.	If (MCAP_Error=1) issue an error and return
			.	If (MCAP_Write_FIFO_Overflow=1) issue an error and return
			.	If (MCAP_Register_Read_Complete=1) issue an error and return
		-	Modify the appropriate values in the control register data structure
			.	MCAP Mode = 1
			.	MCAP Register Read = 0
			.	MCAP Reset = 0
			.	MCAP Module Reset = 0
			.	MCAP Configure In Use by PCIe = 1
			.	Configure MCAP Design Switch = <Retain Value>
			.	Data Register Protect = 1
		-	Perform a �Control Register Write� operation to update these values
		-	Loop For every 32-bit data value in the provided programming file
			.	Perform �Register Write� operations to the MCAP Data_Register with the provided data.	
		-	Perform a �Control and Status Register Read�
		-	Verify current contents of the control and status registers
			.	If (MCAP_Error=1 OR MCAP_Write_FIFO_Overflow=1) issue an error
				@	Perform an �MCAP Full Reset�
		-	Perform a �Control Register Write� operation to restore the original values
			.	With the exception of MCAP EOS, this should be set to 1; unless an error occurred, in which case MCAP EOS should retain its value
		-	Terminate with appropriate messages and status
	*/

	// Perform Status Read
	StatReg.regval = ReadMCAP_StatusReg(DevExt);
	if (StatReg.bits.CfgMCAPRequestByCfg == 1)
	{
		// Perform Control Read
		OldCtrlReg.regval = CtrlReg.regval = ReadMCAP_ControlReg(DevExt);
		CtrlReg.bits.MCAPMode = 1;
		CtrlReg.bits.CfgMCAPInUseByPCIe = 1;
		// Perform Control Write
		WriteMCAP_ControlReg(DevExt, CtrlReg.regval);

		// Perform Status Read
		StatReg.regval = ReadMCAP_StatusReg(DevExt);
		while(StatReg.bits.CfgMCAPRequestByCfg)
		{
			if(LoopCount > MAX_LOOP_COUNT)
			{
				// Error
				TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
					"WriteBitStreamHT: Configure MCAP Request by Configure(CfgMCAPRequestByCfg) Bit is Not Resetting.");

				// Restore Original Values
		        WriteMCAP_ControlReg(DevExt, MCAP_CTRL_DEFAULT_VALUE);

				// Return Error
				NtStatus = STATUS_UNSUCCESSFUL;
				return NtStatus;
			}

			LoopCount++;
			StatReg.regval = ReadMCAP_StatusReg(DevExt);
		}
	}

	// Perform Status Read
	StatReg.regval = ReadMCAP_StatusReg(DevExt);

	if(StatReg.bits.MCAPError == 1)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WriteBitStreamHT: MCAPError is Set");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	if(StatReg.bits.MCAPWriteFifoOverflow == 1)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WriteBitStreamHT: MCAPWriteFifoOverflow is Set");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	if(StatReg.bits.MCAPRegReadComplete == 1)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WriteBitStreamHT: MCAPRegReadComplete is Set");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	// Write Operation
	// Perform Control Read
	OldCtrlReg.regval = CtrlReg.regval = ReadMCAP_ControlReg(DevExt);
	CtrlReg.bits.MCAPMode = 1;
	CtrlReg.bits.MCAPRegisterRead = 0;
	CtrlReg.bits.MCAPReset = 0;
	CtrlReg.bits.MCAPModuleReset = 0;
	CtrlReg.bits.CfgMCAPInUseByPCIe = 1;
	CtrlReg.bits.DataRegisterProtect = 1;
	// Perform Control Write for Write operation
	WriteMCAP_ControlReg(DevExt, CtrlReg.regval);

	// Write Data Registers
	LoopCount = 0;
	while(LoopCount < BufferLength/4)
	{
		ULONG test = *DataBuffer;
		TraceEvents(TRACE_LEVEL_VERBOSE, DBG_WRITE,
			"WriteBitStreamHT: DataBuffer:%p, LoopCount:%d, BufferLength:%d", DataBuffer, LoopCount, BufferLength);
		WriteMCAP_Registers(DevExt, DATA_REG_INDEX, test);
		DataBuffer++;
		LoopCount++;
	}

	// 
	// Perform Control Read
	CtrlReg.regval = ReadMCAP_ControlReg(DevExt);

	// Perform Status Read
	StatReg.regval = ReadMCAP_StatusReg(DevExt);

	if(StatReg.bits.MCAPError == 1)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WriteBitStreamHT: MCAPError is Set");

		// Restore Original Values
		        WriteMCAP_ControlReg(DevExt, MCAP_CTRL_DEFAULT_VALUE);

		// Perfrom Full Reset
		MCAPFullReset(DevExt);

		// Return Error
		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	if(StatReg.bits.MCAPWriteFifoOverflow == 1)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WriteBitStreamHT: MCAPWriteFifoOverflow is Set");

		// Restore Original Values
		        WriteMCAP_ControlReg(DevExt, MCAP_CTRL_DEFAULT_VALUE);

		// Perfrom Full Reset
		MCAPFullReset(DevExt);

		// Return Error
		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

		
	// Perform Status Read
		StatReg.regval = ReadMCAP_StatusReg(DevExt);
			while(StatReg.bits.MCAPEOS != 1) 
			{
				//
				// Wait 2 usec.
				//
				delay.QuadPart =  WDF_REL_TIMEOUT_IN_US(2);
				KeDelayExecutionThread( KernelMode, TRUE, &delay );

#ifdef PROGRAM_NOOP_FOR_EOS_CHECKING
				LoopCount = 0;
				while(LoopCount < MAX_EOS_LOOP_COUNT)
				{
		            WriteMCAP_Registers(DevExt, DATA_REG_INDEX, MCAP_NOOP_VAL);
					LoopCount++;
				}
#endif
				StatReg.regval = ReadMCAP_StatusReg(DevExt);
				RetryCount ++;
				if(RetryCount > MAX_EOS_RETRY_COUNT)
				{
					// Error
					TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
						"WriteBitStreamHT: Configure MCAPEOS Bit is Not getting Set");

					// Restore Original Values
		        WriteMCAP_ControlReg(DevExt, MCAP_CTRL_DEFAULT_VALUE);

					// Return Error
					NtStatus = STATUS_UNSUCCESSFUL;
					return NtStatus;
				}
			}
	
	// Restore Original Values
		        WriteMCAP_ControlReg(DevExt, MCAP_CTRL_DEFAULT_VALUE);

	NtStatus = STATUS_SUCCESS;
	return NtStatus;
}

NTSTATUS WritePartialBitStreamHT(
    IN  PDEVICE_EXTENSION DevExt,
	IN  PVOID Buffer,
	IN  ULONG BufferLength,
	IN  PARTIAL_BITSTREAM_TYPE type
				   )
/*++

Routine Description:

    This Function Writes the Bit Stream in High throughput Mode.

Arguments:

    DevExt - Device Extension.
    Buffer - Buffer from which the data to be read.
    BufferLength - Size of the Buffer Passed.

Return Value:

    NTSTATUS

--*/
{
	NTSTATUS NtStatus = STATUS_UNSUCCESSFUL;
	CTRL_REG CtrlReg;
	CTRL_REG OldCtrlReg;
	STAT_REG StatReg;
	ULONG LoopCount = 0;
	ULONG RetryCount = 0;
	LARGE_INTEGER    delay;
	PULONG DataBuffer = (PULONG)Buffer;

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_WRITE,	"WritePartialBitStreamHT -->");

	if(!DevExt)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WritePartialBitStreamHT: DevExt is NULL");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	if(!Buffer)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WritePartialBitStreamHT Buffer is NULL");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	if(!BufferLength)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WritePartialBitStreamHT: BufferLength is NULL");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	/*
		Steps to Perform this Operation
		-	Perform a �Control and Status Register Read�
			.	If (Configure MCAP Request by Configure = 1)
				@	Modify the appropriate values in the control register data structure
					*	MCAP Mode = 1
					*	MCAP Configure In Use by PCIe = 1
				@	Poll Configure MCAP Request by Configure, If this does not got to 0
					*	Perform a �Control Register Write� operation to restore the original values
					*	 issue an error and return
		-	Verify current contents of the control and status registers
			.	If (MCAP_Error=1) issue an error and return
			.	If (MCAP_Write_FIFO_Overflow=1) issue an error and return
			.	If (MCAP_Register_Read_Complete=1) issue an error and return
		-	Modify the appropriate values in the control register data structure
			.	MCAP Mode = 1
			.	MCAP Register Read = 0
			.	MCAP Reset = 0
			.	MCAP Module Reset = 0
			.	MCAP Configure In Use by PCIe = 1
			.	Configure MCAP Design Switch = <Retain Value>
			.	Data Register Protect = 1
		-	Perform a �Control Register Write� operation to update these values
		-	Loop For every 32-bit data value in the provided programming file
			.	Perform �Register Write� operations to the MCAP Data_Register with the provided data.	
		-	Perform a �Control and Status Register Read�
		-	Verify current contents of the control and status registers
			.	If (MCAP_Error=1 OR MCAP_Write_FIFO_Overflow=1) issue an error
				@	Perform an �MCAP Full Reset�
		-	Perform a �Control Register Write� operation to restore the original values
			.	With the exception of MCAP EOS, this should be set to 1; unless an error occurred, in which case MCAP EOS should retain its value
		-	Terminate with appropriate messages and status
	*/

	// Perform Status Read
	StatReg.regval = ReadMCAP_StatusReg(DevExt);
	if (StatReg.bits.CfgMCAPRequestByCfg == 1)
	{
		// Perform Control Read
		OldCtrlReg.regval = CtrlReg.regval = ReadMCAP_ControlReg(DevExt);
		CtrlReg.bits.MCAPMode = 1;
		CtrlReg.bits.CfgMCAPInUseByPCIe = 1;
		// Perform Control Write
		WriteMCAP_ControlReg(DevExt, CtrlReg.regval);

		// Perform Status Read
		StatReg.regval = ReadMCAP_StatusReg(DevExt);
		while(StatReg.bits.CfgMCAPRequestByCfg)
		{
			if(LoopCount > MAX_LOOP_COUNT)
			{
				// Error
				TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
					"WritePartialBitStreamHT: Configure MCAP Request by Configure(CfgMCAPRequestByCfg) Bit is Not Resetting.");

				// Restore Original Values
		        WriteMCAP_ControlReg(DevExt, MCAP_CTRL_DEFAULT_VALUE);

				// Return Error
				NtStatus = STATUS_UNSUCCESSFUL;
				return NtStatus;
			}

			LoopCount++;
			StatReg.regval = ReadMCAP_StatusReg(DevExt);
		}
	}

	// Perform Status Read
	StatReg.regval = ReadMCAP_StatusReg(DevExt);

	if(StatReg.bits.MCAPError == 1)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WritePartialBitStreamHT: MCAPError is Set");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	if(StatReg.bits.MCAPWriteFifoOverflow == 1)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WritePartialBitStreamHT: MCAPWriteFifoOverflow is Set");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	if(StatReg.bits.MCAPRegReadComplete == 1)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WritePartialBitStreamHT: MCAPRegReadComplete is Set");

		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	// Write Operation
	// Perform Control Read
	if(type == CLEAR)
	{
		DevExt->SavedCtrlReg.regval = OldCtrlReg.regval = CtrlReg.regval = ReadMCAP_ControlReg(DevExt);
		CtrlReg.bits.MCAPMode = 1;
		CtrlReg.bits.MCAPRegisterRead = 0;
		CtrlReg.bits.MCAPReset = 0;
		CtrlReg.bits.MCAPModuleReset = 0;
		CtrlReg.bits.CfgMCAPInUseByPCIe = 1;
		CtrlReg.bits.DataRegisterProtect = 1;
		// Perform Control Write for Write operation
		WriteMCAP_ControlReg(DevExt, CtrlReg.regval);
	}

	// Write Data Registers
	LoopCount = 0;
	while(LoopCount < BufferLength/4)
	{
		ULONG test = *DataBuffer;
		TraceEvents(TRACE_LEVEL_VERBOSE, DBG_WRITE,
			"WritePartialBitStreamHT: DataBuffer:%p, LoopCount:%d, BufferLength:%d", DataBuffer, LoopCount, BufferLength);
		WriteMCAP_Registers(DevExt, DATA_REG_INDEX, test);
		DataBuffer++;
		LoopCount++;
	}

	if(type == CLEAR)
	{
		LoopCount = 0;
		while(LoopCount < MAX_EOS_LOOP_COUNT)
		{
			WriteMCAP_Registers(DevExt, DATA_REG_INDEX, MCAP_NOOP_VAL);
			LoopCount++;
		}
	}

	// 
	// Perform Control Read
	CtrlReg.regval = ReadMCAP_ControlReg(DevExt);

	// Perform Status Read
	StatReg.regval = ReadMCAP_StatusReg(DevExt);

	if(StatReg.bits.MCAPError == 1)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WritePartialBitStreamHT: MCAPError is Set");

		// Restore Original Values
		WriteMCAP_ControlReg(DevExt,MCAP_CTRL_DEFAULT_VALUE);

		// Perfrom Full Reset
		MCAPFullReset(DevExt);

		// Return Error
		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

	if(StatReg.bits.MCAPWriteFifoOverflow == 1)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
			"WritePartialBitStreamHT: MCAPWriteFifoOverflow is Set");

		// Restore Original Values
		WriteMCAP_ControlReg(DevExt,MCAP_CTRL_DEFAULT_VALUE);


		// Perfrom Full Reset
		MCAPFullReset(DevExt);

		// Return Error
		NtStatus = STATUS_UNSUCCESSFUL;
		return NtStatus;
	}

		
	if(type == DATA)
	{
		// Perform Status Read
		StatReg.regval = ReadMCAP_StatusReg(DevExt);
		while(StatReg.bits.MCAPEOS != 1) 
		{
			//
			// Wait 2 usec.
			//
			delay.QuadPart =  WDF_REL_TIMEOUT_IN_US(2);
			KeDelayExecutionThread( KernelMode, TRUE, &delay );

#ifdef PROGRAM_NOOP_FOR_EOS_CHECKING
			LoopCount = 0;
			while(LoopCount < MAX_EOS_LOOP_COUNT)
			{
				WriteMCAP_Registers(DevExt, DATA_REG_INDEX, MCAP_NOOP_VAL);
				LoopCount++;
			}
#endif
			StatReg.regval = ReadMCAP_StatusReg(DevExt);
			RetryCount ++;
			if(RetryCount > MAX_EOS_RETRY_COUNT)
			{
				// Error
				TraceEvents(TRACE_LEVEL_ERROR, DBG_WRITE,
					"WritePartialBitStreamHT: Configure MCAPEOS Bit is Not getting Set");

				// Restore Original Values
				WriteMCAP_ControlReg(DevExt,MCAP_CTRL_DEFAULT_VALUE);
				DevExt->SavedCtrlReg.regval = INVALID_VALUE;

				// Return Error
				NtStatus = STATUS_UNSUCCESSFUL;
				return NtStatus;
			}
		}
		// Restore Original Values
		WriteMCAP_ControlReg(DevExt,MCAP_CTRL_DEFAULT_VALUE);
		DevExt->SavedCtrlReg.regval = INVALID_VALUE;
	}


	NtStatus = STATUS_SUCCESS;
	return NtStatus;
}
