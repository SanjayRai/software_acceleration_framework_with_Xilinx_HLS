/********************************************************************
*Copyright (C) 2014 � 2015 Xilinx, Inc.  All rights reserved.
*
*Permission is hereby granted, free of charge, to any person obtaining
*a copy of this software and associated documentation files (the
*"Software"), to deal in the Software without restriction, including
*without limitation the rights to use, copy, modify, merge, publish,
*distribute, sublicense, and/or sell copies of the Software, and to
*permit persons to whom the Software is furnished to do so, subject to
*the following conditions:
*
*The above copyright notice and this permission notice shall be 
*included in all copies or substantial portions of the Software.
*
*Use of the Software is limited solely to applications: (a) running 
*on a Xilinx device, or (b) that interact with a Xilinx device 
*through a bus or interconnect.  
*
*THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*NONINFRINGEMENT. IN NO EVENT SHALL XILINX BE LIABLE FOR ANY CLAIM, 
*DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
*OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
*OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*Except as contained in this notice, the name of the Xilinx shall
*not be used in advertising or otherwise to promote the sale, use or
*other dealings in this Software without prior written authorization
*from Xilinx.
*********************************************************************/

#include "precomp.h"

#include "mcapIsrDpc.tmh"

NTSTATUS
MCAPInterruptCreate(
    IN PDEVICE_EXTENSION DevExt
    )
/*++
Routine Description:

    Create the WDFINTERRUPT object.

Arguments:

    DevExt      Pointer to the DEVICE_EXTENSION

Return Value:

    NTSTATUS

--*/
{
    NTSTATUS                    NtStatus;
    WDF_INTERRUPT_CONFIG        InterruptConfig;

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP,	"MCAPInterruptCreate -->");

    WDF_INTERRUPT_CONFIG_INIT( &InterruptConfig,
                               MCAPEvtInterruptIsr,
                               MCAPEvtInterruptDpc );

    InterruptConfig.EvtInterruptEnable  = MCAPEvtInterruptEnable;
    InterruptConfig.EvtInterruptDisable = MCAPEvtInterruptDisable;

    // Enable for DpcForIsr Synchronization
    InterruptConfig.AutomaticSerialization = TRUE;

    NtStatus = WdfInterruptCreate( DevExt->Device,
                                 &InterruptConfig,
                                 WDF_NO_OBJECT_ATTRIBUTES,
                                 &DevExt->Interrupt );

    if( !NT_SUCCESS(NtStatus) )
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_PNP,
                    "WdfInterruptCreate failed: %!STATUS!", NtStatus);
    }

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_PNP,	"<-- MCAPInterruptCreate");
    return NtStatus;
}

BOOLEAN
MCAPEvtInterruptIsr(
    IN WDFINTERRUPT Interrupt,
    IN ULONG        MessageID
    )
/*++
Routine Description:

	This event callback function services a hardware interrupt.
	Check if this interrupt is raised by our device.
	If so then clear the interrupts, Queue the DPC.
	
Arguments:

    Interupt   - Handle to WDFINTERRUPT Object.
    MessageID  - MSI message ID

Return Value:

     TRUE   --  This device generated the interrupt.
     FALSE  --  This device did not generated this interrupt.

--*/
{
    PDEVICE_EXTENSION   DevExt;
    BOOLEAN             isRecognized = FALSE;
	CTRL_REG			CtrlReg = {0};
	STAT_REG			StatReg = {0};

    UNREFERENCED_PARAMETER(MessageID);

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_INTERRUPT,
		"--> MCAPInterruptHandler, MessageID:%d", MessageID);

    DevExt  = MCAPGetDeviceContext(WdfInterruptGetDevice(Interrupt));

	// Read Status Register
	StatReg.regval = ReadMCAP_StatusReg(DevExt);

	// Read Control Register
	CtrlReg.regval = ReadMCAP_ControlReg(DevExt);

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_INTERRUPT,
		"Control_reg:0x%x, Status_Reg:0x%x", CtrlReg.regval, StatReg.regval);

	if( 
		(CtrlReg.bits.MCAPMode == 1) && 
		((StatReg.bits.MCAPError == 1) || (StatReg.bits.MCAPWriteFifoOverflow == 1) )
	)
	{
		//
		// Interrupt Handling is done. Queue a DPC.
		//

		TraceEvents(TRACE_LEVEL_INFORMATION, DBG_INTERRUPT,
			"Queuing the DPC ");

		WdfInterruptQueueDpcForIsr( DevExt->Interrupt );
		isRecognized = TRUE;
	}

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_INTERRUPT,
                "<-- MCAPInterruptHandler");

    return isRecognized;
}

// _Use_decl_annotations_
VOID
MCAPEvtInterruptDpc(
    WDFINTERRUPT Interrupt,
    WDFOBJECT    Device
    )
/*++

Routine Description:

    DPC callback for ISR.

Arguments:

    Interupt  - Handle to WDFINTERRUPT Object.
    Device    - WDFDEVICE object

Return Value:

--*/
{
    NTSTATUS            status;
    PDEVICE_EXTENSION   DevExt;
    BOOLEAN             mcapInterrupt = FALSE;
	CTRL_REG			CtrlReg = {0};
	STAT_REG			StatReg = {0};

    UNREFERENCED_PARAMETER(Device);


    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_DPC, "--> EvtInterruptDpc");

    DevExt = MCAPGetDeviceContext(WdfInterruptGetDevice(Interrupt));

    //
    // Acquire this device's InterruptSpinLock.
    //
    WdfInterruptAcquireLock( Interrupt );

	// Read Status Register
	StatReg.regval = ReadMCAP_StatusReg(DevExt);

	// Read Control Register
	CtrlReg.regval = ReadMCAP_ControlReg(DevExt);

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_DPC, 
		"Before Reset: Control_reg:0x%x, Status_Reg:0x%x", CtrlReg.regval, StatReg.regval);
	// Do device reset
	// Perform Reset on Interrupt
	MCAPFullReset(DevExt);

	// Read Status Register
	StatReg.regval = ReadMCAP_StatusReg(DevExt);

	// Read Control Register
	CtrlReg.regval = ReadMCAP_ControlReg(DevExt);

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_DPC, 
		"After Reset: Control_reg:0x%x, Status_Reg:0x%x", CtrlReg.regval, StatReg.regval);

    //
    // Release our interrupt spinlock
    //
    WdfInterruptReleaseLock( Interrupt );

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_DPC, "<-- EvtInterruptDpc");

    return;
}

NTSTATUS
MCAPEvtInterruptEnable(
    IN WDFINTERRUPT Interrupt,
    IN WDFDEVICE    Device
    )
/*++

Routine Description:

    Callback when interrupts are enabled.

Arguments:

    Interupt  - Handle to WDFINTERRUPT Object.
    Device    - WDFDEVICE object

Return Value:

    NTSTATUS
--*/
{
    PDEVICE_EXTENSION  DevExt;

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_INTERRUPT,
                "MCAPEvtInterruptEnable: Interrupt 0x%p, Device 0x%p\n",
                Interrupt, Device);

    DevExt = MCAPGetDeviceContext(WdfInterruptGetDevice(Interrupt));

    return STATUS_SUCCESS;
}

NTSTATUS
MCAPEvtInterruptDisable(
    IN WDFINTERRUPT Interrupt,
    IN WDFDEVICE    Device
    )
/*++

Routine Description:

    Callback when interrupts are disabled.

Arguments:

    Interupt  - Handle to WDFINTERRUPT Object.
    Device    - WDFDEVICE object

Return Value:

    NTSTATUS
--*/
{
    PDEVICE_EXTENSION  DevExt;

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_INTERRUPT,
                "MCAPEvtInterruptDisable: Interrupt 0x%p, Device 0x%p\n",
                Interrupt, Device);

    DevExt  = MCAPGetDeviceContext(WdfInterruptGetDevice(Interrupt));

    return STATUS_SUCCESS;
}
