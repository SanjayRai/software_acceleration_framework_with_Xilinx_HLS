/********************************************************************
*Copyright (C) 2014 � 2015 Xilinx, Inc.  All rights reserved.
*
*Permission is hereby granted, free of charge, to any person obtaining
*a copy of this software and associated documentation files (the
*"Software"), to deal in the Software without restriction, including
*without limitation the rights to use, copy, modify, merge, publish,
*distribute, sublicense, and/or sell copies of the Software, and to
*permit persons to whom the Software is furnished to do so, subject to
*the following conditions:
*
*The above copyright notice and this permission notice shall be 
*included in all copies or substantial portions of the Software.
*
*Use of the Software is limited solely to applications: (a) running 
*on a Xilinx device, or (b) that interact with a Xilinx device 
*through a bus or interconnect.  
*
*THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*NONINFRINGEMENT. IN NO EVENT SHALL XILINX BE LIABLE FOR ANY CLAIM, 
*DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
*OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
*OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*Except as contained in this notice, the name of the Xilinx shall
*not be used in advertising or otherwise to promote the sale, use or
*other dealings in this Software without prior written authorization
*from Xilinx.
*********************************************************************/

#include "precomp.h"

#include "mcapIoctl.tmh"


//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
VOID
MCAPEvtIoDeviceControl(
    IN WDFQUEUE    Queue,
    IN WDFREQUEST  Request,
    IN size_t      OutputBufferLength,
    IN size_t      InputBufferLength,
    IN ULONG       IoControlCode
    )
/*++

Routine Description:

    This callback function processes a specified device I/O control request.

Arguments:

    Queue - Handle to the IOCTL queue.
    Request - Handle to a IOCTL request.

    OutputBufferLength - length of the request's output buffer,
    InputBufferLength - length of the request's input buffer,

    IoControlCode - The IOCTL Code of the request.

Return Value:

    VOID

--*/
{
    NTSTATUS                NtStatus = STATUS_UNSUCCESSFUL;
    PDEVICE_EXTENSION       DevExt;
    PMCAP_IOCTL_REQ_RES     inBuf = NULL, outBuf = NULL; // pointer to Input and output buffer
    size_t                  bufSize;

    UNREFERENCED_PARAMETER(OutputBufferLength);
    UNREFERENCED_PARAMETER(InputBufferLength);

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_IOCTLS,
		"--> MCAPEvtIoDeviceControl: Request %p", Request);

	//
    // Get the DevExt from the Queue Handle
    //
    DevExt = MCAPGetDeviceContext(WdfIoQueueGetDevice(Queue));

	// We do not want any other operation to interrupt our operation
	WdfSpinLockAcquire(DevExt->ExOperationLock);

	if(DevExt->ResetInProgress)
	{
		NtStatus = STATUS_UNSUCCESSFUL;
		TraceEvents(TRACE_LEVEL_ERROR, DBG_IOCTLS,
                    "Device Reset in Progress : %!STATUS!", NtStatus);
		goto CleanUp;
	}

	switch (IoControlCode)
    {
		case IOCTL_MCAP_FULL_RESET:
			{
				NtStatus = MCAPFullReset(DevExt);
				break;
			}
		case IOCTL_MCAP_MODULE_RESET:
			{
				NtStatus = MCAPModuleReset(DevExt);
				break;
			}
		case IOCTL_MCAP_RESET:
			{
				NtStatus = MCAPReset(DevExt);
				break;
			}
		case IOCTL_READ_STATUS_REG:
			{
				NtStatus = WdfRequestRetrieveOutputBuffer(Request, 0, &((PVOID)outBuf), &bufSize);
				if(!NT_SUCCESS(NtStatus))
				{
					NtStatus = STATUS_INSUFFICIENT_RESOURCES;
					break;
				}

				ASSERT(bufSize == OutputBufferLength);

				outBuf->mcapres.mcapreadstatreg.RegValue = ReadMCAP_StatusReg(DevExt);

				bufSize = sizeof(ULONG);

				WdfRequestSetInformation(Request,
						OutputBufferLength < bufSize? OutputBufferLength:bufSize);

				NtStatus = STATUS_SUCCESS;
				break;
			}
		case IOCTL_READ_CONTROL_REG:
			{
				NtStatus = WdfRequestRetrieveOutputBuffer(Request, 0, &((PVOID)outBuf), &bufSize);
				if(!NT_SUCCESS(NtStatus))
				{
					NtStatus = STATUS_INSUFFICIENT_RESOURCES;
					break;
				}

				ASSERT(bufSize == OutputBufferLength);

				outBuf->mcapres.mcapreadctrlreg.RegValue = ReadMCAP_ControlReg(DevExt);

				bufSize = sizeof(ULONG);

				WdfRequestSetInformation(Request,
						OutputBufferLength < bufSize? OutputBufferLength:bufSize);

				NtStatus = STATUS_SUCCESS;
				break;
			}
		case IOCTL_WRITE_CONTROL_REG:
			{
				NtStatus = WdfRequestRetrieveInputBuffer(Request, 0, &((PVOID)inBuf), &bufSize);
				if(!NT_SUCCESS(NtStatus))
				{
					NtStatus = STATUS_INSUFFICIENT_RESOURCES;
					break;
				}

				ASSERT(bufSize == InputBufferLength);

				WriteMCAP_ControlReg(DevExt, inBuf->mcapreq.mcapwritectrlreg.RegValue);

				NtStatus = STATUS_SUCCESS;
				break;
			}
		case IOCTL_WRITE_MCAP_REG:
			{
				NtStatus = WdfRequestRetrieveInputBuffer(Request, 0, &((PVOID)inBuf), &bufSize);
				if(!NT_SUCCESS(NtStatus))
				{
					NtStatus = STATUS_INSUFFICIENT_RESOURCES;
					break;
				}

				ASSERT(bufSize == InputBufferLength);

				// Check Write Protect for the Registers
				if((inBuf->mcapreq.mcapwritereg.RegIndex == CTRL_REG_INDEX) || (inBuf->mcapreq.mcapwritereg.RegIndex == DATA_REG_INDEX))
				{
					WriteMCAP_Registers(DevExt,
						inBuf->mcapreq.mcapwritereg.RegIndex,
						inBuf->mcapreq.mcapwritereg.RegValue);

					TraceEvents(TRACE_LEVEL_VERBOSE, DBG_IOCTLS, "RegIndex:0x%x, Value:0x%08x\n", 
						inBuf->mcapreq.mcapwritereg.RegIndex, inBuf->mcapreq.mcapwritereg.RegValue);

					NtStatus = STATUS_SUCCESS;
				}
				else
				{
					TraceEvents(TRACE_LEVEL_ERROR, DBG_IOCTLS, "RegIndex:0x%x is read only\n", 
						inBuf->mcapreq.mcapwritereg.RegIndex);

					NtStatus = STATUS_ACCESS_DENIED;
				}
				
				break;
			}
		case IOCTL_READ_MCAP_REG:
			{
				ULONG Value;

				NtStatus = WdfRequestRetrieveInputBuffer(Request, 0, &((PVOID)inBuf), &bufSize);
				if(!NT_SUCCESS(NtStatus))
				{
					NtStatus = STATUS_INSUFFICIENT_RESOURCES;
					break;
				}

				ASSERT(bufSize == InputBufferLength);

				Value = ReadMCAP_Registers(DevExt,
					inBuf->mcapreq.mcapreadreg.RegIndex);

				TraceEvents(TRACE_LEVEL_VERBOSE, DBG_IOCTLS, "RegIndex:0x%x, Value:0x%08x\n", inBuf->mcapreq.mcapreadreg.RegIndex, Value);

				NtStatus = WdfRequestRetrieveOutputBuffer(Request, 0, &((PVOID)outBuf), &bufSize);
				if(!NT_SUCCESS(NtStatus))
				{
					NtStatus = STATUS_INSUFFICIENT_RESOURCES;
					break;
				}

				ASSERT(bufSize == OutputBufferLength);

				outBuf->mcapres.mcapreadreg.RegValue = Value;

				bufSize = sizeof(ULONG);

				WdfRequestSetInformation(Request,
						OutputBufferLength < bufSize? OutputBufferLength:bufSize);

				NtStatus = STATUS_SUCCESS;
				break;
			}
		case IOCTL_WRITE_PCI_CONFIG_REG:
			{
				NtStatus = WdfRequestRetrieveInputBuffer(Request, 0, &((PVOID)inBuf), &bufSize);
				if(!NT_SUCCESS(NtStatus))
				{
					NtStatus = STATUS_INSUFFICIENT_RESOURCES;
					break;
				}

				ASSERT(bufSize == InputBufferLength);

				// Acquire Lock
				WdfSpinLockAcquire(DevExt->RegisterLock);

				bufSize = WriteMCAP_PCIRegisters(DevExt,
							inBuf->mcapreq.pciconfigwrite.RegIndex,
							(PVOID)(inBuf->mcapreq.pciconfigwrite.Buffer),
							inBuf->mcapreq.pciconfigwrite.Length);

				if(bufSize)
				{
					NtStatus = STATUS_SUCCESS;
				}
				else
				{
					NtStatus = STATUS_INSUFFICIENT_RESOURCES;
				}

				// Release Lock
				WdfSpinLockRelease(DevExt->RegisterLock);

				break;
			}
		case IOCTL_READ_PCI_CONFIG_REG:
			{
				ULONG RegIndex;
				ULONG Length;

				//
				// For bufffered ioctls WdfRequestRetrieveInputBuffer &
				// WdfRequestRetrieveOutputBuffer return the same buffer
				// pointer (Irp->AssociatedIrp.SystemBuffer), so read the
				// content of the buffer before writing to it.
				//
				NtStatus = WdfRequestRetrieveInputBuffer(Request, 0, &((PVOID)inBuf), &bufSize);
				if(!NT_SUCCESS(NtStatus))
				{
					NtStatus = STATUS_INSUFFICIENT_RESOURCES;
					break;
				}

				ASSERT(bufSize == InputBufferLength);

				RegIndex = inBuf->mcapreq.pciconfigread.RegIndex;
				Length = inBuf->mcapreq.pciconfigread.Length;

				NtStatus = WdfRequestRetrieveOutputBuffer(Request, 0, &((PVOID)outBuf), &bufSize);
				if(!NT_SUCCESS(NtStatus))
				{
					NtStatus = STATUS_INSUFFICIENT_RESOURCES;
					break;
				}

				ASSERT(bufSize == OutputBufferLength);

				bufSize = ReadMCAP_PCIRegisters(DevExt,
							RegIndex,
							(PVOID)(outBuf->mcapres.pciconfigread.Buffer),
							Length);

				//
				// Assign the length of the data copied to IoStatus.Information
				// of the request and complete the request.
				//

				// This request has variable length
				WdfRequestSetInformation(Request, OutputBufferLength);

				if(bufSize)
				{
					outBuf->mcapres.pciconfigread.Length = Length;
					outBuf->mcapres.pciconfigread.RegIndex = RegIndex;

					NtStatus = STATUS_SUCCESS;
				}
				else
				{
					outBuf->mcapres.pciconfigread.Length = 0;
					outBuf->mcapres.pciconfigread.RegIndex = RegIndex;

					NtStatus = STATUS_INSUFFICIENT_RESOURCES;
				}

				//
				// When the request is completed the content of the SystemBuffer
				// is copied to the User output buffer and the SystemBuffer is
				// is freed.
				//

			   break;
			}

		case IOCTL_WRITE_IOBAR_REG:
			{
				NtStatus = WdfRequestRetrieveInputBuffer(Request, 0, &((PVOID)inBuf), &bufSize);
				if(!NT_SUCCESS(NtStatus))
				{
					NtStatus = STATUS_INSUFFICIENT_RESOURCES;
					break;
				}

				ASSERT(bufSize == InputBufferLength);

				if(DevExt->PortBase)
				{
					WriteIOBAR_Registers(DevExt,
						inBuf->mcapreq.mcapwriteiobarreg.RegIndex,
						inBuf->mcapreq.mcapwriteiobarreg.RegValue);

					TraceEvents(TRACE_LEVEL_VERBOSE, DBG_IOCTLS, "RegIndex:0x%x, Value:0x%08x\n", 
						inBuf->mcapreq.mcapwriteiobarreg.RegIndex, inBuf->mcapreq.mcapwriteiobarreg.RegValue);
					NtStatus = STATUS_SUCCESS;
				}
				else
				{
					NtStatus = STATUS_ACCESS_DENIED;
				}
				
				break;
			}
		case IOCTL_READ_IOBAR_REG:
			{
				ULONG Value;

				NtStatus = WdfRequestRetrieveInputBuffer(Request, 0, &((PVOID)inBuf), &bufSize);
				if(!NT_SUCCESS(NtStatus))
				{
					NtStatus = STATUS_INSUFFICIENT_RESOURCES;
					break;
				}

				ASSERT(bufSize == InputBufferLength);

				if(DevExt->PortBase)
				{
					Value = ReadIOBAR_Registers(DevExt,
						inBuf->mcapreq.mcapreadiobarreg.RegIndex);

					TraceEvents(TRACE_LEVEL_VERBOSE, DBG_IOCTLS, "RegIndex:0x%x, Value:0x%08x\n", inBuf->mcapreq.mcapreadiobarreg.RegIndex, Value);

					NtStatus = WdfRequestRetrieveOutputBuffer(Request, 0, &((PVOID)outBuf), &bufSize);
					if(!NT_SUCCESS(NtStatus))
					{
						NtStatus = STATUS_INSUFFICIENT_RESOURCES;
						break;
					}

					ASSERT(bufSize == OutputBufferLength);

					outBuf->mcapres.mcapreadiobarreg.RegValue = Value;

					bufSize = sizeof(ULONG);

					WdfRequestSetInformation(Request,
							OutputBufferLength < bufSize? OutputBufferLength:bufSize);

					NtStatus = STATUS_SUCCESS;
				}
				else
				{
					NtStatus = STATUS_ACCESS_DENIED;
				}
				
				break;
			}

		case IOCTL_WRITE_MEMBAR_REG:
			{
				NtStatus = WdfRequestRetrieveInputBuffer(Request, 0, &((PVOID)inBuf), &bufSize);
				if(!NT_SUCCESS(NtStatus))
				{
					NtStatus = STATUS_INSUFFICIENT_RESOURCES;
					break;
				}

				ASSERT(bufSize == InputBufferLength);

				if(DevExt->RegsBase)
				{
					WriteMEMBAR_Registers(DevExt,
						inBuf->mcapreq.mcapwritemembarreg.RegIndex,
						inBuf->mcapreq.mcapwritemembarreg.RegValue);

					TraceEvents(TRACE_LEVEL_VERBOSE, DBG_IOCTLS, "RegIndex:0x%x, Value:0x%08x\n", 
						inBuf->mcapreq.mcapwritemembarreg.RegIndex, inBuf->mcapreq.mcapwritemembarreg.RegValue);
					NtStatus = STATUS_SUCCESS;
				}
				else
				{
					NtStatus = STATUS_ACCESS_DENIED;
				}
				
				break;
			}
		case IOCTL_READ_MEMBAR_REG:
			{
				ULONG Value;

				NtStatus = WdfRequestRetrieveInputBuffer(Request, 0, &((PVOID)inBuf), &bufSize);
				if(!NT_SUCCESS(NtStatus))
				{
					NtStatus = STATUS_INSUFFICIENT_RESOURCES;
					break;
				}

				ASSERT(bufSize == InputBufferLength);

				if(DevExt->RegsBase)
				{
					Value = ReadMEMBAR_Registers(DevExt,
						inBuf->mcapreq.mcapreadmembarreg.RegIndex);

					TraceEvents(TRACE_LEVEL_VERBOSE, DBG_IOCTLS, "RegIndex:0x%x, Value:0x%08x\n", inBuf->mcapreq.mcapreadmembarreg.RegIndex, Value);

					NtStatus = WdfRequestRetrieveOutputBuffer(Request, 0, &((PVOID)outBuf), &bufSize);
					if(!NT_SUCCESS(NtStatus))
					{
						NtStatus = STATUS_INSUFFICIENT_RESOURCES;
						break;
					}

					ASSERT(bufSize == OutputBufferLength);

					outBuf->mcapres.mcapreadmembarreg.RegValue = Value;

					bufSize = sizeof(ULONG);

					WdfRequestSetInformation(Request,
							OutputBufferLength < bufSize? OutputBufferLength:bufSize);

					NtStatus = STATUS_SUCCESS;
				}
				else
				{
					NtStatus = STATUS_ACCESS_DENIED;
				}
				
				break;
			}

		default:
			{
				//
				// Invalid I/O control code.
				//
				NtStatus = STATUS_INVALID_DEVICE_REQUEST;
				TraceEvents(TRACE_LEVEL_ERROR, DBG_IOCTLS, "ERROR: unrecognized IOCTL %x\n", IoControlCode);
				ASSERTMSG(FALSE, "Invalid IOCTL request\n");
				break;
			}
    }

CleanUp:

	WdfSpinLockRelease(DevExt->ExOperationLock);

    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_IOCTLS,
                "<-- MCAPEvtIoDeviceControl: %!STATUS!", NtStatus);

	WdfRequestComplete(Request, NtStatus);

	return;
}
