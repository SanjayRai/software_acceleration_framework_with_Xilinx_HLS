/********************************************************************
*Copyright (C) 2014 � 2015 Xilinx, Inc.  All rights reserved.
*
*Permission is hereby granted, free of charge, to any person obtaining
*a copy of this software and associated documentation files (the
*"Software"), to deal in the Software without restriction, including
*without limitation the rights to use, copy, modify, merge, publish,
*distribute, sublicense, and/or sell copies of the Software, and to
*permit persons to whom the Software is furnished to do so, subject to
*the following conditions:
*
*The above copyright notice and this permission notice shall be 
*included in all copies or substantial portions of the Software.
*
*Use of the Software is limited solely to applications: (a) running 
*on a Xilinx device, or (b) that interact with a Xilinx device 
*through a bus or interconnect.  
*
*THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*NONINFRINGEMENT. IN NO EVENT SHALL XILINX BE LIABLE FOR ANY CLAIM, 
*DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
*OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
*OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*Except as contained in this notice, the name of the Xilinx shall
*not be used in advertising or otherwise to promote the sale, use or
*other dealings in this Software without prior written authorization
*from Xilinx.
*********************************************************************/

#include "precomp.h"

#include "mcapHW.tmh"


//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------

ULONG ReadMCAP_PCIRegisters(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG Register,
	IN  PVOID PValue,
	IN  ULONG Length
	)
/*++
Routine Description:

    This routine Reads the PCI Config Data.

Arguments:

    DevExt		Pointer to the Device Extension
	Register	Offset from which the data to be read
	PValue		Buffer into which the data to be read
	Length		Size of the buffer and also 
				the size to be read from the PCI Config space.

Return Value:

     ULONG Bytes Actually Read

--*/
{
	ULONG bytesRead = 0;

	if(!DevExt)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"DevExt is NULL, Reading PCI Config Space for Register:0x%x, Length:%d", Register, Length);

		return bytesRead;
	}

	if(!PValue)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"PValue is NULL, Reading PCI Config Space for Register:0x%x, Length:%d", Register, Length);

		return bytesRead;
	}

	bytesRead = DevExt->BusInterface.GetBusData(
                        DevExt->BusInterface.Context,
						PCI_WHICHSPACE_CONFIG, //READ
                        PValue,
                        Register,
                        Length);

	if(!bytesRead)
	{
		// Unsuccessful Read
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"PCI Config Space Read Failed for Register:0x%x, Length:%d", Register, Length);

		return bytesRead;
	}

	return bytesRead;
}

ULONG WriteMCAP_PCIRegisters(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG Register,
	IN  PVOID PValue,
	IN  ULONG Length
	)
/*++
Routine Description:

    This routine Writes the PCI Config Data.

Arguments:

    DevExt		Pointer to the Device Extension
	Register	Offset from which the data to be Written
	PValue		Buffer from which the data to be wriiten
	Length		Size of the buffer and also 
				the size to be written to the PCI Config space.

Return Value:

     ULONG Bytes Actually Wrote

--*/{
	ULONG bytesWritten = 0;

	if(!DevExt)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"DevExt is NULL, Writing PCI Config Space for Register:0x%x, Length:%d", Register, Length);

		return bytesWritten;
	}

	if(!PValue)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"PValue is NULL, Writing PCI Config Space for Register:0x%x, Length:%d", Register, Length);

		return bytesWritten;
	}

	bytesWritten = DevExt->BusInterface.SetBusData(
                    DevExt->BusInterface.Context,
                    PCI_WHICHSPACE_CONFIG, //WRITE
                    PValue,
                    Register,
                    Length);

	if(!bytesWritten)
	{
		// Unsuccessful Write
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"PCI Config Space Write Failed for Register:0x%x, Length:%d", Register, Length);

		return bytesWritten;
	}

	return bytesWritten;
}

ULONG
ReadMCAP_ReadDataRegisters(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG RegIndex
	)
/*++
Routine Description:

    This routine Reads the MCAP's ReadData Register.

Arguments:

    DevExt		Pointer to the Device Extension
	Register	Offset of the ReadData Register to be read

Return Value:

     ULONG		Data Read from the ReadData Register Sepcified by the Offset

--*/
{
	ULONG Value = 0;
	CTRL_REG CtrlReg;
	CTRL_REG OldCtrlReg;
	STAT_REG StatReg;
	ULONG LoopCount = 0;

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_READ,	"ReadMCAP_ReadDataRegisters -->");

	if(!DevExt)
	{
        TraceEvents(TRACE_LEVEL_ERROR, DBG_READ,
			"ReadMCAP_ReadDataRegisters: DevExt is NULL");

		Value = 0;
		return Value;
	}

/*
	Steps to Perform this Operation
	-	Perform a �Control and Status Register Read�
		.	If (Configure MCAP Request by Configure = 1)
			@	Modify the appropriate values in the control register data structure
				*	MCAP Mode = 1
				*	MCAP Configure In Use by PCIe = 1
			@	Poll Configure MCAP Request by Configure, If this does not got to 0
				*	Perform a �Control Register Write� operation to restore the original values
				*	 issue an error and return
	-	Modify the appropriate values in the control register data structure
		.	MCAP Mode = 1
		.	MCAP Register Read = 1
		.	MCAP Reset = 0
		.	MCAP Module Reset = 0
		.	MCAP Configure In Use by PCIe = 1
		.	Configure MCAP Design Switch = <Retain Value>
		.	Data Register Protect = <Retain Value>
	-	Verify current contents of the control and status registers
		.	If (MCAP_Error=1) issue an error and return
		.	If (MCAP_Write_FIFO_Overflow=1) issue an error and return
		.	If (MCAP_Register_Read_Complete=0) issue an error and return
		.	If (MCAP_Register_Read_Count = 0) issue an error and return
		.	If (MCAP_Register_Read_Count > 4 issue an error, but continue processing
	-	Perform �Register Reads� from the MCAP Read Data[0-3] Registers as required
		.	If ((MCAP_Register_Read_Complete=1) then MCAP_Register_Read_Data0 should be returned.
		.	If ((MCAP_Register_Read_Complete=2) then MCAP_Register_Read_Data0 and  MCAP_Register_Read_Data1 should be returned.
		.	If ((MCAP_Register_Read_Complete=3) then MCAP_Register_Read_Data0, MCAP_Register_Read_Data1, and MCAP_Register_Read_Data2 should be returned.
		.	If ((MCAP_Register_Read_Complete >= 4) then MCAP_Register_Read_Data0, MCAP_Register_Read_Data1, MCAP_Register_Read_Data2, and MCAP_Register_Read_Data3 should be returned.
	-	Perform a �Control Register Write� operation to restore the original values
	-	Terminate with appropriate messages and status
*/
	// Perform Status Read
	StatReg.regval = ReadMCAP_StatusReg(DevExt);
	if (StatReg.bits.CfgMCAPRequestByCfg == 1)
	{
		// Perform Control Read
		OldCtrlReg.regval = CtrlReg.regval = ReadMCAP_ControlReg(DevExt);
		CtrlReg.bits.MCAPMode = 1;
		CtrlReg.bits.CfgMCAPInUseByPCIe = 1;
		// Perform Control Write
		WriteMCAP_ControlReg(DevExt, CtrlReg.regval);

		// Perform Status Read
		StatReg.regval = ReadMCAP_StatusReg(DevExt);
		while(StatReg.bits.CfgMCAPRequestByCfg)
		{
			if(LoopCount > MAX_LOOP_COUNT)
			{
				// Error
				TraceEvents(TRACE_LEVEL_ERROR, DBG_READ,
					"ReadMCAP_ReadDataRegisters: Configure MCAP Request by Configure(CfgMCAPRequestByCfg) Bit is Not Resetting.");

				// Restore Original Values
				WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

				// Return Error
				Value = 0;
				return Value;
			}		

			LoopCount++;
			StatReg.regval = ReadMCAP_StatusReg(DevExt);
		}
	}

	// Read Operation
	// Perform Control Read
	OldCtrlReg.regval = CtrlReg.regval = ReadMCAP_ControlReg(DevExt);
	CtrlReg.bits.MCAPMode = 1;
	CtrlReg.bits.MCAPRegisterRead = 1;
	CtrlReg.bits.MCAPReset = 0;
	CtrlReg.bits.MCAPModuleReset = 0;
	CtrlReg.bits.CfgMCAPInUseByPCIe = 1;
	// Perform Control Write for Read operation
	WriteMCAP_ControlReg(DevExt, CtrlReg.regval);

	// Perform Status Read
	StatReg.regval = ReadMCAP_StatusReg(DevExt);

	if(StatReg.bits.MCAPError == 1)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_READ,
			"ReadMCAP_ReadDataRegisters: MCAPError Bit is Set.");

		// Restore Original Values
		WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

		Value = 0;
		return Value;
	}

	if(StatReg.bits.MCAPWriteFifoOverflow == 1)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_READ,
			"ReadMCAP_ReadDataRegisters: MCAPWriteFifoOverflow Bit is Set.");

		// Restore Original Values
		WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

		Value = 0;
		return Value;
	}

	if(StatReg.bits.MCAPRegReadComplete == 0)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_READ,
			"ReadMCAP_ReadDataRegisters: MCAPRegReadComplete Bit is Not Set.");

		// Acquire Lock
		WdfSpinLockAcquire(DevExt->RegisterLock);

		// Read MCAP Registers
		ReadMCAP_PCIRegisters(
						DevExt,
						DevExt->MCAP_Register_Base+(RegIndex*MCAP_REGISTER_SIZE), 
						&Value,
						MCAP_REGISTER_SIZE
						);

		// Release Lock
		WdfSpinLockRelease(DevExt->RegisterLock);

		// Restore Original Values
		WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

		return Value;
	}

	if(StatReg.bits.MCAPRegReadCount == 0)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_READ,
			"ReadMCAP_ReadDataRegisters: MCAPRegReadCount is 0.");

		// Acquire Lock
		WdfSpinLockAcquire(DevExt->RegisterLock);

		// Read MCAP Registers
		ReadMCAP_PCIRegisters(
						DevExt,
						DevExt->MCAP_Register_Base+(RegIndex*MCAP_REGISTER_SIZE), 
						&Value,
						MCAP_REGISTER_SIZE
						);

		// Release Lock
		WdfSpinLockRelease(DevExt->RegisterLock);

		// Restore Original Values
		WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

		return Value;
	}

	if(StatReg.bits.MCAPRegReadCount > MCAP_MAX_READ_REGS)
	{
		// Error But OK to Proceed
		TraceEvents(TRACE_LEVEL_ERROR, DBG_READ,
			"ReadMCAP_ReadDataRegisters: MCAPRegReadCount is more than %d(MCAP_MAX_READ_REGS).", MCAP_MAX_READ_REGS);
	}

	// Acquire Lock
	WdfSpinLockAcquire(DevExt->RegisterLock);

	// Read MCAP Registers
	ReadMCAP_PCIRegisters(
					DevExt,
					DevExt->MCAP_Register_Base+(RegIndex*MCAP_REGISTER_SIZE), 
					&Value,
					MCAP_REGISTER_SIZE
					);

	// Release Lock
	WdfSpinLockRelease(DevExt->RegisterLock);

	// Restore Original Values
	WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_READ,	"<-- ReadMCAP_ReadDataRegisters");
	return Value;
}

ULONG ReadMCAP_Registers(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG RegIndex
	)
/*++
Routine Description:

    This routine Reads the MCAP's Registers.

Arguments:

    DevExt		Pointer to the Device Extension
	Register	Offset of the  Register to be read

Return Value:

     ULONG		Data Read from the Specified MCAP Register

--*/
{
	ULONG Value = 0;

	if(!DevExt)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"DevExt is NULL, Reading MCAP Register:0x%x", RegIndex);

		return 0;
	}

	// If Reading Read Data Registers, First Initiate the Read
	if(RegIndex>=REGRD1_REG_INDEX && RegIndex<=REGRD4_REG_INDEX)
	{
		Value = ReadMCAP_ReadDataRegisters(DevExt, RegIndex);
	}
	else
	{
		// Acquire Lock
		WdfSpinLockAcquire(DevExt->RegisterLock);

		// Read MCAP Registers
		ReadMCAP_PCIRegisters(
						DevExt,
						DevExt->MCAP_Register_Base+(RegIndex*MCAP_REGISTER_SIZE), 
						&Value,
						MCAP_REGISTER_SIZE
						);
		// Release Lock
		WdfSpinLockRelease(DevExt->RegisterLock);
	}

	TraceEvents(TRACE_LEVEL_VERBOSE, DBG_HW_ACCESS,
		"ReadMCAP_Registers: Register:%d, Offset:0x%x, Value:0x%08x", RegIndex, 
		DevExt->MCAP_Register_Base+(RegIndex*MCAP_REGISTER_SIZE),
		Value);


	return Value;
}

VOID WriteMCAP_Registers(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG RegIndex,
	IN  ULONG Value
	)
/*++
Routine Description:

    This routine Writes to the MCAP's Registers.

Arguments:

    DevExt		Pointer to the Device Extension
	Register	Offset of the  Register to be written
	Value		Value to be written into the specified Register.

Return Value:

     VOID

--*/
{
	if(!DevExt)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"DevExt is NULL, Writing MCAP Register:0x%x", RegIndex);

		return;
	}

	// Acquire Lock
	WdfSpinLockAcquire(DevExt->RegisterLock);

	// Write MCAP Registers
	WriteMCAP_PCIRegisters(
		DevExt,
		DevExt->MCAP_Register_Base+(RegIndex*MCAP_REGISTER_SIZE), 
		&Value,
		MCAP_REGISTER_SIZE
		);

	TraceEvents(TRACE_LEVEL_VERBOSE, DBG_HW_ACCESS,
		"WriteMCAP_Registers: Register:%d, Offset:0x%x, Value:0x%08x", RegIndex, 
		DevExt->MCAP_Register_Base+(RegIndex*MCAP_REGISTER_SIZE),
		Value);

	// Release Lock
	WdfSpinLockRelease(DevExt->RegisterLock);
}

VOID WriteMCAP_ControlReg(
    IN  PDEVICE_EXTENSION DevExt,
	ULONG CtrlRegVal
	)
/*++
Routine Description:

    This routine Writes to the MCAP's Control Registers.

Arguments:

    DevExt		Pointer to the Device Extension
	Value		Value to be written into the Control Register.

Return Value:

     VOID

--*/
{
	if(!DevExt)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"DevExt is NULL, Writing MCAP Control Register");

		return;
	}

	WriteMCAP_Registers(DevExt, CTRL_REG_INDEX, CtrlRegVal);
}

ULONG ReadMCAP_ControlReg(
    IN  PDEVICE_EXTENSION DevExt
	)
/*++
Routine Description:

    This routine Reads from the MCAP's Control Registers.

Arguments:

    DevExt		Pointer to the Device Extension

Return Value:

     ULONG		Value read from the Control Register.

--*/
{
	if(!DevExt)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"DevExt is NULL, Reading MCAP Control Register");

		return 0;
	}

	return ReadMCAP_Registers(DevExt, CTRL_REG_INDEX);
}

ULONG ReadMCAP_StatusReg(
    IN  PDEVICE_EXTENSION DevExt
	)
/*++
Routine Description:

    This routine Reads from the MCAP's Status Registers.

Arguments:

    DevExt		Pointer to the Device Extension

Return Value:

     ULONG		Value read from the Status Register.

--*/
{
	if(!DevExt)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"DevExt is NULL, Writing MCAP Status Register");

		return 0;
	}

	return ReadMCAP_Registers(DevExt, STAT_REG_INDEX);
}

NTSTATUS MCAPReset(
    IN  PDEVICE_EXTENSION DevExt
				   )
/*++
Routine Description:

    This routine does the reset of the MCAP Device

Arguments:

    DevExt		Pointer to the Device Extension

Return Value:

     NTSTATUS	NTSTATUS of the Reset.

--*/
{
	NTSTATUS NtStatus = STATUS_UNSUCCESSFUL;
	CTRL_REG CtrlReg;
	CTRL_REG OldCtrlReg = {0};
	STAT_REG StatReg;
	ULONG LoopCount = 0;

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_HW_ACCESS, "MCAPReset -->");

	if(!DevExt)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"DevExt is NULL in MCAPReset");

		NtStatus = STATUS_UNSUCCESSFUL;

		TraceEvents(TRACE_LEVEL_INFORMATION, DBG_HW_ACCESS, "--> MCAPReset");
		return NtStatus;
	}

	DevExt->ResetInProgress = TRUE;

	/*
		Steps to Perform this Operation
		-	Perform a �Control and Status Register Read�
			.	If (Configure MCAP Request by Configure = 1)
				@	Modify the appropriate values in the control register data structure
					*	MCAP Mode = 1
					*	MCAP Configure In Use by PCIe = 1
				@	Poll Configure MCAP Request by Configure, If this does not got to 0
					*	Perform a �Control Register Write� operation to restore the original values
					*	Issue an error and return
		-	Modify the appropriate values in the control register data structure
			.	MCAP Mode = 1
			.	MCAP Reset = 1
			.	MCAP Configure In Use by PCIe = 1
			.	All other bits remain in their previous state
		-	Perform a �Control Register Write� operation to update these values
		-	Perform a �Control and Status Register Read�
		-	Verify the current contents of the control and status registers
			.	If (MCAP_Error = 1) issue an error
			.	If (MCAP_Reset = 0) issue an error
		-	Perform a �Control Register Write� operation to restore the original values
		-	Terminate with appropriate messages and status
	
	*/

	// Perform Status Read
	StatReg.regval = ReadMCAP_StatusReg(DevExt);
	if (StatReg.bits.CfgMCAPRequestByCfg == 1)
	{
		// Perform Control Read
		OldCtrlReg.regval = CtrlReg.regval = ReadMCAP_ControlReg(DevExt);
		CtrlReg.bits.MCAPMode = 1;
		CtrlReg.bits.CfgMCAPInUseByPCIe = 1;
		// Perform Control Write
		WriteMCAP_ControlReg(DevExt, CtrlReg.regval);

		// Perform Status Read
		StatReg.regval = ReadMCAP_StatusReg(DevExt);
		while(StatReg.bits.CfgMCAPRequestByCfg)
		{
			if(LoopCount > MAX_LOOP_COUNT)
			{
				TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
					"MCAPReset: Configure MCAP Request by Configure(CfgMCAPRequestByCfg) Bit is Not Resetting.");

				// Error
				// Restore Original Values
				WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

				// Return Error
				NtStatus = STATUS_UNSUCCESSFUL;
				goto CleanUp;
			}

			LoopCount++;
			StatReg.regval = ReadMCAP_StatusReg(DevExt);
		}
	}

	// Reset Operation
	// Perform Control Read
	OldCtrlReg.regval = CtrlReg.regval = ReadMCAP_ControlReg(DevExt);
	CtrlReg.bits.MCAPMode = 1;
	CtrlReg.bits.MCAPReset = 1;
	CtrlReg.bits.CfgMCAPInUseByPCIe = 1;
	// Perform Control Write for Reset
	WriteMCAP_ControlReg(DevExt, CtrlReg.regval);

	// Perform Control Read
	CtrlReg.regval = ReadMCAP_ControlReg(DevExt);

	// Perform Status Read
	StatReg.regval = ReadMCAP_StatusReg(DevExt);

	if(!CtrlReg.bits.MCAPReset)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"MCAPReset: MCAPReset Bit is Not Set.");

		// Restore Original Values
		WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

		// Return Error
		NtStatus = STATUS_UNSUCCESSFUL;
		goto CleanUp;
	}

	if(StatReg.bits.MCAPError)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"MCAPReset: MCAPError Bit is Set.");

		// Restore Original Values
		WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

		// Return Error
		NtStatus = STATUS_UNSUCCESSFUL;
		goto CleanUp;
	}

	NtStatus = STATUS_SUCCESS;
	
CleanUp:
	// Restore Original Values
	WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

	DevExt->ResetInProgress = FALSE;

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_HW_ACCESS, "--> MCAPReset");
	return NtStatus;
}

NTSTATUS MCAPModuleReset(
    IN  PDEVICE_EXTENSION DevExt
				   )
/*++
Routine Description:

    This routine does the Module reset of the MCAP Device

Arguments:

    DevExt		Pointer to the Device Extension

Return Value:

     NTSTATUS	NTSTATUS of the Reset.

--*/
{
	NTSTATUS NtStatus = STATUS_UNSUCCESSFUL;
	CTRL_REG CtrlReg;
	CTRL_REG OldCtrlReg = {0};
	STAT_REG StatReg;
	ULONG LoopCount = 0;

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_HW_ACCESS, "MCAPModuleReset -->");

	if(!DevExt)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"DevExt is NULL in MCAPModuleReset");

		NtStatus = STATUS_UNSUCCESSFUL;

		TraceEvents(TRACE_LEVEL_INFORMATION, DBG_HW_ACCESS, "<-- MCAPModuleReset");
		return NtStatus;
	}

	DevExt->ResetInProgress = TRUE;

	/*
		Steps to Perform this Operation
		-	Perform a �Control and Status Register Read�
			.	If (Configure MCAP Request by Configure = 1)
					@	Modify the appropriate values in the control register data structure
						*	MCAP Mode = 1
						*	MCAP Configure In Use by PCIe = 1
					@	Poll Configure MCAP Request by Configure, If this does not got to 0
						*	Perform a �Control Register Write� operation to restore the original values
						*	 issue an error and return
		-	Modify the appropriate values in the control register data structure
			.	MCAP Mode = 1
			.	MCAP Module Reset = 1
			.	MCAP Configure In Use by PCIe = 1
			.	All other bits remain in their previous state
		-	Perform a �Control Register Write� operation to update these values
		-	Perform a �Control and Status Register Read�
		-	Verify current contents of the control and status registers
			.	If (MCAP_Error=1) issue an error
			.	If (MCAP_Module_Reset != 1) issue an error
		-	Perform a �Control Register Write� operation to restore the original values
		-	Terminate with appropriate messages and status
	*/

	// Perform Status Read
	StatReg.regval = ReadMCAP_StatusReg(DevExt);
	if (StatReg.bits.CfgMCAPRequestByCfg == 1)
	{
		// Perform Control Read
		OldCtrlReg.regval = CtrlReg.regval = ReadMCAP_ControlReg(DevExt);
		CtrlReg.bits.MCAPMode = 1;
		CtrlReg.bits.CfgMCAPInUseByPCIe = 1;
		// Perform Control Write
		WriteMCAP_ControlReg(DevExt, CtrlReg.regval);

		// Perform Status Read
		StatReg.regval = ReadMCAP_StatusReg(DevExt);
		while(StatReg.bits.CfgMCAPRequestByCfg)
		{
			if(LoopCount > MAX_LOOP_COUNT)
			{
				// Error
				TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
					"MCAPModuleReset: Configure MCAP Request by Configure(CfgMCAPRequestByCfg) Bit is Not Resetting.");

				// Restore Original Values
				WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

				// Return Error
				NtStatus = STATUS_UNSUCCESSFUL;
				goto CleanUp;
			}

			LoopCount++;
			StatReg.regval = ReadMCAP_StatusReg(DevExt);
		}
	}

	// Reset Operation
	// Perform Control Read
	OldCtrlReg.regval = CtrlReg.regval = ReadMCAP_ControlReg(DevExt);
	CtrlReg.bits.MCAPMode = 1;
	CtrlReg.bits.MCAPModuleReset = 1;
	CtrlReg.bits.CfgMCAPInUseByPCIe = 1;
	// Perform Control Write for Reset
	WriteMCAP_ControlReg(DevExt, CtrlReg.regval);

	// Perform Control Read
	CtrlReg.regval = ReadMCAP_ControlReg(DevExt);

	// Perform Status Read
	StatReg.regval = ReadMCAP_StatusReg(DevExt);

	if(!CtrlReg.bits.MCAPModuleReset)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"MCAPModuleReset: MCAPModuleReset Bit is Not Set.");

		// Restore Original Values
		WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

		// Return Error
		NtStatus = STATUS_UNSUCCESSFUL;
		goto CleanUp;
	}

	if(StatReg.bits.MCAPError)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"MCAPModuleReset: MCAPError Bit is Set.");

		// Restore Original Values
		WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

		// Return Error
		NtStatus = STATUS_UNSUCCESSFUL;
		goto CleanUp;
	}

	NtStatus = STATUS_SUCCESS;

CleanUp:
	// Restore Original Values
	WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

	DevExt->ResetInProgress = FALSE;

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_HW_ACCESS, "<-- MCAPModuleReset");
	return NtStatus;
}

NTSTATUS MCAPFullReset(
    IN  PDEVICE_EXTENSION DevExt
				   )
/*++
Routine Description:

    This routine does the full reset (reset + full reset) of the MCAP Device

Arguments:

    DevExt		Pointer to the Device Extension

Return Value:

     NTSTATUS	NTSTATUS of the Reset.

--*/
{
	NTSTATUS NtStatus = STATUS_UNSUCCESSFUL;
	CTRL_REG CtrlReg;
	CTRL_REG OldCtrlReg = {0};
	STAT_REG StatReg;
	ULONG LoopCount = 0;

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_HW_ACCESS, "MCAPFullReset -->");

	if(!DevExt)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"DevExt is NULL in MCAPFullReset");

		NtStatus = STATUS_UNSUCCESSFUL;

		TraceEvents(TRACE_LEVEL_INFORMATION, DBG_HW_ACCESS, "<-- MCAPFullReset");
		return NtStatus;
	}

	DevExt->ResetInProgress = TRUE;

	/*
		Steps to Perform this Operation
			-	Perform a �Control and Status Register Read�
				.	If (Configure MCAP Request by Configure = 1)
					@	Modify the appropriate values in the control register data structure
						*	MCAP Mode = 1
						*	MCAP Configure In Use by PCIe = 1
					@	Poll Configure MCAP Request by Configure, If this does not got to 0
						*	Perform a �Control Register Write� operation to restore the original values
						*	 issue an error and return
			-	Modify the appropriate values in the control register data structure
				.	MCAP Mode = 1
				.	MCAP Reset = 1
				.	MCAP Module Reset = 1
				.	MCAP Configure In Use by PCIe = 1
				.	All other bits remain in their previous state
		-	Perform a �Control Register Write� operation to update these values
		-	Perform a �Control and Status Register Read�
		-	Verify current contents of the control and status registers
			.	If (MCAP_Error=1) issue an error
			.	If (MCAP_Reset != 1) issue an error
			.	If (MCAP_Module_Reset != 1) issue an error
		-	Perform a �Control Register Write� operation to restore the original values
		-	Terminate with appropriate messages and status
	*/

	// Perform Status Read
	StatReg.regval = ReadMCAP_StatusReg(DevExt);
	if (StatReg.bits.CfgMCAPRequestByCfg == 1)
	{
		// Perform Control Read
		OldCtrlReg.regval = CtrlReg.regval = ReadMCAP_ControlReg(DevExt);
		CtrlReg.bits.MCAPMode = 1;
		CtrlReg.bits.CfgMCAPInUseByPCIe = 1;
		// Perform Control Write
		WriteMCAP_ControlReg(DevExt, CtrlReg.regval);

		// Perform Status Read
		StatReg.regval = ReadMCAP_StatusReg(DevExt);
		while(StatReg.bits.CfgMCAPRequestByCfg)
		{
			if(LoopCount > MAX_LOOP_COUNT)
			{
				// Error
				TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
					"MCAPFullReset: Configure MCAP Request by Configure(CfgMCAPRequestByCfg) Bit is Not Resetting.");

				// Restore Original Values
				WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

				// Return Error
				NtStatus = STATUS_UNSUCCESSFUL;
				goto CleanUp;
			}

			LoopCount++;
			StatReg.regval = ReadMCAP_StatusReg(DevExt);
		}
	}

	// Reset Operation
	// Perform Control Read
	OldCtrlReg.regval = CtrlReg.regval = ReadMCAP_ControlReg(DevExt);
	CtrlReg.bits.MCAPMode = 1;
	CtrlReg.bits.MCAPReset = 1;
	CtrlReg.bits.MCAPModuleReset = 1;
	CtrlReg.bits.CfgMCAPInUseByPCIe = 1;
	// Perform Control Write for Reset
	WriteMCAP_ControlReg(DevExt, CtrlReg.regval);

	// Perform Control Read
	CtrlReg.regval = ReadMCAP_ControlReg(DevExt);

	// Perform Status Read
	StatReg.regval = ReadMCAP_StatusReg(DevExt);

	if(!CtrlReg.bits.MCAPModuleReset)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"MCAPFullReset: MCAPModuleReset Bit is Not Set.");

		// Restore Original Values
		WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

		// Return Error
		NtStatus = STATUS_UNSUCCESSFUL;
		goto CleanUp;
	}

	if(!CtrlReg.bits.MCAPReset)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"MCAPFullReset: MCAPReset Bit is Not Set.");

		// Restore Original Values
		WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

		// Return Error
		NtStatus = STATUS_UNSUCCESSFUL;
		goto CleanUp;
	}

	if(StatReg.bits.MCAPError)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"MCAPFullReset: MCAPError Bit is Set.");

		// Restore Original Values
		WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

		// Return Error
		NtStatus = STATUS_UNSUCCESSFUL;
		goto CleanUp;
	}

	NtStatus = STATUS_SUCCESS;

CleanUp:
	// Restore Original Values
	WriteMCAP_ControlReg(DevExt, OldCtrlReg.regval);

	DevExt->ResetInProgress = FALSE;

	TraceEvents(TRACE_LEVEL_INFORMATION, DBG_HW_ACCESS, "<-- MCAPFullReset");
	return NtStatus;
}

ULONG ReadIOBAR_Registers(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG RegIndex
	)
/*++
Routine Description:

    This routine Reads the MCAP's IO BAR Registers.

Arguments:

    DevExt		Pointer to the Device Extension
	Register	Offset of the  Register to be read

Return Value:

     ULONG		Data Read from the Specified MCAP IO BAR Register

--*/
{
	ULONG Value = 0;

	if(!DevExt)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"DevExt is NULL, Reading MCAP IO BAR Register:0x%x", RegIndex);

		return 0;
	}

	if(DevExt->PortBase)
	{
		// Acquire Lock
		WdfSpinLockAcquire(DevExt->RegisterLock);

		// Read MCAP IO BAR Registers
		Value = READ_PORT_ULONG((PULONG)(DevExt->PortBase+(RegIndex*MCAP_REGISTER_SIZE)));

		// Release Lock
		WdfSpinLockRelease(DevExt->RegisterLock);

		TraceEvents(TRACE_LEVEL_VERBOSE, DBG_HW_ACCESS,
			"ReadIOBAR_Registers: Register:%d, Offset:0x%p, Value:0x%08x", RegIndex, 
			DevExt->PortBase+(RegIndex*MCAP_REGISTER_SIZE),
			Value);
	}
	else
	{
		Value = INVALID_VALUE;
		
		TraceEvents(TRACE_LEVEL_VERBOSE, DBG_HW_ACCESS,
			"ReadIOBAR_Registers: Register:%d, Offset:0x%p, Value:0x%08x, FAILED", RegIndex, 
			DevExt->PortBase+(RegIndex*MCAP_REGISTER_SIZE),
			Value);
	}

	return Value;
}

VOID WriteIOBAR_Registers(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG RegIndex,
	IN  ULONG Value
	)
/*++
Routine Description:

    This routine Writes to the MCAP's IO BAR Registers.

Arguments:

    DevExt		Pointer to the Device Extension
	Register	Offset of the  Register to be written
	Value		Value to be written into the specified Register.

Return Value:

     VOID

--*/
{
	if(!DevExt)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"DevExt is NULL, Writing MCAP Register:0x%x", RegIndex);

		return;
	}

	if(DevExt->PortBase)
	{
		// Acquire Lock
		WdfSpinLockAcquire(DevExt->RegisterLock);

		// Write MCAP Registers
		WRITE_PORT_ULONG((PULONG)(DevExt->PortBase+(RegIndex*MCAP_REGISTER_SIZE)), Value);

		// Release Lock
		WdfSpinLockRelease(DevExt->RegisterLock);

		TraceEvents(TRACE_LEVEL_VERBOSE, DBG_HW_ACCESS,
			"WriteIOBAR_Registers: Register:%d, Offset:0x%p, Value:0x%08x", RegIndex, 
			DevExt->PortBase+(RegIndex*MCAP_REGISTER_SIZE),
			Value);
	}
	else
	{
		TraceEvents(TRACE_LEVEL_VERBOSE, DBG_HW_ACCESS,
			"WriteIOBAR_Registers: Register:%d, Offset:0x%p, Value:0x%08x, FAILED", RegIndex, 
			DevExt->PortBase+(RegIndex*MCAP_REGISTER_SIZE),
			Value);
	}
}

ULONG ReadMEMBAR_Registers(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG RegIndex
	)
/*++
Routine Description:

    This routine Reads the MCAP's MEMORY BAR Registers.

Arguments:

    DevExt		Pointer to the Device Extension
	Register	Offset of the  Register to be read

Return Value:

     ULONG		Data Read from the Specified MCAP MEMORY BAR Register

--*/
{
	ULONG Value = 0;

	if(!DevExt)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"DevExt is NULL, Reading MCAP MEMORY BAR Register:0x%x", RegIndex);

		return 0;
	}

	if(DevExt->RegsBase)
	{
		// Acquire Lock
		WdfSpinLockAcquire(DevExt->RegisterLock);

		// Read MCAP MEMORY BAR Registers
		Value = READ_REGISTER_ULONG((PULONG)(DevExt->RegsBase+(RegIndex*MCAP_REGISTER_SIZE)));

		// Release Lock
		WdfSpinLockRelease(DevExt->RegisterLock);

		TraceEvents(TRACE_LEVEL_VERBOSE, DBG_HW_ACCESS,
			"ReadMEMBAR_Registers: Register:%d, Offset:0x%p, Value:0x%08x", RegIndex, 
			DevExt->RegsBase+(RegIndex*MCAP_REGISTER_SIZE),
			Value);
	}
	else
	{
		Value = INVALID_VALUE;
		
		TraceEvents(TRACE_LEVEL_VERBOSE, DBG_HW_ACCESS,
			"ReadMEMBAR_Registers: Register:%d, Offset:0x%p, Value:0x%08x, FAILED", RegIndex, 
			DevExt->RegsBase+(RegIndex*MCAP_REGISTER_SIZE),
			Value);
	}

	return Value;
}

VOID WriteMEMBAR_Registers(
    IN  PDEVICE_EXTENSION DevExt,
	IN  ULONG RegIndex,
	IN  ULONG Value
	)
/*++
Routine Description:

    This routine Writes to the MCAP's MEMORY BAR Registers.

Arguments:

    DevExt		Pointer to the Device Extension
	Register	Offset of the  Register to be written
	Value		Value to be written into the specified Register.

Return Value:

     VOID

--*/
{
	if(!DevExt)
	{
		TraceEvents(TRACE_LEVEL_ERROR, DBG_HW_ACCESS, 
			"DevExt is NULL, Writing MCAP Register:0x%x", RegIndex);

		return;
	}

	if(DevExt->RegsBase)
	{
		// Acquire Lock
		WdfSpinLockAcquire(DevExt->RegisterLock);

		// Write MCAP Registers
		WRITE_REGISTER_ULONG((PULONG)(DevExt->RegsBase+(RegIndex*MCAP_REGISTER_SIZE)), Value);

		// Release Lock
		WdfSpinLockRelease(DevExt->RegisterLock);

		TraceEvents(TRACE_LEVEL_VERBOSE, DBG_HW_ACCESS,
			"WriteMEMBAR_Registers: Register:%d, Offset:0x%p, Value:0x%08x", RegIndex, 
			DevExt->RegsBase+(RegIndex*MCAP_REGISTER_SIZE),
			Value);
	}
	else
	{
		TraceEvents(TRACE_LEVEL_VERBOSE, DBG_HW_ACCESS,
			"WriteMEMBAR_Registers: Register:%d, Offset:0x%p, Value:0x%08x, FAILED", RegIndex, 
			DevExt->RegsBase+(RegIndex*MCAP_REGISTER_SIZE),
			Value);
	}
}
