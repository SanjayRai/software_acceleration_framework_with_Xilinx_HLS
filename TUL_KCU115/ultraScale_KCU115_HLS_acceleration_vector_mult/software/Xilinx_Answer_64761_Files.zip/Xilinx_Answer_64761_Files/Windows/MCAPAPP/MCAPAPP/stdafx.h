// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <windows.h>
#include <setupapi.h>
#include <initguid.h>

#include <stdio.h>
#include <tchar.h>
#include "mcapapp.h"
#include "../../common/mcapPublic.h"
#include "../../common/mcapregs.h"
#include "../../appcommon/drvfns.h"
#include "../../appcommon/DataProcessFns.h"

#ifndef LogMessage
#define LogMessage(Z) printf(" Error: %s:%d:%S", __FUNCTION__, __LINE__, Z);
#endif

#ifndef LogMessageInfo
#define LogMessageInfo(Z) printf(" Info: %s:%d:%S", __FUNCTION__, __LINE__, Z);
#endif