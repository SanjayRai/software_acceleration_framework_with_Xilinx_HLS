/********************************************************************
*Copyright (C) 2014 – 2015 Xilinx, Inc.  All rights reserved.
*
*Permission is hereby granted, free of charge, to any person obtaining
*a copy of this software and associated documentation files (the
*"Software"), to deal in the Software without restriction, including
*without limitation the rights to use, copy, modify, merge, publish,
*distribute, sublicense, and/or sell copies of the Software, and to
*permit persons to whom the Software is furnished to do so, subject to
*the following conditions:
*
*The above copyright notice and this permission notice shall be 
*included in all copies or substantial portions of the Software.
*
*Use of the Software is limited solely to applications: (a) running 
*on a Xilinx device, or (b) that interact with a Xilinx device 
*through a bus or interconnect.  
*
*THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*NONINFRINGEMENT. IN NO EVENT SHALL XILINX BE LIABLE FOR ANY CLAIM, 
*DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
*OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
*OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*Except as contained in this notice, the name of the Xilinx shall
*not be used in advertising or otherwise to promote the sale, use or
*other dealings in this Software without prior written authorization
*from Xilinx.
*********************************************************************/
// MCAPAPP.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

extern int IsLogEnabled;

int _tmain(int argc, _TCHAR* argv[])
{
	TCHAR         DevicePath[MAX_PATH] = {0};
	ULONG         Size = MAX_PATH;
	ULONG         Status = 0;
	ULONG         Choice;

	IsLogEnabled = 0;

	Status = GetMCAPDevicePath(DevicePath, Size);
	if(Status)
	{
		// Failed for some other reason
		printf("GetMCAPDevicePath Failed \n");
		return 1;
	}

	// Open the Device
	printf("Selected: %S\n", DevicePath);

	do
	{
		Choice = 0;
		fflush(stdin);
		printf("\n");
		printf(" 1. Read PCI Configuration \t  2. Write PCI Configuration \n");
		printf(" 3. Read MCAP Register \t\t  4. Write MCAP Register \n");
		printf(" 5. Write Control Register \t  6. Read Control Configuration \n");
		printf(" 7. Read Status Register \t  8. MCAP Reset \n");
		printf(" 9. MCAP Module Reset \t\t 10. MCAP Full Reset \n");
		printf("11. Write BitStream File \t 12. Field Update \n");
		printf("13. Read BitStream File \t 14. Dump MCAP Registers\n");
		printf("15. Dump FPGA Registers \t 16. Read FPGA Register\n");
		printf("17. Exit");
		printf("\n Enter the Choice ... : ");
		scanf_s("%d", &Choice);

		switch(Choice)
		{
			case 1:	
			{
				PVOID Buffer = NULL;
				DWORD RegIndex, RegSize;

				printf(" Read PCI Configuration \n");

				printf(" Enter the Register Byte Index(In Hex): ");
				scanf_s("%x", &RegIndex);

				printf(" Enter the Number of Bytes to Read: ");
				scanf_s("%d", &RegSize);

				Buffer = malloc(RegSize);
				if(!Buffer)
				{
					printf("Unable to Allocate Buffer \n");
					break;
				}

				memset(Buffer, 0xcc, RegSize);

				Status = ReadPCIConfigSpace(
								DevicePath,
								RegIndex, 
								RegSize,
								Buffer);
				if(!Status)
				{
					printf(" Read PCI Configuration Success \n");
					PrintPCIConfigSpace(Buffer, RegIndex, RegSize);
				}
				else
				{
					printf(" Read PCI Configuration Failed \n");
				}

				if(Buffer)
					free(Buffer);
			}
			break;
			
			case 2:	
			{
				DWORD RegIndex, RegValue;

				printf(" Write PCI Configuration \n");

				printf(" Enter the Register Byte Index(Hex): ");
				scanf_s("%x", &RegIndex);

				printf(" Enter the Register Value(Hex): ");
				scanf_s("%x", &RegValue);

				Status = WritePCIConfigSpace(
								DevicePath,
								RegIndex, 
								sizeof(DWORD),
								&RegValue);
				if(!Status)
				{
					printf(" Write PCI Configuration Success \n");
				}
				else
				{
					printf(" Write PCI Configuration Failed \n");
				}
			}
			break;
			
			case 3:	
			{
				DWORD RegIndex, RegValue;

				printf(" Read MCAP Register \n");

				printf(" Enter the Register Index: ");
				scanf_s("%d", &RegIndex);

				Status = ReadMCAPReg(DevicePath, RegIndex, &RegValue);
				if(!Status)
				{
					printf(" Register : %d \n Value:0x%08x \n", RegIndex, RegValue);
				}
				else
				{
					printf(" Read MCAP Register Failed \n");
				}
			}
			break;
			
			case 4:	
			{
				DWORD RegIndex, RegValue;

				printf(" Write MCAP Register \n");

				printf(" Enter the Register Index: ");
				scanf_s("%d", &RegIndex);

				printf(" Enter the Register Value(Hex): ");
				scanf_s("%x", &RegValue);

				Status = WriteMCAPReg(DevicePath, RegIndex, RegValue);
				if(!Status)
				{
					printf(" Write MCAP Register Success \n");
				}
				else
				{
					printf(" Write MCAP Register Failed \n");
				}
			}
			break;
			
			case 5:	
			{
				DWORD RegValue;

				printf(" Write Control Register \n");

				printf(" Enter the Register Value(Hex): ");
				scanf_s("%x", &RegValue);

				Status = WriteControlReg(DevicePath, RegValue);
				if(!Status)
				{
					printf(" Write Control Register Success \n");
				}
				else
				{
					printf(" Write Control Register Failed \n");
				}
			}
			break;
			
			case 6:	
			{
				DWORD RegValue;

				printf(" Read Control Register \n");

				Status = ReadControlReg(DevicePath, &RegValue);
				if(!Status)
				{
					printf(" Control Register: Value:0x%08x \n", RegValue);
				}
				else
				{
					printf(" Read MCAP Control Register Failed \n");
				}
			}
			break;
			
			case 7:	
			{
				DWORD RegValue;

				printf(" Read Status Register \n");

				Status = ReadStatusReg(DevicePath, &RegValue);
				if(!Status)
				{
					printf(" Status Register: Value:0x%08x \n", RegValue);
				}
				else
				{
					printf(" Read MCAP Status Register Failed \n");
				}
			}
			break;
			
			case 8:	
			{
				printf(" MCAP Reset \n");
				Status = MCAPReset(DevicePath);
				if(!Status)
				{
					printf(" MCAP Reset Success \n");
				}
				else
				{
					printf(" MCAP Reset Failed \n");
				}
			}
			break;
			
			case 9:	
			{
				printf(" MCAP Module Reset \n");
				Status = MCAPModuleReset(DevicePath);
				if(!Status)
				{
					printf(" MCAP Module Reset Success \n");
				}
				else
				{
					printf(" MCAP Module Reset Failed \n");
				}
			}
			break;
			
			case 10:	
			{
				printf(" MCAP Full Reset \n");
				Status = MCAPFullReset(DevicePath);
				if(!Status)
				{
					printf(" MCAP Full Reset Success \n");
				}
				else
				{
					printf(" MCAP Full Reset Failed \n");
				}
			}
			break;
			
			case 11:	
			{
				TCHAR BinFilePath[MAX_PATH] = {'\0'};

				printf(" Write BitStream File \n");

				printf(" Enter the BitStream File Path: ");
				wscanf_s(L"%s", BinFilePath, MAX_PATH);

				Status = MCAPWriteBinFile(DevicePath, NULL, BinFilePath);
				if(!Status)
				{
					printf(" Write BitStream File Success \n");
				}
				else
				{
					printf(" Write BitStream File Failed \n");
				}
			}
			break;
			case 12:
			{
					   TCHAR ClearBinFilePath[MAX_PATH] = { '\0' };
					   TCHAR PartialBinFilePath[MAX_PATH] = { '\0' };

					   printf(" Field Update \n");

					   printf(" Enter the Clear BitStream File Path: ");
					   wscanf_s(L"%s", ClearBinFilePath, MAX_PATH);

					   printf(" Enter the Partial BitStream File Path: ");
					   wscanf_s(L"%s", PartialBinFilePath, MAX_PATH);

					   Status = MCAPWriteBinFile(DevicePath, ClearBinFilePath, PartialBinFilePath);
					   if(!Status)
					   {
						   printf(" Field Update Success \n");
					   }
					   else
					   {
						   printf(" Field Update Failed \n");
					   }
			}
			break;
			case 13:	
			{
				printf("Operation Not Supported \n");
#if 0
				TCHAR BinFilePath[MAX_PATH] = {'\0'};
				  
				printf(" Read BitStream File \n");

				printf(" Enter the BitStream File Path: ");
				wscanf_s(L"%s", BinFilePath, MAX_PATH);

				Status = MCAPReadBinFile(DevicePath, BinFilePath);
				if(!Status)
				{
					printf(" Read BitStream File Success ");
				}
				else
				{
					printf(" Read BitStream File Failed \n");
				}
#endif
			}
			break;

			case 14:
			{
				DWORD RegIndex = 0, RegValue = 0;

				printf(" Dump MCAP Registers \n");

				for(RegIndex = 0; RegIndex < MCAP_REGISTERS_COUNT;RegIndex++)
				{
					ReadMCAPReg(DevicePath, RegIndex, &RegValue);
					printf(" Register : %d \t Value:0x%08x \n", RegIndex, RegValue);
				}
			}
			break;

			case 15:
			{
				DWORD RegIndex = 0, RegValue = 0;

				printf(" Dump FPGA Registers \n");

				for(RegIndex = 0; RegIndex < XHI_NUM_REGISTERS;RegIndex++)
				{
					ReadFPGAReg(DevicePath, RegIndex, &RegValue);
					printf(" Register : %d \t Value:0x%08x \n", RegIndex, RegValue);
				}
			}
			break;

			case 16:	
			{
				DWORD RegIndex, RegValue;

				printf(" Read FPGA Register \n");

				printf(" Enter the Register Index: ");
				scanf_s("%d", &RegIndex);

				Status = ReadFPGAReg(DevicePath, RegIndex, &RegValue);
				if(!Status)
				{
					printf(" Register : %d \n Value:0x%08x \n", RegIndex, RegValue);
				}
				else
				{
					printf(" Read FPGA Register Failed \n");
				}
			}
			break;

			/*case 17:	
			{
				DWORD RegIndex, RegValue;

				printf(" Read MCAP IO BAR Register \n");

				printf(" Enter the Register Index: ");
				scanf_s("%d", &RegIndex);

				Status = ReadMCAPIOBARReg(DevicePath, RegIndex, &RegValue);
				if(!Status)
				{
					printf(" Register : %d \n Value:0x%08x \n", RegIndex, RegValue);
				}
				else
				{
					printf(" Read MCAP IO BAR Register Failed \n");
				}
			}
			break;
			
			case 18:	
			{
				DWORD RegIndex, RegValue;

				printf(" Write MCAP IO BAR Register \n");

				printf(" Enter the Register Index: ");
				scanf_s("%d", &RegIndex);

				printf(" Enter the Register Value(Hex): ");
				scanf_s("%x", &RegValue);

				Status = WriteMCAPIOBARReg(DevicePath, RegIndex, RegValue);
				if(!Status)
				{
					printf(" Write MCAP IO BAR Register Success \n");
				}
				else
				{
					printf(" Write MCAP IO BAR Register Failed \n");
				}
			}
			break;

			case 19:	
			{
				DWORD RegIndex, RegValue;

				printf(" Read MCAP MEM BAR Register \n");

				printf(" Enter the Register Index: ");
				scanf_s("%d", &RegIndex);

				Status = ReadMCAPMEMBARReg(DevicePath, RegIndex, &RegValue);
				if(!Status)
				{
					printf(" Register : %d \n Value:0x%08x \n", RegIndex, RegValue);
				}
				else
				{
					printf(" Read MCAP MEM BAR Register Failed \n");
				}
			}
			break;
			
			case 20:	
			{
				DWORD RegIndex, RegValue;

				printf(" Write MCAP MEM BAR Register \n");

				printf(" Enter the Register Index: ");
				scanf_s("%d", &RegIndex);

				printf(" Enter the Register Value(Hex): ");
				scanf_s("%x", &RegValue);

				Status = WriteMCAPMEMBARReg(DevicePath, RegIndex, RegValue);
				if(!Status)
				{
					printf(" Write MCAP MEM BAR Register Success \n");
				}
				else
				{
					printf(" Write MCAP MEM BAR Register Failed \n");
				}
			}
			break;*/

			default:
			{
				printf(" Invalid Choice \n");
			}
			break;
		}

	}while((Choice>=1)&&(Choice<=16));

	return 0;
}

// This Function Populates the MCAP device and selects a device among them
ULONG GetMCAPDevicePath(PTCHAR DevicePath, ULONG DevicePathSize)
{
    ULONG size;
	ULONG Status;
    int count, i, index;
    TCHAR *DeviceName = NULL;
    TCHAR *DeviceLocation = NULL;
	HDEVINFO hDevInfo = NULL;

	SP_DEVICE_INTERFACE_DATA DeviceInterfaceData = {0};
	SP_DEVINFO_DATA DeviceInfoData = {0};
	PSP_DEVICE_INTERFACE_DETAIL_DATA pDeviceInterfaceDetail = NULL;

	// Initialize DevicePath
	memset((void *)DevicePath, '\0', DevicePathSize);

    //
    //  Retreive the Device Information for all MCAP Devices.
    //
    hDevInfo = SetupDiGetClassDevs(&GUID_MCAP_INTERFACE,
                                   NULL,
                                   NULL,
                                   DIGCF_DEVICEINTERFACE |
                                   DIGCF_PRESENT);

    //
    //  Initialize the SP_DEVICE_INTERFACE_DATA Structure.
    //
    DeviceInterfaceData.cbSize  = sizeof(SP_DEVICE_INTERFACE_DATA);

    //
    //  Determine How Many Devices Are Present.
    //
    count = 0;
    while(SetupDiEnumDeviceInterfaces(hDevInfo,
                                      NULL,
                                      &GUID_MCAP_INTERFACE,
                                      count++,  //Cycle through the available devices.
                                      &DeviceInterfaceData)
          );

    //
    // Since the last call fails when all devices have been enumerated,
    // decrement the count to get the true device count.
    //
    count--;

    //
    //  If the count is zero then there are no devices present.
    //
    if (count == 0)
	{
        printf("No Xilinx MCAP devices are present and enabled in the system.\n");
        Status = 1;
        return Status;
    }

    //
    //  Initialize the Appropriate Data Structures in Preparation for
    //  the SetupDi Calls.
    //
    DeviceInterfaceData.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);
    DeviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);

    //
    //  Loop through the device list to allow user to choose
    //  a device.  If there is only one device, select it
    //  by default.
    //
    i = 0;
    while (SetupDiEnumDeviceInterfaces(hDevInfo,
                                       NULL,
                                       (LPGUID)&GUID_MCAP_INTERFACE,
                                       i,
                                       &DeviceInterfaceData))
	{

        //
        // Determine the size required for the DeviceInterfaceData
        //
        SetupDiGetDeviceInterfaceDetail(hDevInfo,
                                        &DeviceInterfaceData,
                                        NULL,
                                        0,
                                        &size,
                                        NULL);

        if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
		{
            printf("SetupDiGetDeviceInterfaceDetail failed, Error: %u", GetLastError());
            Status = 1;
            return Status;
        }

        pDeviceInterfaceDetail = (PSP_DEVICE_INTERFACE_DETAIL_DATA) malloc(size);
        if (!pDeviceInterfaceDetail)
		{
            printf("Insufficient memory.\n");
            Status = 1;
            return Status;
        }

        //
        // Initialize structure and retrieve data.
        //
        pDeviceInterfaceDetail->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
        Status = SetupDiGetDeviceInterfaceDetail(hDevInfo,
                                                 &DeviceInterfaceData,
                                                 pDeviceInterfaceDetail,
                                                 size,
                                                 NULL,
                                                 &DeviceInfoData);

		free(pDeviceInterfaceDetail);
		if (!Status)
		{
            printf("SetupDiGetDeviceInterfaceDetail failed, Error: %u", GetLastError());
            Status = 1;
            return Status;
        }

        //
        //  Get the Device Name
        //  Calls to SetupDiGetDeviceRegistryProperty require two consecutive
        //  calls, first to get required buffer size and second to get
        //  the data.
        //
        SetupDiGetDeviceRegistryProperty(hDevInfo,
                                        &DeviceInfoData,
                                        SPDRP_DEVICEDESC,
                                        NULL,
                                        (PBYTE)DeviceName,
                                        0,
                                        &size);

        if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
		{
            printf("SetupDiGetDeviceRegistryProperty failed, Error: %u", GetLastError());
            Status = 1;
            return Status;
        }

        DeviceName = (TCHAR*) malloc(size);
        if (!DeviceName)
		{
            printf("Insufficient memory.\n");
            Status = 1;
            return Status;
        }

        Status = SetupDiGetDeviceRegistryProperty(hDevInfo,
                                                  &DeviceInfoData,
                                                  SPDRP_DEVICEDESC,
                                                  NULL,
                                                  (PBYTE)DeviceName,
                                                  size,
                                                  NULL);
        if (!Status)
		{
            printf("SetupDiGetDeviceRegistryProperty failed, Error: %u",
                   GetLastError());
            free(DeviceName);
			DeviceName = NULL;
            Status = 1;
            return Status;
        }

        //
        //  Now retrieve the Device Location.
        //
        SetupDiGetDeviceRegistryProperty(hDevInfo,
                                         &DeviceInfoData,
                                         SPDRP_LOCATION_INFORMATION,
                                         NULL,
                                         (PBYTE)DeviceLocation,
                                         0,
                                         &size);

        if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
		{
            printf("SetupDiGetDeviceRegistryProperty failed, Error: %u", GetLastError());
            Status = 1;
            return Status;
		}

        DeviceLocation = (TCHAR*) malloc(size);
        if (!DeviceLocation)
		{
            printf("Insufficient memory.\n");
            Status = 1;
            return Status;
        }

		Status = SetupDiGetDeviceRegistryProperty(hDevInfo,
                                                      &DeviceInfoData,
                                                      SPDRP_LOCATION_INFORMATION,
                                                      NULL,
                                                      (PBYTE)DeviceLocation,
                                                      size,
                                                      NULL);
        if (!Status)
		{
            printf("SetupDiGetDeviceRegistryProperty failed, Error: %u",
                   GetLastError());
            free(DeviceLocation);
			DeviceLocation = NULL;
            Status = 1;
            return Status;
        }


        //
        // If there is more than one device print description.
        //
        if (count > 1)
		{
            printf("%d", i);
        }

        if (DeviceLocation)
		{
			printf("\t%S", DeviceName);
		}

		if (DeviceLocation)
		{
            printf("\t%S\n", DeviceLocation);
        }

        if (DeviceName)
		{
			free(DeviceName);
			DeviceName = NULL;
		}

		if (DeviceLocation)
		{
            free(DeviceLocation);
            DeviceLocation = NULL;
        }

        i++; // Cycle through the available devices.
    }

    //
    //  Select device.
    //
    index = 0;
    if (count > 1)
	{
        printf("\nSelect Device: ");

        if (scanf_s("%d", &index) == 0)
		{
			printf("Invalid Index \n");
            return ERROR_INVALID_DATA;
        }
    }

    //
    //  Get information for specific device.
    //
    Status = SetupDiEnumDeviceInterfaces(hDevInfo,
                                    NULL,
                                    (LPGUID)&GUID_MCAP_INTERFACE,
                                    index,
                                    &DeviceInterfaceData);

    if (!Status)
	{
        printf("SetupDiEnumDeviceInterfaces failed, Error: %u", GetLastError());
        return Status;
    }

    //
    // Determine the size required for the DeviceInterfaceData
    //
    SetupDiGetDeviceInterfaceDetail(hDevInfo,
                                    &DeviceInterfaceData,
                                    NULL,
                                    0,
                                    &size,
                                    NULL);

    if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
	{
        printf("SetupDiGetDeviceInterfaceDetail failed, Error: %u", GetLastError());
        Status = 1;
        return Status;
    }

    pDeviceInterfaceDetail = (PSP_DEVICE_INTERFACE_DETAIL_DATA) malloc(size);

    if (!pDeviceInterfaceDetail)
	{
        printf("Insufficient memory.\n");
        Status = 1;
        return Status;
    }

    //
    // Initialize structure and retrieve data.
    //
    pDeviceInterfaceDetail->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

    Status = SetupDiGetDeviceInterfaceDetail(hDevInfo,
                                             &DeviceInterfaceData,
                                             pDeviceInterfaceDetail,
                                             size,
                                             NULL,
                                             &DeviceInfoData);
    if (!Status)
	{
        printf("SetupDiGetDeviceInterfaceDetail failed, Error: %u", GetLastError());
		free(pDeviceInterfaceDetail);
        Status = 1;
        return Status;
    }

	if(DevicePathSize > size)
	{
		// Buffer is sufficient
		memcpy(DevicePath, pDeviceInterfaceDetail->DevicePath, size);
        Status = 0;
	}
	else
	{
		// Buffer is insufficient
		memcpy(DevicePath, pDeviceInterfaceDetail->DevicePath, DevicePathSize);
        Status = 1;
	}

    free(pDeviceInterfaceDetail);

    return Status;
}

// Prints the PCI Config Space Data
VOID PrintPCIConfigSpace(PVOID PBuffer, DWORD Offset, DWORD Length)
{
	DWORD Counter = 0;
	PBYTE PByBuffer = (PBYTE)PBuffer;

	printf("\n Offset  \t Value    ");
	for(Counter = 0; Counter < Length;Counter++)
	{
		if(!(Counter % 4))
		{
			printf("  ");
		}

		if(!(Counter % 8))
		{
			printf("\n %04x:", Offset+Counter);
		}
		printf(" %02x", *PByBuffer++);
	}
	printf("\n");
}
