/********************************************************************
*Copyright (C) 2014 � 2015 Xilinx, Inc.  All rights reserved.
*
*Permission is hereby granted, free of charge, to any person obtaining
*a copy of this software and associated documentation files (the
*"Software"), to deal in the Software without restriction, including
*without limitation the rights to use, copy, modify, merge, publish,
*distribute, sublicense, and/or sell copies of the Software, and to
*permit persons to whom the Software is furnished to do so, subject to
*the following conditions:
*
*The above copyright notice and this permission notice shall be 
*included in all copies or substantial portions of the Software.
*
*Use of the Software is limited solely to applications: (a) running 
*on a Xilinx device, or (b) that interact with a Xilinx device 
*through a bus or interconnect.  
*
*THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*NONINFRINGEMENT. IN NO EVENT SHALL XILINX BE LIABLE FOR ANY CLAIM, 
*DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
*OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
*OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*Except as contained in this notice, the name of the Xilinx shall
*not be used in advertising or otherwise to promote the sale, use or
*other dealings in this Software without prior written authorization
*from Xilinx.
*********************************************************************/
// DataProcess.h : This file contains defines and declarations for the functions
//					which are used to process the data. The Data Read from RBT, BIN, BIT
//					needs to be process before sending it to the driver.

#ifndef _DATAPROCESSFNS_H_
#define _DATAPROCESSFNS_H_


#define BINFILE L".bin"
#define BITFILE L".bit"
#define RBTFILE L".rbt"
#define LOGFILE L".log"

#define SYNCDWORD 0xAA995566
#define SYNCBYTE0 ((SYNCDWORD&0xFF000000)>>24) //0xAA
#define SYNCBYTE1 ((SYNCDWORD&0x00FF0000)>>16) //0x99
#define SYNCBYTE2 ((SYNCDWORD&0x0000FF00)>>8) //0x55
#define SYNCBYTE3 ((SYNCDWORD&0x000000FF)>>0) //0x66


ULONG ReadBinFileData(PTCHAR FullFolderPath, PVOID BinFileBuffer, DWORD BinFileSize);

ULONG WriteBinFileData(PTCHAR FullFolderPath, PVOID BinFileBuffer, DWORD BinFileSize);

ULONG ProcessRBTFile(PTCHAR FullFolderPath, PVOID BinFileBuffer, DWORD BinFileSize);

ULONG ProcessBINFile(PTCHAR FullFolderPath, PVOID BinFileBuffer, DWORD BinFileSize);

ULONG ProcessBITFile(PTCHAR FullFolderPath, PVOID BinFileBuffer, DWORD BinFileSize);

ULONG BinaryToDecimal(char *BinaryData, ULONG BinaryDataLength, PULONG DecimalValue);

#endif // _DATAPROCESSFNS_H_