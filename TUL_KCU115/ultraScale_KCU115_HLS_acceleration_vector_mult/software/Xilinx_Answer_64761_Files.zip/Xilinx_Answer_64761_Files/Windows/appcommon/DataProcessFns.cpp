/********************************************************************
*Copyright (C) 2014 � 2015 Xilinx, Inc.  All rights reserved.
*
*Permission is hereby granted, free of charge, to any person obtaining
*a copy of this software and associated documentation files (the
*"Software"), to deal in the Software without restriction, including
*without limitation the rights to use, copy, modify, merge, publish,
*distribute, sublicense, and/or sell copies of the Software, and to
*permit persons to whom the Software is furnished to do so, subject to
*the following conditions:
*
*The above copyright notice and this permission notice shall be 
*included in all copies or substantial portions of the Software.
*
*Use of the Software is limited solely to applications: (a) running 
*on a Xilinx device, or (b) that interact with a Xilinx device 
*through a bus or interconnect.  
*
*THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*NONINFRINGEMENT. IN NO EVENT SHALL XILINX BE LIABLE FOR ANY CLAIM, 
*DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
*OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
*OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*Except as contained in this notice, the name of the Xilinx shall
*not be used in advertising or otherwise to promote the sale, use or
*other dealings in this Software without prior written authorization
*from Xilinx.
*********************************************************************/
// DRVFNS.cpp : Defines the Functions which interact with the driver
//

#include "stdafx.h"

extern int IsLogEnabled;

ULONG ReadBinFileData(PTCHAR FullFolderPath, PVOID BinFileBuffer, DWORD BinFileSize)
/*++
Routine Description:

    This routine Reads the BIN/BIT/RBT files and processes
	and make them ready to send to the driver.

Arguments:

    FullFolderPath		Path of the BIN/BIT/RBT file
	BinFileBuffer		Buffer into which the Data to be read
	BinFileSize			Size of the Buffer

Return Value:

     ULONG				Bytes After Processing

--*/
{
	DWORD ReadBinFileSize = 0;
	struct _stat st;

	if(!FullFolderPath)
	{
		ReadBinFileSize = 0;
		goto Cleanup;
	}

	_wstat(FullFolderPath, &st);
	ReadBinFileSize = st.st_size;

	if(!BinFileSize)
	{
		goto Cleanup;
	}

	if(!BinFileBuffer)
	{
		goto Cleanup;
	}

	if(BinFileSize < ReadBinFileSize)
	{
		goto Cleanup;
	}

	// Check whether we are processing an rbt, bit or bin file
	if(_tcsstr(FullFolderPath, BINFILE))
	{
		ReadBinFileSize = ProcessBINFile(FullFolderPath, BinFileBuffer, BinFileSize);
	}
	else if(_tcsstr(FullFolderPath, BITFILE))
	{
		ReadBinFileSize = ProcessBITFile(FullFolderPath, BinFileBuffer, BinFileSize);
	}
	else if(_tcsstr(FullFolderPath, RBTFILE))
	{
		ReadBinFileSize = ProcessRBTFile(FullFolderPath, BinFileBuffer, BinFileSize);
	}

Cleanup:

	return ReadBinFileSize;
}

ULONG ProcessBITFile(PTCHAR FullFolderPath, PVOID BinFileBuffer, DWORD BinFileSize)
/*++
Routine Description:

    This routine Processes the BIT file and processes
	and make them ready to send to the driver.

Arguments:

    FullFolderPath		Path of the BIN/BIT/RBT file
	BinFileBuffer		Buffer into which the Data to be read
	BinFileSize			Size of the Buffer

Return Value:

     ULONG				Bytes After Processing

--*/
{
	FILE *FileHandle = NULL;
	DWORD ReadBinFileSize = 0;
	DWORD DecimalValue = 0;
	PDWORD DecimalValueBuffer = (PDWORD)BinFileBuffer;
	UCHAR SyncDWord = NULL;
	TCHAR LogFilePath[MAX_PATH] = {L"\0"};
	FILE *LogFileHandle = NULL;

	// Open the File
	_wfopen_s(&FileHandle, FullFolderPath, L"rb");
	if(!FileHandle)
	{
		TCHAR Message[MAX_PATH] = {0};

		_stprintf_s(Message, MAX_PATH, L"Unable to Open File %s \n", FullFolderPath);
		LogMessage(Message);
		ReadBinFileSize = 0;
        goto Cleanup;
	}

	// Open the Log File
	_tcscpy_s(LogFilePath, MAX_PATH, FullFolderPath);
	_tcscat_s(LogFilePath, MAX_PATH, LOGFILE);
	
	if (IsLogEnabled)
		_wfopen_s(&LogFileHandle, LogFilePath, L"w");

	if(!FileHandle)
	{
		TCHAR Message[MAX_PATH] = {0};

		_stprintf_s(Message, MAX_PATH, L"Unable to Open File %s \n", LogFilePath);
		LogMessage(Message);
		ReadBinFileSize = 0;
        goto Cleanup;
	}

	// Find the SYNCDWORD
	while((fread(&SyncDWord, 1, 1, FileHandle)) != NULL)
	{
		if(SyncDWord == SYNCBYTE0)
		{
			if((fread(&SyncDWord, 1, 1, FileHandle)) != NULL)
			{
				if(SyncDWord == SYNCBYTE1)
				{
					if((fread(&SyncDWord, 1, 1, FileHandle)) != NULL)
					{
						if(SyncDWord == SYNCBYTE2)
						{
							if((fread(&SyncDWord, 1, 1, FileHandle)) != NULL)
							{
								if(SyncDWord == SYNCBYTE3)
								{
									// SYNC DWORD Found
									break;
								}
							}
						}
					}
				}
			}
		}

		if (IsLogEnabled)
			fputc(SyncDWord, LogFileHandle);
	}

	// Check if we have reached EOF,
	// If yes return back, NO SYNC DWORD Found
	if(feof(FileHandle))
	{
		TCHAR Message[MAX_PATH] = {0};

		_stprintf_s(Message, MAX_PATH, L"SYNC DWORD 0x%08x not found in the File %s \n", SYNCDWORD, FullFolderPath);
		LogMessage(Message);
		ReadBinFileSize = 0;
        goto Cleanup;
	}

	// SYNC DWORD need to be written to the Device
	*DecimalValueBuffer = DecimalValue = SYNCDWORD;

	// Update the buffer
	DecimalValueBuffer++;

	// Adding only 4 bytes
	ReadBinFileSize+=4;

	DecimalValue = 0;


	// SYNC DWORD found, so continue reading data from here
	// we are interested in only first 32 characters
	// which is 4 Bytes
	while((fread(&DecimalValue, 4, 1, FileHandle)) != NULL)
	{
		// We need to swap bytes because we are reading a binary file with 4bytes Starting from MSB-LSB
		// These 4 bytes when read and stored in our buffer it stores first byte in lowest address
		// which means MSB in lowest address and LSB in highest address eventually this is Big Endian
		// But, our windows system is little endian, hence we need to swap the bytes
		*DecimalValueBuffer = ((DecimalValue&0xFF000000)>>24) | ((DecimalValue&0x00FF0000)>>8) | ((DecimalValue&0x0000FF00)<<8) | ((DecimalValue&0x000000FF)<<24);

		// Update the buffer
		DecimalValueBuffer++;

		// Adding only 4 bytes
		ReadBinFileSize+=4;

		DecimalValue = 0;
	}

Cleanup:
	// Close the File
	if(FileHandle)
		fclose(FileHandle);

	if (IsLogEnabled)
		if(LogFileHandle)
			fclose(LogFileHandle);

	return ReadBinFileSize;
}

ULONG ProcessBINFile(PTCHAR FullFolderPath, PVOID BinFileBuffer, DWORD BinFileSize)
/*++
Routine Description:

    This routine Processes the BIN file and processes
	and make them ready to send to the driver.

Arguments:

    FullFolderPath		Path of the BIN/BIT/RBT file
	BinFileBuffer		Buffer into which the Data to be read
	BinFileSize			Size of the Buffer

Return Value:

     ULONG				Bytes After Processing

--*/
{
	FILE *FileHandle = NULL;
	DWORD ReadBinFileSize = 0;
	DWORD DecimalValue = 0;
	PDWORD DecimalValueBuffer = (PDWORD)BinFileBuffer;

	// Open the File
	_wfopen_s(&FileHandle, FullFolderPath, L"rb");
	if(!FileHandle)
	{
		TCHAR Message[MAX_PATH] = {0};

		_stprintf_s(Message, MAX_PATH, L"Unable to Open File %s \n", FullFolderPath);
		LogMessage(Message);
		ReadBinFileSize = 0;
        goto Cleanup;
	}

	// we are interested in only first 32 characters
	// which is 4 Bytes
	while((fread(&DecimalValue, 4, 1, FileHandle)) != NULL)
	{
		// We need to swap bytes because we are reading a binary file with 4bytes Starting from MSB-LSB
		// These 4 bytes when read and stored in our buffer it stores first byte in lowest address
		// which means MSB in lowest address and LSB in highest address eventually this is Big Endian
		// But, our windows system is little endian, hence we need to swap the bytes
		*DecimalValueBuffer = ((DecimalValue&0xFF000000)>>24) | ((DecimalValue&0x00FF0000)>>8) | ((DecimalValue&0x0000FF00)<<8) | ((DecimalValue&0x000000FF)<<24);

		// Update the buffer
		DecimalValueBuffer++;

		// Adding only 4 bytes
		ReadBinFileSize+=4;

		DecimalValue = 0;
	}

Cleanup:
	// Close the File
	if(FileHandle)
		fclose(FileHandle);

	return ReadBinFileSize;
}

ULONG ProcessRBTFile(PTCHAR FullFolderPath, PVOID BinFileBuffer, DWORD BinFileSize)
/*++
Routine Description:

    This routine Processes the RBT file and processes
	and make them ready to send to the driver.

Arguments:

    FullFolderPath		Path of the BIN/BIT/RBT file
	BinFileBuffer		Buffer into which the Data to be read
	BinFileSize			Size of the Buffer

Return Value:

     ULONG				Bytes After Processing

--*/
{
	FILE *FileHandle = NULL;
	DWORD ReadBinFileSize = 0;
	char FileLine[MAX_PATH] = {0};
	DWORD DecimalValue = 0;
	PDWORD DecimalValueBuffer = (PDWORD)BinFileBuffer;
	TCHAR LogFilePath[MAX_PATH] = {L"\0"};
	FILE *LogFileHandle = NULL;

	// Open the File
	_wfopen_s(&FileHandle, FullFolderPath, L"r");
	if(!FileHandle)
	{
		TCHAR Message[MAX_PATH] = {0};

		_stprintf_s(Message, MAX_PATH, L"Unable to Open File %s \n", FullFolderPath);
		LogMessage(Message);
		ReadBinFileSize = 0;
        goto Cleanup;
	}

	// Open the Log File
	_tcscpy_s(LogFilePath, MAX_PATH, FullFolderPath);
	_tcscat_s(LogFilePath, MAX_PATH, LOGFILE);

	if (IsLogEnabled)
		_wfopen_s(&LogFileHandle, LogFilePath, L"w");

	if(!FileHandle)
	{
		TCHAR Message[MAX_PATH] = {0};

		_stprintf_s(Message, MAX_PATH, L"Unable to Open File %s \n", LogFilePath);
		LogMessage(Message);
		ReadBinFileSize = 0;
        goto Cleanup;
	}

	// we are interested in only first 32 characters
	while((fgets(FileLine, MAX_PATH, FileHandle)) != NULL)
	{
		if((FileLine[0]== '/') && (FileLine[1]== '/'))
		{
			// This line is a comment
			if (IsLogEnabled)
				fputs(FileLine, LogFileHandle);

			continue;
		}

		// Convert the 32 Bit Binary Data to Decimal
		if(BinaryToDecimal(FileLine, 32, &DecimalValue))
		{
			// Store the Decimal Value into the buffer
			*DecimalValueBuffer = DecimalValue;

			// Update the buffer
			DecimalValueBuffer++;

			// Adding only 4 bytes
			ReadBinFileSize+=4;
		}
		else
		{
			if (IsLogEnabled)
				fputs(FileLine, LogFileHandle);
		}

		// Reset the Values
		DecimalValue = 0;
		memset(FileLine, 0x00, MAX_PATH);
	}

Cleanup:
	// Close the File
	if(FileHandle)
		fclose(FileHandle);

	if (IsLogEnabled)
		if(LogFileHandle)
			fclose(LogFileHandle);

	return ReadBinFileSize;
}

ULONG BinaryToDecimal(char *BinaryData, ULONG BinaryDataLength, PULONG PDecimalValue)
/*++
Routine Description:

    This routine converts a given Binary Data in a string to Decimal Value.

Arguments:

    BinaryData			Binary Data to be converted
	BinaryDataLength	Length of the Binary Data passed
	PDecimalValue		The converted Decimal Value

Return Value:

     ULONG				Success - 0, Error - 1

--*/
{
	ULONG i = 0;

	// Initialize the out value
	*PDecimalValue = 0x0;

	// Check if the string as any other characters other than Binary 0 or 1
	// If So, return 0
	for(i = 0;i < BinaryDataLength;i++)
	{
		if(!(BinaryData[i] == '1' || BinaryData[i] == '0'))
		{
			return 0; // error not binary data
		}
	}

	// We have the string with MSB at left and LSB at right
	for(i = 0;i < BinaryDataLength;i++)
	{
		*PDecimalValue = (*PDecimalValue << 1) | (BinaryData[i]-48);
	}

	return 1;
}

ULONG WriteBinFileData(PTCHAR FullFolderPath, PVOID BinFileBuffer, DWORD BinFileSize)
/*++
Routine Description:

    This routine Writes the BIN/BIT/RBT files read 
	from the driver and writes to the file.

Arguments:

    FullFolderPath		Path of the BIN/BIT/RBT file
	BinFileBuffer		Buffer into which the Data to be written
	BinFileSize			Size of the Buffer

Return Value:

     ULONG				Bytes After Processing

--*/
{
	FILE *FileHandle = NULL;
	DWORD WriteBinFileSize = 0;

	if(!FullFolderPath)
	{
		WriteBinFileSize = 0;
		goto Cleanup;
	}

	if(!BinFileSize)
	{
		WriteBinFileSize = 0;
		goto Cleanup;
	}

	if(!BinFileBuffer)
	{
		WriteBinFileSize = 0;
		goto Cleanup;
	}

	// Open the File
	_wfopen_s(&FileHandle, FullFolderPath, L"wb");
	if(!FileHandle)
	{
		TCHAR Message[MAX_PATH] = {0};

		_stprintf_s(Message, MAX_PATH, L"Unable to Open File %s \n", FullFolderPath);
		LogMessage(Message);
		WriteBinFileSize = 0;
        goto Cleanup;
	}

	// Read Bin File
	WriteBinFileSize = fwrite(BinFileBuffer, sizeof(char), BinFileSize, FileHandle);
	if(!BinFileSize)
	{
		TCHAR Message[MAX_PATH] = {0};

		_stprintf_s(Message, MAX_PATH, L"Unable to Read File %s \n", FullFolderPath);
		LogMessage(Message);
		WriteBinFileSize = 0;
        goto Cleanup;
	}

Cleanup:
	// Close the File
	if(FileHandle)
		fclose(FileHandle);

	return WriteBinFileSize;
}
