/********************************************************************
*Copyright (C) 2014 � 2015 Xilinx, Inc.  All rights reserved.
*
*Permission is hereby granted, free of charge, to any person obtaining
*a copy of this software and associated documentation files (the
*"Software"), to deal in the Software without restriction, including
*without limitation the rights to use, copy, modify, merge, publish,
*distribute, sublicense, and/or sell copies of the Software, and to
*permit persons to whom the Software is furnished to do so, subject to
*the following conditions:
*
*The above copyright notice and this permission notice shall be 
*included in all copies or substantial portions of the Software.
*
*Use of the Software is limited solely to applications: (a) running 
*on a Xilinx device, or (b) that interact with a Xilinx device 
*through a bus or interconnect.  
*
*THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*NONINFRINGEMENT. IN NO EVENT SHALL XILINX BE LIABLE FOR ANY CLAIM, 
*DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
*OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
*OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*Except as contained in this notice, the name of the Xilinx shall
*not be used in advertising or otherwise to promote the sale, use or
*other dealings in this Software without prior written authorization
*from Xilinx.
*********************************************************************/
// DRVFNS.cpp : Defines the Functions which interact with the driver
//

#include "stdafx.h"

ULONG GetDataFromDevice(PTCHAR DevicePath, DWORD dwIoControlCode, 
						PMCAP_IOCTL_REQ_RES pMCAPReq, DWORD InLen, 
						PMCAP_IOCTL_REQ_RES pMCAPResp, DWORD OutLen, 
						PDWORD BytesReturned)
/*++
Routine Description:

    This routine Sends the IOCTL Request to the device driver and gets the response.

Arguments:

    DevicePath		Pointer to the Device Path
	dwIoControlCode	IO Control Code to be sent
	pMCAPReq		Pointer to the Request Buffer
	InLen			Length of the Input (Request) Buffer
	pMCAPReq		Pointer to the Response Buffer
	InLen			Length of the Output (Response) Buffer

Return Value:

     ULONG		0 - Success, ErrorCode - Failure.


--*/
{
	HANDLE File = NULL;
	DWORD dwError = 0;

	File = CreateFile ( DevicePath,
                        GENERIC_READ | GENERIC_WRITE, // write & read access
                        0, // FILE_SHARE_READ | FILE_SHARE_WRITE
                        NULL, // no SECURITY_ATTRIBUTES structure
                        OPEN_EXISTING, // No special create flags
                        0, // No special attributes
                        NULL); // No template file

    if (INVALID_HANDLE_VALUE == File)
	{
		TCHAR Message[4*MAX_PATH] = {0};
		TCHAR ErrorMessage[MAX_PATH] = {0};

		dwError = GetLastError();
		GET_ERROR_MESSAGE(dwError, ErrorMessage, MAX_PATH);

		_stprintf_s(Message, MAX_PATH, L"CreateFile Failed for %s path with [%d] %s\n", DevicePath, dwError, ErrorMessage);
		LogMessage(Message);

		return dwError;
    }

	if (!(DeviceIoControl (File,
						  dwIoControlCode,
						  pMCAPReq, 
						  InLen,
						  pMCAPResp, 
						  OutLen,
						  BytesReturned,
						  NULL)))
	{
		TCHAR Message[MAX_PATH] = {0};
		TCHAR ErrorMessage[MAX_PATH] = {0};

		dwError = GetLastError();
		GET_ERROR_MESSAGE(dwError, ErrorMessage, MAX_PATH);

		_stprintf_s(Message, MAX_PATH, L"DeviceIoControl Failed with [%d] %s\n", dwError, ErrorMessage);
		LogMessage(Message);

		return dwError;
	}

	if(File)
	{
		CloseHandle(File);
		File = NULL;
	}

	return dwError;
}

ULONG ReadPCIConfigSpace(PTCHAR DevicePath, DWORD RegIndex, DWORD Length, PVOID Buffer)
/*++
Routine Description:

    This routine Sends the IOCTL Request to the read the PCI Config Space.

Arguments:

    DevicePath		Pointer to the Device Path
	RegIndex		Starting Offset from which the PCI Config Data to be Read
	Length			Size of the Buffer and also the size to be read from the PCI Config Space
	Buffer			Buffer to which the PCI Config Data to be read into

Return Value:

     ULONG		0 - Success, ErrorCode - Failure.
--*/
{
	MCAP_IOCTL_REQ_RES Request = {0};
	PMCAP_IOCTL_REQ_RES Response = NULL;
	DWORD InLen = 0, OutLen = 0;
	DWORD BytesRet = 0;
	ULONG Status = 0;

	if(!DevicePath)
	{
		Status = ERROR_PATH_NOT_FOUND;
		LogMessage(L"Device Path is Null \n");
		return Status;
	}

	if(!Length)
	{
		Status = ERROR_INVALID_ACCESS;
		LogMessage(L"Length is Zero \n");
		return Status;
	}

	if(!Buffer)
	{
		Status = ERROR_INVALID_ACCESS;
		LogMessage(L"Buffer is Null \n");
		return Status;
	}

	Request.mcapreq.pciconfigread.RegIndex = RegIndex;
	Request.mcapreq.pciconfigread.Length = Length;
	InLen = sizeof(MCAP_IOCTL_REQ_RES);

	OutLen = Request.mcapreq.pciconfigread.Length + sizeof(MCAP_IOCTL_REQ_RES);
	Response = (PMCAP_IOCTL_REQ_RES)malloc(OutLen);
	if(!Response)
	{
		// Failed Memory
		Status = ERROR_NOT_ENOUGH_MEMORY;
		LogMessage(L"Memory Allocation for Response Failed. \n");
	}
	else
	{
		memset(Response, '\0', OutLen);

		if((Status = GetDataFromDevice(DevicePath, IOCTL_READ_PCI_CONFIG_REG, &Request, InLen, Response, OutLen, &BytesRet)))
		{
			LogMessage(L"Read PCI Configuration Failed\n");
		}
		else
		{
			if((Response->mcapres.pciconfigread.RegIndex == RegIndex) && 
				(Response->mcapres.pciconfigread.Length  == Length))
			{
				// Success
				memcpy(Buffer, Response->mcapres.pciconfigread.Buffer, Response->mcapres.pciconfigread.Length);
			}
			else
			{
				// Failed
				Status = ERROR_INVALID_DATA;
				LogMessage(L"Read PCI Configuration Failed \n");
			}
		}

		free(Response);
	}

	return Status;
}

ULONG WritePCIConfigSpace(PTCHAR DevicePath, DWORD RegIndex, DWORD Length, PVOID Buffer)
/*++
Routine Description:

    This routine Sends the IOCTL Request to the Write the PCI Config Space.

Arguments:

    DevicePath		Pointer to the Device Path
	RegIndex		Starting Offset from which the PCI Config Data to be Written
	Length			Size of the Buffer and also the size to be written to the PCI Config Space
	Buffer			Buffer from which the PCI Config Data to be written

Return Value:

     ULONG		0 - Success, ErrorCode - Failure.
--*/
{
	PMCAP_IOCTL_REQ_RES Request = NULL;
	PMCAP_IOCTL_REQ_RES Response = NULL;
	DWORD InLen = 0, OutLen = 0;
	DWORD Status = 0;
	DWORD BytesRet = 0;

	if(!DevicePath)
	{
		Status = ERROR_PATH_NOT_FOUND;
		LogMessage(L"Device Path is Null \n");
		return Status;
	}

	if(!Length)
	{
		Status = ERROR_INVALID_ACCESS;
		LogMessage(L"Length is Zero \n");
		return Status;
	}

	if(!Buffer)
	{
		Status = ERROR_INVALID_ACCESS;
		LogMessage(L"Buffer is Null \n");
		return Status;
	}

	InLen = Length + sizeof(MCAP_IOCTL_REQ_RES);
	Request = (PMCAP_IOCTL_REQ_RES)malloc(InLen);
	if(!Request)
	{
		// Failed Memory
		Status = ERROR_NOT_ENOUGH_MEMORY;
		LogMessage(L"Memory Allocation for Request Failed. \n");
	}
	else
	{
		memset(Request, '\0', OutLen);
		Request->mcapreq.pciconfigwrite.RegIndex = RegIndex;
		Request->mcapreq.pciconfigwrite.Length = Length;
		memcpy(Request->mcapreq.pciconfigwrite.Buffer, Buffer, Length);

		// GetPCIConfig(Request, &InLen);
		if(Status = GetDataFromDevice(DevicePath, IOCTL_WRITE_PCI_CONFIG_REG, Request, InLen, Response, OutLen, &BytesRet))
		{
			// Failed
			LogMessage(L"Write PCI Configuration Failed\n");
		}
		else
		{
			// Success
			//LogMessage(L"Write PCI Configuration Success \n");
		}
	}
	return Status;
}

ULONG ReadMCAPReg(PTCHAR DevicePath, DWORD RegIndex, DWORD *RegValue)
/*++
Routine Description:

    This routine Sends the IOCTL Request to the Read the MCAP Register.

Arguments:

    DevicePath		Pointer to the Device Path
	RegIndex		Offset of the MCAP Register to be read
	RegValue		Buffer to which the MCAP Register to be read into

Return Value:

     ULONG			Status 0 -Success, 1 - Faliure.
--*/
{
	MCAP_IOCTL_REQ_RES Request = {0};
	MCAP_IOCTL_REQ_RES Response = {0};
	DWORD InLen = 0, OutLen = 0;
	ULONG Status = 0;
	DWORD BytesRet = 0;

	if(!DevicePath)
	{
		Status = ERROR_PATH_NOT_FOUND;
		LogMessage(L"Device Path is Null \n");
		return Status;
	}

	Request.mcapreq.mcapreadreg.RegIndex = RegIndex;
	OutLen = InLen = sizeof(MCAP_IOCTL_REQ_RES);
	
	if(Status = GetDataFromDevice(DevicePath, IOCTL_READ_MCAP_REG, &Request, InLen, &Response, OutLen, &BytesRet))
	{
		// Failed
		LogMessage(L"Read MCAP Register Failed\n");
	}
	else
	{
		*RegValue = Response.mcapres.mcapreadreg.RegValue;
	}

	return Status;
}

ULONG WriteMCAPReg(PTCHAR DevicePath, DWORD RegIndex, DWORD RegValue)
/*++
Routine Description:

    This routine Sends the IOCTL Request to the Write the MCAP Register.

Arguments:

    DevicePath		Pointer to the Device Path
	RegIndex		Offset of the MCAP Register to be written
	RegValue		Buffer from which the data to the MCAP Register to be written

Return Value:

     ULONG			Status 0 -Success, 1 - Faliure.
--*/
{
	MCAP_IOCTL_REQ_RES Request = {0};
	PMCAP_IOCTL_REQ_RES Response = NULL;
	DWORD InLen = 0, OutLen = 0;
	ULONG Status = 0;
	DWORD BytesRet = 0;

	if(!DevicePath)
	{
		Status = ERROR_PATH_NOT_FOUND;
		LogMessage(L"Device Path is Null \n");
		return Status;
	}

	Request.mcapreq.mcapwritereg.RegIndex = RegIndex;
	Request.mcapreq.mcapwritereg.RegValue = RegValue;

	InLen = sizeof(MCAP_IOCTL_REQ_RES);

	if(Status = GetDataFromDevice(DevicePath, IOCTL_WRITE_MCAP_REG, &Request, InLen, Response, OutLen, &BytesRet))
	{
		// Failed
		LogMessage(L"Write MCAP Register Failed\n");
	}
	else
	{
		// Success
		//LogMessage(L"Write MCAP Register Success \n");
	}

	return Status;
}

ULONG WriteControlReg(PTCHAR DevicePath, DWORD RegValue)
/*++
Routine Description:

    This routine Sends the IOCTL Request to the Write to the MCAP Control Register.

Arguments:

    DevicePath		Pointer to the Device Path
	RegValue		Buffer from which the MCAP Control Register to be written

Return Value:

     ULONG			Status 0 -Success, 1 - Faliure.
--*/
{
	MCAP_IOCTL_REQ_RES Request = {0};
	PMCAP_IOCTL_REQ_RES Response = NULL;
	DWORD InLen = 0, OutLen = 0;
	ULONG Status = 0;
	DWORD BytesRet = 0;

	if(!DevicePath)
	{
		Status = ERROR_PATH_NOT_FOUND;
		LogMessage(L"Device Path is Null \n");
		return Status;
	}

	Request.mcapreq.mcapwritectrlreg.RegValue = RegValue;
	InLen = sizeof(MCAP_IOCTL_REQ_RES);

	if(Status = GetDataFromDevice(DevicePath, IOCTL_WRITE_CONTROL_REG, &Request, InLen, Response, OutLen, &BytesRet))
	{
		// Failed
		LogMessage(L"Write Control Register Failed\n");
	}
	else
	{
		// Success
		//LogMessage(L"Write Control Register Success \n");
	}

	return Status;
}

ULONG ReadControlReg(PTCHAR DevicePath, DWORD *RegValue)
/*++
Routine Description:

    This routine Sends the IOCTL Request to the Read to the MCAP Control Register.

Arguments:

    DevicePath		Pointer to the Device Path
	RegValue		Buffer to which the MCAP Control Register to be read

Return Value:

     ULONG			Status 0 -Success, 1 - Faliure.
--*/
{
	PMCAP_IOCTL_REQ_RES Request = NULL;
	MCAP_IOCTL_REQ_RES Response = {0};
	DWORD InLen = 0, OutLen = 0;
	ULONG Status = 0;
	DWORD BytesRet = 0;

	if(!DevicePath)
	{
		Status = ERROR_PATH_NOT_FOUND;
		LogMessage(L"Device Path is Null \n");
		return Status;
	}

	OutLen = sizeof(MCAP_IOCTL_REQ_RES);

	if(Status = GetDataFromDevice(DevicePath, IOCTL_READ_CONTROL_REG, Request, InLen, &Response, OutLen, &BytesRet))
	{
		// Failed
		LogMessage(L"Read Control Register Failed\n");
	}
	else
	{
		TCHAR Message[MAX_PATH] = {0};

		// Success
		//LogMessage(L"Read Control Register Success \n");
		*RegValue = Response.mcapres.mcapreadctrlreg.RegValue;

		_stprintf_s(Message, MAX_PATH, L"Control Register: Value:0x%08x \n", *RegValue);
		LogMessageInfo(Message);
	}

	return Status;
}

ULONG ReadStatusReg(PTCHAR DevicePath, DWORD *RegValue)
/*++
Routine Description:

    This routine Sends the IOCTL Request to the Read to the MCAP Status Register.

Arguments:

    DevicePath		Pointer to the Device Path
	RegValue		Buffer to which the MCAP Status Register to be read

Return Value:

     ULONG			Status 0 -Success, 1 - Faliure.
--*/
{
	PMCAP_IOCTL_REQ_RES Request = NULL;
	MCAP_IOCTL_REQ_RES Response = {0};
	DWORD InLen = 0, OutLen = 0;
	ULONG Status = 0;
	DWORD BytesRet = 0;

	if(!DevicePath)
	{
		Status = ERROR_PATH_NOT_FOUND;
		LogMessage(L"Device Path is Null \n");
		return Status;
	}

	OutLen = sizeof(MCAP_IOCTL_REQ_RES);

	if(Status = GetDataFromDevice(DevicePath, IOCTL_READ_STATUS_REG, Request, InLen, &Response, OutLen, &BytesRet))
	{
		// Failed
		LogMessage(L"Read Status Register Failed\n");
	}
	else
	{
		TCHAR Message[MAX_PATH] = {0};

		// Success
		LogMessage(L"Read Status Register Success \n");
		*RegValue = Response.mcapres.mcapreadstatreg.RegValue;

		_stprintf_s(Message, MAX_PATH, L"Status Register: Value:0x%08x \n", *RegValue);
		LogMessageInfo(Message);
	}

	return Status;
}

ULONG MCAPReset(PTCHAR DevicePath)
/*++
Routine Description:

    This routine Sends the IOCTL Request to Reset the Device.

Arguments:

    DevicePath		Pointer to the Device Path

Return Value:

     ULONG			Status 0 -Success, 1 - Faliure.
--*/
{
	PMCAP_IOCTL_REQ_RES Request = NULL;
	PMCAP_IOCTL_REQ_RES Response = NULL;
	DWORD InLen = 0, OutLen = 0;
	ULONG Status = 0;
	DWORD BytesRet = 0;

	if(!DevicePath)
	{
		Status = ERROR_PATH_NOT_FOUND;
		LogMessage(L"Device Path is Null \n");
		return Status;
	}

	if(Status = GetDataFromDevice(DevicePath, IOCTL_MCAP_RESET, Request, InLen, Response, OutLen, &BytesRet))
	{
		// Failed
		LogMessage(L"MCAP Reset Failed\n");
	}
	else
	{
		// Success
		LogMessageInfo(L"MCAP Reset Success \n");
	}

	return Status;
}

ULONG MCAPModuleReset(PTCHAR DevicePath)
/*++
Routine Description:

    This routine Sends the IOCTL Request to Module Reset the Device.

Arguments:

    DevicePath		Pointer to the Device Path

Return Value:

     ULONG			Status 0 -Success, 1 - Faliure.
--*/
{
	PMCAP_IOCTL_REQ_RES Request = NULL;
	PMCAP_IOCTL_REQ_RES Response = NULL;
	DWORD InLen = 0, OutLen = 0;
	ULONG Status = 0;
	DWORD BytesRet = 0;

	if(!DevicePath)
	{
		Status = ERROR_PATH_NOT_FOUND;
		LogMessage(L"Device Path is Null \n");
		return Status;
	}

	if(Status = GetDataFromDevice(DevicePath, IOCTL_MCAP_MODULE_RESET, Request, InLen, Response, OutLen, &BytesRet))
	{
		// Failed
		LogMessage(L"MCAP Module Reset Failed\n");
	}
	else
	{
		// Success
		LogMessageInfo(L"MCAP Module Reset Success \n");
	}

	return Status;
}

ULONG MCAPFullReset(PTCHAR DevicePath)
/*++
Routine Description:

    This routine Sends the IOCTL Request to Full Reset the Device.

Arguments:

    DevicePath		Pointer to the Device Path

Return Value:

     ULONG			Status 0 -Success, 1 - Faliure.
--*/
{
	PMCAP_IOCTL_REQ_RES Request = NULL;
	PMCAP_IOCTL_REQ_RES Response = NULL;
	DWORD InLen = 0, OutLen = 0;
	ULONG Status = 0;
	DWORD BytesRet = 0;

	if(!DevicePath)
	{
		Status = ERROR_PATH_NOT_FOUND;
		LogMessage(L"Device Path is Null \n");
		return Status;
	}

	if(Status = GetDataFromDevice(DevicePath, IOCTL_MCAP_FULL_RESET, Request, InLen, Response, OutLen, &BytesRet))
	{
		// Failed
		LogMessage(L"MCAP Full Reset Failed\n");
	}
	else
	{
		// Success
		LogMessageInfo(L"MCAP Full Reset Success \n");
	}

	return Status;
}

ULONG MCAPWriteBinFile(PTCHAR DevicePath, PTCHAR ClearBinFilePath, PTCHAR ProgramBinFilePath)
/*++
Routine Description:

    This routine Read the Bit Stream File Processes it and then
	Writes the Bin File Data to the device..

Arguments:

    DevicePath			Pointer to the Device Path
	ClearBinFilePath	Path of the clear BIN/BIT/RBT File
	ProgramBinFilePath	Path of the program BIN/BIT/RBT File

Return Value:

     ULONG			Status 0 -Success, 1 - Faliure.
--*/
{
	ULONG Status = 0;
	PVOID ClearBinFileBuffer = NULL;
	ULONG ClearBinFileSize = 0;
	PVOID ProgramBinFileBuffer = NULL;
	ULONG ProgramBinFileSize = 0;
	ULONG BinFileSizeWritten = 0;
	ULONG ClearBinFileSizePostProcessing = 0;
	ULONG ProgramBinFileSizePostProcessing = 0;
	UINT pMode = 2; // 0 - Only Clear, 1 - Only Program, 2 - Clear and Program
	USER_WRITE_BUFFER userBuffer;
	PUCHAR dataBuffer;
	UINT totalSize = 0;
	userBuffer.USER_SPACE_BITSTREAM_TYPE.type = 0;
	TCHAR Message[MAX_PATH] = { 0 };
	//HANDLE File = NULL;
	//DWORD dwError = 0;

	if(!DevicePath)
	{
		Status = ERROR_PATH_NOT_FOUND;
		LogMessage(L"Device Path is Null \n");
		return Status;
	}

	
	if(!ClearBinFilePath)
	{
		/*Status = ERROR_FILE_NOT_FOUND;
		LogMessage(L"BIN File Path Handle is Null \n");
		return Status;*/
		// Could be PCiE programming
		if (!ProgramBinFilePath)
		{
			Status = ERROR_FILE_NOT_FOUND;
			LogMessage(L"BIN File Path Handle is Null \n");
			return Status;
		}else{
			pMode = 1;
			// Read the BIN File Size
			userBuffer.USER_SPACE_BITSTREAM_TYPE.BIT.FIELD_UPDATE = 0;
			ProgramBinFileSize = ReadBinFileData(ProgramBinFilePath, NULL, 0);
			dataBuffer = (PUCHAR)malloc(ProgramBinFileSize + 12);
			ProgramBinFileBuffer = malloc(ProgramBinFileSize);
			if (!dataBuffer || !ProgramBinFileBuffer)
			{
				Status = ERROR_NOT_ENOUGH_MEMORY;
				LogMessage(L"Unable to Allocate Memory \n");
				return Status;
			}
			memcpy(dataBuffer, (void*)(&userBuffer.USER_SPACE_BITSTREAM_TYPE.type), 4);
			memset(dataBuffer + 4, 0, 4);
			memcpy(dataBuffer + 8, (void*)&ProgramBinFileSize, 4);
			// Now, Read the BIN File Data
			ProgramBinFileSizePostProcessing = ReadBinFileData(ProgramBinFilePath, ProgramBinFileBuffer, ProgramBinFileSize);
			memcpy(dataBuffer + 12, ProgramBinFileBuffer, ProgramBinFileSize);
			totalSize = 12 + ProgramBinFileSize;
		}
	}else if (!ProgramBinFilePath){
		pMode = 0;
		// Read the BIN File Size
		userBuffer.USER_SPACE_BITSTREAM_TYPE.BIT.FIELD_UPDATE = 1;
		userBuffer.USER_SPACE_BITSTREAM_TYPE.BIT.MULTIPLE_BITSTREAM = 0;
		userBuffer.USER_SPACE_BITSTREAM_TYPE.BIT.CLEAR_BITSTREAM = 1;
		userBuffer.USER_SPACE_BITSTREAM_TYPE.BIT.FULL_BITSTREAM = 0;
		ClearBinFileSize = ReadBinFileData(ClearBinFilePath, NULL, 0);
		dataBuffer = (PUCHAR)malloc(ClearBinFileSize + 12);
		ClearBinFileBuffer = malloc(ClearBinFileSize);
		if (!dataBuffer || !ClearBinFileBuffer)
		{
			Status = ERROR_NOT_ENOUGH_MEMORY;
			LogMessage(L"Unable to Allocate Memory \n");
			return Status;
		}
		memcpy(dataBuffer, (void*)(&userBuffer.USER_SPACE_BITSTREAM_TYPE.type), 4);
		memset(dataBuffer + 4, 0, 4);
		memcpy(dataBuffer + 8, (void*)&ClearBinFileSize, 4);
		// Now, Read the BIN File Data
		ClearBinFileSizePostProcessing = ReadBinFileData(ClearBinFilePath, ClearBinFileBuffer, ClearBinFileSize);
		memcpy(dataBuffer + 12, ClearBinFileBuffer, ClearBinFileSize);
		totalSize = 12 + ClearBinFileSize;
	}
	
	if (pMode == 2){
		// Read the BIN File Size
		userBuffer.USER_SPACE_BITSTREAM_TYPE.BIT.FIELD_UPDATE = 1;
		userBuffer.USER_SPACE_BITSTREAM_TYPE.BIT.MULTIPLE_BITSTREAM = 1;
		userBuffer.USER_SPACE_BITSTREAM_TYPE.BIT.CLEAR_BITSTREAM = 1;
		userBuffer.USER_SPACE_BITSTREAM_TYPE.BIT.FULL_BITSTREAM = 1;

		ClearBinFileSize = ReadBinFileData(ClearBinFilePath, NULL, 0);
		ProgramBinFileSize = ReadBinFileData(ProgramBinFilePath, NULL, 0);
		dataBuffer = (PUCHAR)malloc(ClearBinFileSize + ProgramBinFileSize + 12);
		ClearBinFileBuffer = malloc(ClearBinFileSize);
		ProgramBinFileBuffer = malloc(ProgramBinFileSize);
		if (!dataBuffer || !ClearBinFileBuffer || !ProgramBinFileBuffer)
		{
			Status = ERROR_NOT_ENOUGH_MEMORY;
			LogMessage(L"Unable to Allocate Memory \n");
			return Status;
		}

		// Now, Read the BIN File Data
		ClearBinFileSizePostProcessing = ReadBinFileData(ClearBinFilePath, ClearBinFileBuffer, ClearBinFileSize);
		// Now, Read the BIN File Data
		ProgramBinFileSizePostProcessing = ReadBinFileData(ProgramBinFilePath, ProgramBinFileBuffer, ProgramBinFileSize);
		memcpy(dataBuffer, (void*)(&userBuffer.USER_SPACE_BITSTREAM_TYPE.type), 4);
		memcpy(dataBuffer + 4, (void*)&ClearBinFileSize, 4);
		memcpy(dataBuffer + 8, (void*)&ProgramBinFileSize, 4);
		memcpy(dataBuffer + 12, ClearBinFileBuffer, ClearBinFileSize);
		memcpy(dataBuffer + 12 + ClearBinFileSize, ProgramBinFileBuffer, ProgramBinFileSize);
		totalSize = 12 + ClearBinFileSize + ProgramBinFileSize;
	}
	

	Status = MCAPWriteDataToDevice(DevicePath, dataBuffer, totalSize, &BinFileSizeWritten);
/*
	File = CreateFile ( DevicePath,
                        GENERIC_READ | GENERIC_WRITE, // write & read access
                        0, // FILE_SHARE_READ | FILE_SHARE_WRITE
                        NULL, // no SECURITY_ATTRIBUTES structure
                        OPEN_EXISTING, // No special create flags
                        0, // No special attributes
                        NULL); // No template file

    if (INVALID_HANDLE_VALUE == File)
	{
		TCHAR Message[MAX_PATH] = {0};
		TCHAR ErrorMessage[MAX_PATH] = {0};

		dwError = GetLastError();
		GET_ERROR_MESSAGE(dwError, ErrorMessage, MAX_PATH);

		_stprintf_s(Message, MAX_PATH, L"CreateFile Failed for %s path with [%d] %s \n", DevicePath, dwError, ErrorMessage);
		LogMessage(Message);

		Status = 1;
		return Status;
    }

	// Write the BIN File
	//if(!WriteFile(File, BinFileBuffer, BinFileSize, &BinFileSizeWritten, NULL))
	if(!WriteFile(File, BinFileBuffer, BinFileSizePostProcessing, &BinFileSizeWritten, NULL))
	{
		TCHAR Message[MAX_PATH] = {0};
		TCHAR ErrorMessage[MAX_PATH] = {0};

		dwError = GetLastError();
		GET_ERROR_MESSAGE(dwError, ErrorMessage, MAX_PATH);

		_stprintf_s(Message, MAX_PATH, L"WriteFile Failed: [%d] %s", dwError, ErrorMessage);
        LogMessage(Message);

		if(File)
		{
			CloseHandle(File);
			File = NULL;
		}

		Status = 1;
		return Status;
	}

	if(File)
	{
		CloseHandle(File);
		File = NULL;
	}
*/
	// Free the Buffer
	if(dataBuffer)
	{
		free(dataBuffer);
	}
	if (ProgramBinFileBuffer)
	{
		free(ProgramBinFileBuffer);
	}
	if (ClearBinFileBuffer)
	{
		free(ClearBinFileBuffer);
	}
	return Status;
}

ULONG MCAPWriteDataToDevice(PTCHAR DevicePath, PVOID BinFileBuffer, ULONG BinFileSizePostProcessing, PULONG BinFileSizeWritten)
/*++
Routine Description:

    This routine Writes the Bin File Data to the device..
	This routine is responsible for sending the Bit, Bin, Rbt file
	data to the device after processing.

Arguments:

    DevicePath		Pointer to the Device Path
	BinFileBuffer	Buffer in which BIN/BIT/RBT Data is present after Processing
	BinFileSizePostProcessing	Size of the Buffer after Processing

Return Value:
     ULONG			BinFileSizeWritten	Bytes Written to the Device
     ULONG			Status 0 -Success, 1 - Faliure.
--*/
{
	HANDLE File = NULL;
	DWORD dwError = 0;

	File = CreateFile ( DevicePath,
                        GENERIC_READ | GENERIC_WRITE, // write & read access
                        0, // FILE_SHARE_READ | FILE_SHARE_WRITE
                        NULL, // no SECURITY_ATTRIBUTES structure
                        OPEN_EXISTING, // No special create flags
                        0, // No special attributes
                        NULL); // No template file

    if (INVALID_HANDLE_VALUE == File)
	{
		TCHAR Message[MAX_PATH] = {0};
		TCHAR ErrorMessage[MAX_PATH] = {0};

		dwError = GetLastError();
		GET_ERROR_MESSAGE(dwError, ErrorMessage, MAX_PATH);

		_stprintf_s(Message, MAX_PATH, L"CreateFile Failed for %s path with [%d] %s \n", DevicePath, dwError, ErrorMessage);
		LogMessage(Message);

		return dwError;
    }

	// Write the BIN File
	if(!WriteFile(File, BinFileBuffer, BinFileSizePostProcessing, BinFileSizeWritten, NULL))
	{
		TCHAR Message[MAX_PATH] = {0};
		TCHAR ErrorMessage[MAX_PATH] = {0};

		dwError = GetLastError();
		GET_ERROR_MESSAGE(dwError, ErrorMessage, MAX_PATH);

		_stprintf_s(Message, MAX_PATH, L"WriteFile Failed: [%d] %s\n", dwError, ErrorMessage);
        LogMessage(Message);

		if(File)
		{
			CloseHandle(File);
			File = NULL;
		}

		return dwError;
	}

	if(File)
	{
		CloseHandle(File);
		File = NULL;
	}

	return dwError;
}
#if 0
ULONG MCAPReadBinFile(PTCHAR DevicePath, PTCHAR BinFilePath)
/*++
Routine Description:

    This routine Reads the Bin File Data from the device..
	This routine is responsible for reading the Bit, Bin, Rbt file
	data from the device.

Arguments:

    DevicePath		Pointer to the Device Path
	BinFilePath		Path of the BIN/BIT/RBT File

Return Value:

     ULONG			Status 0 -Success, 1 - Faliure.
--*/
{
	ULONG Status = 0;
	PVOID BinFileBuffer = NULL;
	ULONG BinFileSize = 0;
	ULONG BinFileSizeRead = 0;
	HANDLE File = NULL;
	DWORD dwError = 0;

	if(!DevicePath)
	{
		Status = ERROR_PATH_NOT_FOUND;
		LogMessage(L"Device Path is Null \n");
		return Status;
	}

	if(!BinFilePath)
	{
		Status = ERROR_FILE_NOT_FOUND;
		LogMessage(L"BIN File Path Handle is Null \n");
		return Status;
	}

	BinFileSize = MAX_PATH;
	BinFileBuffer = malloc(BinFileSize);
	if(!BinFileBuffer)
	{
		LogMessage(L"Unable to Allocate Memory \n");
		Status = ERROR_NOT_ENOUGH_MEMORY;
		return Status;
	}

	File = CreateFile ( DevicePath,
                        GENERIC_READ | GENERIC_WRITE, // write & read access
                        0, // FILE_SHARE_READ | FILE_SHARE_WRITE
                        NULL, // no SECURITY_ATTRIBUTES structure
                        OPEN_EXISTING, // No special create flags
                        0, // No special attributes
                        NULL); // No template file

    if (INVALID_HANDLE_VALUE == File)
	{
		TCHAR Message[MAX_PATH] = {0};
		TCHAR ErrorMessage[MAX_PATH] = {0};

		dwError = GetLastError();
		GET_ERROR_MESSAGE(dwError, ErrorMessage, MAX_PATH);

		_stprintf_s(Message, MAX_PATH, L"CreateFile Failed for %s path with [%d] %s\n", DevicePath, dwError, ErrorMessage);
		LogMessage(Message);

		return dwError;
    }

	// Read the BIN File
	if(!ReadFile(File, BinFileBuffer, BinFileSize, &BinFileSizeRead, NULL))
	{
		TCHAR Message[MAX_PATH] = {0};
		TCHAR ErrorMessage[MAX_PATH] = {0};

		dwError = GetLastError();
		GET_ERROR_MESSAGE(dwError, ErrorMessage, MAX_PATH);

		_stprintf_s(Message, MAX_PATH, L"ReadFile Failed: [%d] %s", dwError, ErrorMessage);
        LogMessage(Message);

		if(File)
		{
			CloseHandle(File);
			File = NULL;
		}

		Status = dwError;
		return Status;
	}

	// Write the BIN File Data
	WriteBinFileData(BinFilePath, BinFileBuffer, BinFileSizeRead);

	// Free the Buffer
	if(BinFileBuffer)
	{
		free(BinFileBuffer);
	}

	if(File)
	{
		CloseHandle(File);
		File = NULL;
	}

	return Status;
}
#endif

ULONG ReadFPGAReg(PTCHAR DevicePath, DWORD ConfigReg, DWORD *RegValue)
/*++
Routine Description:

    This routine Reads the Internal FPGA Register.

Arguments:

    DevicePath		Pointer to the Device Path
	ConfigReg		Offset of the FPGA Register to be read
	RegValue		Buffer to which the FPGA Register to be read into

Return Value:

     ULONG			Status 0 -Success, 1 - Faliure.
--*/
{

	ULONG Status = 0;

	DWORD BinFileBuffer[READ_CFG_REG_COMMAND_SIZE] = {};
	ULONG BinFileSizePostProcessing = READ_CFG_REG_COMMAND_SIZE*sizeof(DWORD);
	ULONG BinFileSizeWritten = 0;
	DWORD Index = 0;
	USER_WRITE_BUFFER userBuffer;
	PUCHAR dataBuffer;
	UINT totalSize = 0;
	
	userBuffer.USER_SPACE_BITSTREAM_TYPE.type = 0;
	userBuffer.USER_SPACE_BITSTREAM_TYPE.BIT.FIELD_UPDATE = 0;

	dataBuffer = (PUCHAR)malloc(BinFileSizePostProcessing + 12);
	if (!dataBuffer)
	{
		Status = ERROR_NOT_ENOUGH_MEMORY;
		LogMessage(L"Unable to Allocate Memory \n");
		return Status;
	}
	memcpy(dataBuffer, (void*)(&userBuffer.USER_SPACE_BITSTREAM_TYPE.type), 4);
	//_stprintf_s(Message, MAX_PATH, L"Buffer suze [%d]", BinFileSizePostProcessing);
	//LogMessage(L"Message");
	memset(dataBuffer + 4, 0, 4);
	//LogMessage(L"Inside Read FPGA Reg - 3\n");
	memcpy(dataBuffer + 8, (void*)&BinFileSizePostProcessing, 4);
	//LogMessage(L"Inside Read FPGA Reg - 4\n");
	
	// This is intercept from HW ICAP Driver
	// --- From Here ---
	BinFileBuffer[Index++] = XHI_DUMMY_PACKET;	// 0xFFFFFFFF
	BinFileBuffer[Index++] = XHI_SYNC_PACKET;	// 0xAA995566
	BinFileBuffer[Index++] = XHI_NOOP_PACKET;	// 0x20000000
	BinFileBuffer[Index++] = XHI_NOOP_PACKET;	// 0x20000000
	BinFileBuffer[Index++] = XHwIcap_Type1Read(ConfigReg) | 0x1;
	BinFileBuffer[Index++] = XHI_NOOP_PACKET;	// 0x20000000
	BinFileBuffer[Index++] = XHI_NOOP_PACKET;	// 0x20000000
	// --- To Here ---
	memcpy(dataBuffer + 12, (void*)BinFileBuffer, BinFileSizePostProcessing);
	totalSize = 12 + BinFileSizePostProcessing;
	/*for (int i = 0; i < 10; i++){
		_stprintf_s(Message, MAX_PATH, L" [%x]", *(PULONG)dataBuffer);
		LogMessage(Message);
		dataBuffer += 4;
	}*/
	Status = MCAPWriteDataToDevice(DevicePath, dataBuffer, totalSize, &BinFileSizeWritten);
	if (Status == 0){
		Status = ReadMCAPReg(DevicePath, REGRD1_REG_INDEX, RegValue);
	}
	else{
		return Status;
	}
	
	if (dataBuffer)
	{
		free(dataBuffer);
	}
	return Status;
}

ULONG ReadMCAPIOBARReg(PTCHAR DevicePath, DWORD RegIndex, DWORD *RegValue)
/*++
Routine Description:

    This routine Sends the IOCTL Request to the Read the MCAP IO BAR Register.

Arguments:

    DevicePath		Pointer to the Device Path
	RegIndex		Offset of the MCAP IO BAR Register to be read
	RegValue		Buffer to which the MCAP IO BAR Register to be read into

Return Value:

     ULONG			Status 0 -Success, 1 - Faliure.
--*/
{
	MCAP_IOCTL_REQ_RES Request = {0};
	MCAP_IOCTL_REQ_RES Response = {0};
	DWORD InLen = 0, OutLen = 0;
	ULONG Status = 0;
	DWORD BytesRet = 0;

	if(!DevicePath)
	{
		Status = ERROR_PATH_NOT_FOUND;
		LogMessage(L"Device Path is Null \n");
		return Status;
	}

	Request.mcapreq.mcapreadiobarreg.RegIndex = RegIndex;
	OutLen = InLen = sizeof(MCAP_IOCTL_REQ_RES);
	
	if(Status = GetDataFromDevice(DevicePath, IOCTL_READ_IOBAR_REG, &Request, InLen, &Response, OutLen, &BytesRet))
	{
		// Failed
		LogMessage(L"Read MCAP IO BAR Register Failed\n");
	}
	else
	{
		*RegValue = Response.mcapres.mcapreadiobarreg.RegValue;
	}

	return Status;
}

ULONG WriteMCAPIOBARReg(PTCHAR DevicePath, DWORD RegIndex, DWORD RegValue)
/*++
Routine Description:

    This routine Sends the IOCTL Request to the Write the MCAP IO BAR Register.

Arguments:

    DevicePath		Pointer to the Device Path
	RegIndex		Offset of the MCAP IO BAR Register to be written
	RegValue		Buffer from which the data to the MCAP IO BAR Register to be written

Return Value:

     ULONG			Status 0 -Success, 1 - Faliure.
--*/
{
	MCAP_IOCTL_REQ_RES Request = {0};
	PMCAP_IOCTL_REQ_RES Response = NULL;
	DWORD InLen = 0, OutLen = 0;
	ULONG Status = 0;
	DWORD BytesRet = 0;

	if(!DevicePath)
	{
		Status = ERROR_PATH_NOT_FOUND;
		LogMessage(L"Device Path is Null \n");
		return Status;
	}

	Request.mcapreq.mcapwriteiobarreg.RegIndex = RegIndex;
	Request.mcapreq.mcapwriteiobarreg.RegValue = RegValue;

	InLen = sizeof(MCAP_IOCTL_REQ_RES);

	if(Status = GetDataFromDevice(DevicePath, IOCTL_WRITE_IOBAR_REG, &Request, InLen, Response, OutLen, &BytesRet))
	{
		// Failed
		LogMessage(L"Write MCAP IO BAR Register Failed\n");
	}
	else
	{
		// Success
		//LogMessage(L"Write MCAP IO BAR Register Success \n");
	}

	return Status;
}

ULONG ReadMCAPMEMBARReg(PTCHAR DevicePath, DWORD RegIndex, DWORD *RegValue)
/*++
Routine Description:

    This routine Sends the IOCTL Request to the Read the MCAP MEM BAR Register.

Arguments:

    DevicePath		Pointer to the Device Path
	RegIndex		Offset of the MCAP MEM BAR Register to be read
	RegValue		Buffer to which the MCAP MEM BAR Register to be read into

Return Value:

     ULONG			Status 0 -Success, 1 - Faliure.
--*/
{
	MCAP_IOCTL_REQ_RES Request = {0};
	MCAP_IOCTL_REQ_RES Response = {0};
	DWORD InLen = 0, OutLen = 0;
	ULONG Status = 0;
	DWORD BytesRet = 0;

	if(!DevicePath)
	{
		Status = ERROR_PATH_NOT_FOUND;
		LogMessage(L"Device Path is Null \n");
		return Status;
	}

	Request.mcapreq.mcapreadmembarreg.RegIndex = RegIndex;
	OutLen = InLen = sizeof(MCAP_IOCTL_REQ_RES);
	
	if(Status = GetDataFromDevice(DevicePath, IOCTL_READ_MEMBAR_REG, &Request, InLen, &Response, OutLen, &BytesRet))
	{
		// Failed
		LogMessage(L"Read MCAP MEM BAR Register Failed\n");
	}
	else
	{
		*RegValue = Response.mcapres.mcapreadmembarreg.RegValue;
	}

	return Status;
}

ULONG WriteMCAPMEMBARReg(PTCHAR DevicePath, DWORD RegIndex, DWORD RegValue)
/*++
Routine Description:

    This routine Sends the IOCTL Request to the Write the MCAP MEM BAR Register.

Arguments:

    DevicePath		Pointer to the Device Path
	RegIndex		Offset of the MCAP MEM BAR Register to be written
	RegValue		Buffer from which the data to the MCAP MEM BAR Register to be written

Return Value:

     ULONG			Status 0 -Success, 1 - Faliure.
--*/
{
	MCAP_IOCTL_REQ_RES Request = {0};
	PMCAP_IOCTL_REQ_RES Response = NULL;
	DWORD InLen = 0, OutLen = 0;
	ULONG Status = 0;
	DWORD BytesRet = 0;

	if(!DevicePath)
	{
		Status = ERROR_PATH_NOT_FOUND;
		LogMessage(L"Device Path is Null \n");
		return Status;
	}

	Request.mcapreq.mcapwritemembarreg.RegIndex = RegIndex;
	Request.mcapreq.mcapwritemembarreg.RegValue = RegValue;

	InLen = sizeof(MCAP_IOCTL_REQ_RES);

	if(Status = GetDataFromDevice(DevicePath, IOCTL_WRITE_MEMBAR_REG, &Request, InLen, Response, OutLen, &BytesRet))
	{
		// Failed
		LogMessage(L"Write MCAP MEM BAR Register Failed\n");
	}
	else
	{
		// Success
		//LogMessage(L"Write MCAP MEM BAR Register Success \n");
	}

	return Status;
}
