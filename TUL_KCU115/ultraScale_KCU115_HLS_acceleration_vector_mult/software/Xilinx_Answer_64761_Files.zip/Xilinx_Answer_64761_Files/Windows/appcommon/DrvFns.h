/********************************************************************
*Copyright (C) 2014 � 2015 Xilinx, Inc.  All rights reserved.
*
*Permission is hereby granted, free of charge, to any person obtaining
*a copy of this software and associated documentation files (the
*"Software"), to deal in the Software without restriction, including
*without limitation the rights to use, copy, modify, merge, publish,
*distribute, sublicense, and/or sell copies of the Software, and to
*permit persons to whom the Software is furnished to do so, subject to
*the following conditions:
*
*The above copyright notice and this permission notice shall be 
*included in all copies or substantial portions of the Software.
*
*Use of the Software is limited solely to applications: (a) running 
*on a Xilinx device, or (b) that interact with a Xilinx device 
*through a bus or interconnect.  
*
*THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*NONINFRINGEMENT. IN NO EVENT SHALL XILINX BE LIABLE FOR ANY CLAIM, 
*DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
*OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
*OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*Except as contained in this notice, the name of the Xilinx shall
*not be used in advertising or otherwise to promote the sale, use or
*other dealings in this Software without prior written authorization
*from Xilinx.
*********************************************************************/
// DrvFns.h : This file contains defines and declarations for the functions
//				which are used to interact with the driver.

#ifndef _DRVFNS_H_
#define _DRVFNS_H_


#define GET_ERROR_MESSAGE(A, B, C)					\
{													\
	LPVOID lpMsgBuf;								\
													\
	FormatMessage(									\
		FORMAT_MESSAGE_ALLOCATE_BUFFER |			\
		FORMAT_MESSAGE_FROM_SYSTEM |				\
		FORMAT_MESSAGE_IGNORE_INSERTS,				\
		NULL,										\
		A,											\
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),	\
		(LPTSTR) &lpMsgBuf,							\
		0, NULL );									\
													\
	_stprintf_s(B, C, L"%s", lpMsgBuf);				\
													\
	LocalFree(lpMsgBuf);							\
}													\

#define PCI_TYPE0_ADDRESSES             6
typedef struct _PCI_COMMON_CONFIG {
  USHORT VendorID;
  USHORT DeviceID;
  USHORT Command;
  USHORT Status;
  UCHAR  RevisionID;
  UCHAR  ProgIf;
  UCHAR  SubClass;
  UCHAR  BaseClass;
  UCHAR  CacheLineSize;
  UCHAR  LatencyTimer;
  UCHAR  HeaderType;
  UCHAR  BIST;
  union {
    struct {
      ULONG BaseAddresses[PCI_TYPE0_ADDRESSES];
      ULONG Reserved1[2];
      ULONG ROMBaseAddress;
      ULONG Reserved2[2];
      UCHAR InterruptLine;
      UCHAR InterruptPin;
      UCHAR MinimumGrant;
      UCHAR MaximumLatency;
    } type0;
  } u;
  UCHAR  DeviceSpecific[192];
} PCI_COMMON_CONFIG, *PPCI_COMMON_CONFIG;

typedef struct  _USER_WRITE_BUFFER {
    union {
        unsigned long type;
        struct {
			unsigned long FIELD_UPDATE:1;
            unsigned long MULTIPLE_BITSTREAM:1;
            unsigned long CLEAR_BITSTREAM:1;
            unsigned long FULL_BITSTREAM:1;
			unsigned long :28;
        } BIT;
    } USER_SPACE_BITSTREAM_TYPE;
	unsigned long clear_bitstream_length;
	unsigned long full_bitstream_length;
	PVOID         data;
} USER_WRITE_BUFFER, *PUSER_WRITE_BUFFER;

// --- From Here ---
// This is intercept from HW ICAP Driver
#define READ_CFG_REG_COMMAND_SIZE 7
#define XHI_DUMMY_PACKET	0xFFFFFFFF
#define XHI_SYNC_PACKET		0xAA995566
#define XHI_NOOP_PACKET		0x20000000
#define XHI_NOOP_PACKET		0x20000000
#define XHI_NOOP_PACKET		0x20000000
#define XHI_NOOP_PACKET		0x20000000

#define XHI_TYPE_1				1
#define XHI_TYPE_SHIFT			29
#define XHI_REGISTER_SHIFT		13
#define XHI_OP_SHIFT			27
#define XHI_OP_READ				1
#define XHI_NUM_REGISTERS		25 // Not Continuous (0-17, 22 24)

#define XHwIcap_Type1Read(Register) \
	( (XHI_TYPE_1 << XHI_TYPE_SHIFT) | (Register << XHI_REGISTER_SHIFT) | \
	(XHI_OP_READ << XHI_OP_SHIFT) )

// --- To Here ---

ULONG GetDataFromDevice(PTCHAR DevicePath, DWORD dwIoControlCode, 
						PMCAP_IOCTL_REQ_RES pMCAPReq, DWORD InLen, 
						PMCAP_IOCTL_REQ_RES pMCAPResp, DWORD OutLen, 
						PDWORD BytesReturned);

ULONG ReadPCIConfigSpace(PTCHAR DevicePath, DWORD RegIndex, DWORD Length, PVOID Buffer);

ULONG WritePCIConfigSpace(PTCHAR DevicePath, DWORD RegIndex, DWORD Length, PVOID Buffer);

ULONG ReadMCAPReg(PTCHAR DevicePath, DWORD RegIndex, DWORD *RegValue);

ULONG WriteMCAPReg(PTCHAR DevicePath, DWORD RegIndex, DWORD RegValue);

ULONG ReadMCAPIOBARReg(PTCHAR DevicePath, DWORD RegIndex, DWORD *RegValue);

ULONG WriteMCAPIOBARReg(PTCHAR DevicePath, DWORD RegIndex, DWORD RegValue);

ULONG ReadMCAPMEMBARReg(PTCHAR DevicePath, DWORD RegIndex, DWORD *RegValue);

ULONG WriteMCAPMEMBARReg(PTCHAR DevicePath, DWORD RegIndex, DWORD RegValue);

ULONG WriteControlReg(PTCHAR DevicePath, DWORD RegValue);

ULONG ReadControlReg(PTCHAR DevicePath, DWORD *RegValue);

ULONG ReadStatusReg(PTCHAR DevicePath, DWORD *RegValue);

ULONG MCAPReset(PTCHAR DevicePath);

ULONG MCAPModuleReset(PTCHAR DevicePath);

ULONG MCAPFullReset(PTCHAR DevicePath);

ULONG MCAPWriteBinFile(PTCHAR DevicePath, PTCHAR ClearBinFilePath, PTCHAR ProgramBinFilePath);

ULONG MCAPWriteDataToDevice(PTCHAR DevicePath, PVOID BinFileBuffer, ULONG BinFileSizePostProcessing, PULONG BinFileSizeWritten);

#if 0
ULONG MCAPReadBinFile(PTCHAR DevicePath, PTCHAR BinFilePath);
#endif

ULONG ReadFPGAReg(PTCHAR DevicePath, DWORD ConfigReg, DWORD *RegValue);

#endif // _DRVFNS_H_