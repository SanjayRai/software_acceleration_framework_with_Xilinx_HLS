// ConfigStatusDialog.cpp : implementation file
//

#include "stdafx.h"
#include "MCAPAPPGUI.h"
#include "ConfigStatusDialog.h"
#include "afxdialogex.h"


// CConfigStatusDialog dialog

IMPLEMENT_DYNAMIC(CConfigStatusDialog, CDialog)

CConfigStatusDialog::CConfigStatusDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CConfigStatusDialog::IDD, pParent)
{

}

CConfigStatusDialog::~CConfigStatusDialog()
{
}

void CConfigStatusDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

void CConfigStatusDialog::PostNcDestroy(){
	CDialog::PostNcDestroy();
	delete this;
}

BEGIN_MESSAGE_MAP(CConfigStatusDialog, CDialog)
END_MESSAGE_MAP()


// CConfigStatusDialog message handlers
