
// MCAPAPPGUIDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MCAPAPPGUI.h"
#include "MCAPAPPGUIDlg.h"
#include "DlgProxy.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

extern int IsLogEnabled;

// CMCAPAPPGUIDlg dialog

IMPLEMENT_DYNAMIC(CMCAPAPPGUIDlg, CDialog);

CMCAPAPPGUIDlg::CMCAPAPPGUIDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMCAPAPPGUIDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pAutoProxy = NULL;
}

CMCAPAPPGUIDlg::~CMCAPAPPGUIDlg()
{
	// If there is an automation proxy for this dialog, set
	//  its back pointer to this dialog to NULL, so it knows
	//  the dialog has been deleted.
	if (m_pAutoProxy != NULL)
		m_pAutoProxy->m_pDialog = NULL;
}

void CMCAPAPPGUIDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_DEVSEL, SelDeviceComboCtrl);
}

BEGIN_MESSAGE_MAP(CMCAPAPPGUIDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_CLOSE()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_REFRESH, &CMCAPAPPGUIDlg::OnBnClickedButtonRefresh)
	ON_CBN_SELCHANGE(IDC_COMBO_DEVSEL, &CMCAPAPPGUIDlg::OnCbnSelchangeComboDevsel)
	ON_BN_CLICKED(IDC_BUTTON_SELFILE, &CMCAPAPPGUIDlg::OnBnClickedButtonSelfile)
	ON_BN_CLICKED(IDC_BUTTON_PROGBIN, &CMCAPAPPGUIDlg::OnBnClickedButtonProgbin)
	ON_BN_CLICKED(IDC_BUTTON_APPLY, &CMCAPAPPGUIDlg::OnBnClickedButtonApply)
	ON_BN_CLICKED(IDC_BUTTON_RESET, &CMCAPAPPGUIDlg::OnBnClickedButtonReset)
	ON_BN_CLICKED(IDC_BUTTON_MODRESET, &CMCAPAPPGUIDlg::OnBnClickedButtonModreset)
	ON_BN_CLICKED(IDC_BUTTON_FULLRESET, &CMCAPAPPGUIDlg::OnBnClickedButtonFullreset)
	ON_BN_CLICKED(IDC_CHECK_GENLOG, &CMCAPAPPGUIDlg::OnBnClickedCheckGenlog)
	ON_BN_CLICKED(IDC_BUTTON_PCICONFIG_GET, &CMCAPAPPGUIDlg::OnBnClickedButtonPciconfigGet)
	ON_BN_CLICKED(IDC_BUTTON_PCICONFIG_SET, &CMCAPAPPGUIDlg::OnBnClickedButtonPciconfigSet)
	ON_BN_CLICKED(IDC_BUTTON_READFPGA, &CMCAPAPPGUIDlg::OnBnClickedButtonReadfpga)
//	ON_BN_CLICKED(IDC_BUTTON_IOBAR_GET, &CMCAPAPPGUIDlg::OnBnClickedButtonIobarGet)
//	ON_BN_CLICKED(IDC_BUTTON_IOBAR_SET, &CMCAPAPPGUIDlg::OnBnClickedButtonIobarSet)
//	ON_BN_CLICKED(IDC_BUTTON_MEMBAR_GET, &CMCAPAPPGUIDlg::OnBnClickedButtonMembarGet)
//	ON_BN_CLICKED(IDC_BUTTON_MEMBAR_SET, &CMCAPAPPGUIDlg::OnBnClickedButtonMembarSet)
	//ON_UPDATE_COMMAND_UI(UWM_THREAD_START, &CMCAPAPPGUIDlg::onThreadStart)
	//ON_UPDATE_COMMAND_UI(UWM_THREAD_STOP, &CMCAPAPPGUIDlg::onThreadStop)

	ON_BN_CLICKED(IDC_RADIO_PCIE, &CMCAPAPPGUIDlg::OnBnClickedRadioPcie)
	ON_BN_CLICKED(IDC_RADIO_FIELDSET, &CMCAPAPPGUIDlg::OnBnClickedRadioFieldset)
	ON_BN_CLICKED(IDC_BUTTON_CLEARSELFILE, &CMCAPAPPGUIDlg::OnBnClickedButtonClearselfile)
END_MESSAGE_MAP()


// CMCAPAPPGUIDlg message handlers

BOOL CMCAPAPPGUIDlg::OnInitDialog()
{
	CDialog::OnInitDialog();


	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	// Populate the Devices
	PopulateMCAPDevices();

	// Set Max Lengths
	((CEdit *)GetDlgItem(IDC_EDIT_MCAP_CTRL))->SetLimitText(8);
	((CEdit *)GetDlgItem(IDC_EDIT_MCAP_DATAREG))->SetLimitText(8);
	((CEdit *)GetDlgItem(IDC_EDIT_PCICONFIG_VALUE))->SetLimitText(2);
	((CEdit *)GetDlgItem(IDC_EDIT_PCICONFIG_LEN))->SetLimitText(4);
	((CEdit *)GetDlgItem(IDC_EDIT_PCICONFIG_OFFSET))->SetLimitText(4);
	//((CEdit *)GetDlgItem(IDC_EDIT_REAADFPGA_OFFSET))->SetLimitText(4);

	//((CEdit *)GetDlgItem(IDC_EDIT_IOBAR_OFFSET))->SetLimitText(4);
	//((CEdit *)GetDlgItem(IDC_EDIT_MEMBAR_OFFSET))->SetLimitText(4);
	//((CEdit *)GetDlgItem(IDC_EDIT_IOBAR_VAL))->SetLimitText(8);
	//((CEdit *)GetDlgItem(IDC_EDIT_MEMBAR_VAL))->SetLimitText(8);
	((CButton *)GetDlgItem(IDC_RADIO_PCIE))->SetCheck(true);
	GetDlgItem(IDC_EDIT_CLEARSTREAMFILE)->EnableWindow(false);
	GetDlgItem(IDC_BUTTON_CLEARSELFILE)->EnableWindow(false);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMCAPAPPGUIDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	CDialog::OnSysCommand(nID, lParam);
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMCAPAPPGUIDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMCAPAPPGUIDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

// Automation servers should not exit when a user closes the UI
//  if a controller still holds on to one of its objects.  These
//  message handlers make sure that if the proxy is still in use,
//  then the UI is hidden but the dialog remains around if it
//  is dismissed.

void CMCAPAPPGUIDlg::OnClose()
{
	if (CanExit())
		CDialog::OnClose();
}

BOOL CMCAPAPPGUIDlg::CanExit()
{
	// If the proxy object is still around, then the automation
	//  controller is still holding on to this application.  Leave
	//  the dialog around, but hide its UI.
	if (m_pAutoProxy != NULL)
	{
		ShowWindow(SW_HIDE);
		return FALSE;
	}

	return TRUE;
}

// This Functions Populates the MCAP Devices Available in the system
int CMCAPAPPGUIDlg::PopulateMCAPDevices()
{
    ULONG size;
	ULONG Status;
    int count, i;
    TCHAR *DeviceName = NULL;
    TCHAR *DeviceLocation = NULL;
	HDEVINFO hDevInfo = NULL;

	SP_DEVICE_INTERFACE_DATA DeviceInterfaceData = {0};
	SP_DEVINFO_DATA DeviceInfoData = {0};
	PSP_DEVICE_INTERFACE_DETAIL_DATA pDeviceInterfaceDetail = NULL;

    //
    //  Retreive the Device Information for all MCAP Devices.
    //
    hDevInfo = SetupDiGetClassDevs(&GUID_MCAP_INTERFACE,
                                   NULL,
                                   NULL,
                                   DIGCF_DEVICEINTERFACE |
                                   DIGCF_PRESENT);

    //
    //  Initialize the SP_DEVICE_INTERFACE_DATA Structure.
    //
    DeviceInterfaceData.cbSize  = sizeof(SP_DEVICE_INTERFACE_DATA);

    //
    //  Determine How Many Devices Are Present.
    //
    count = 0;
    while(SetupDiEnumDeviceInterfaces(hDevInfo,
                                      NULL,
                                      &GUID_MCAP_INTERFACE,
                                      count++,  //Cycle through the available devices.
                                      &DeviceInterfaceData)
          );

    //
    // Since the last call fails when all devices have been enumerated,
    // decrement the count to get the true device count.
    //
    count--;

    //
    //  If the count is zero then there are no devices present.
    //
    if (count == 0)
	{
        LogMessage(L"No Xilinx MCAP devices are present and enabled in the system.\n");
        Status = 1;
        return Status;
    }

	// Allocate Memory
	// Each MAX_PATH for DeviceName, DeviceLocation and DevicePath
	DeviceDataInfo = (struct _DeviceDataInfo_ *)malloc(count*sizeof(struct _DeviceDataInfo_));
	if(!DeviceDataInfo)
	{
        LogMessage(L"Unable to allocate memory.\n");
        Status = 1;
        return Status;
	}

    //
    //  Initialize the Appropriate Data Structures in Preparation for
    //  the SetupDi Calls.
    //
    DeviceInterfaceData.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);
    DeviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);

    //
    //  Loop through the device list to allow user to choose
    //  a device.  If there is only one device, select it
    //  by default.
    //
    i = 0;
    while (SetupDiEnumDeviceInterfaces(hDevInfo,
                                       NULL,
                                       (LPGUID)&GUID_MCAP_INTERFACE,
                                       i,
                                       &DeviceInterfaceData))
	{
        //
        // Determine the size required for the DeviceInterfaceData
        //
        SetupDiGetDeviceInterfaceDetail(hDevInfo,
                                        &DeviceInterfaceData,
                                        NULL,
                                        0,
                                        &size,
                                        NULL);

        if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
		{
			TCHAR Message[MAX_PATH] = {0};

			_stprintf_s(Message, MAX_PATH, L"SetupDiGetDeviceInterfaceDetail failed, Error: %u", GetLastError());
            LogMessage(Message);
            Status = 1;
            return Status;
        }

        pDeviceInterfaceDetail = (PSP_DEVICE_INTERFACE_DETAIL_DATA) malloc(size);

        if (!pDeviceInterfaceDetail)
		{
            LogMessage(L"Insufficient memory.\n");
            Status = 1;
            return Status;
        }

        //
        // Initialize structure and retrieve data.
        //
        pDeviceInterfaceDetail->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
        Status = SetupDiGetDeviceInterfaceDetail(hDevInfo,
                                                 &DeviceInterfaceData,
                                                 pDeviceInterfaceDetail,
                                                 size,
                                                 NULL,
                                                 &DeviceInfoData);

        if (!Status)
		{
			TCHAR Message[MAX_PATH] = {0};

			_stprintf_s(Message, MAX_PATH, L"SetupDiGetDeviceInterfaceDetail failed, Error: %u", GetLastError());
            LogMessage(Message);

            Status = 1;
            return Status;
        }

        //
        //  Get the Device Name
        //  Calls to SetupDiGetDeviceRegistryProperty require two consecutive
        //  calls, first to get required buffer size and second to get
        //  the data.
        //
        SetupDiGetDeviceRegistryProperty(hDevInfo,
                                        &DeviceInfoData,
                                        SPDRP_DEVICEDESC,
                                        NULL,
                                        (PBYTE)DeviceName,
                                        0,
                                        &size);

        if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
		{
			TCHAR Message[MAX_PATH] = {0};

			_stprintf_s(Message, MAX_PATH, L"SetupDiGetDeviceRegistryProperty failed, Error: %u", GetLastError());
            LogMessage(Message);

            Status = 1;
            return Status;
        }

        DeviceName = (TCHAR*) malloc(size);
        if (!DeviceName)
		{
			LogMessage(L"Insufficient memory.\n");
            Status = 1;
            return Status;
        }

        Status = SetupDiGetDeviceRegistryProperty(hDevInfo,
                                                  &DeviceInfoData,
                                                  SPDRP_DEVICEDESC,
                                                  NULL,
                                                  (PBYTE)DeviceName,
                                                  size,
                                                  NULL);
        if (!Status)
		{
			TCHAR Message[MAX_PATH] = {0};

			_stprintf_s(Message, MAX_PATH, L"SetupDiGetDeviceRegistryProperty failed, Error: %u", GetLastError());
            LogMessage(Message);

            free(DeviceName);
            Status = 1;
            return Status;
        }

        //
        //  Now retrieve the Device Location.
        //
        SetupDiGetDeviceRegistryProperty(hDevInfo,
                                         &DeviceInfoData,
                                         SPDRP_LOCATION_INFORMATION,
                                         NULL,
                                         (PBYTE)DeviceLocation,
                                         0,
                                         &size);

        if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
		{
			TCHAR Message[MAX_PATH] = {0};

			_stprintf_s(Message, MAX_PATH, L"SetupDiGetDeviceRegistryProperty failed, Error: %u", GetLastError());
            LogMessage(Message);

            Status = 1;
            return Status;
		}

		DeviceLocation = (TCHAR*) malloc(size);
		if (!DeviceLocation) {

			LogMessage(L"Insufficient memory.\n");
            Status = 1;
            return Status;
		}
			
		Status = SetupDiGetDeviceRegistryProperty(hDevInfo,
												&DeviceInfoData,
												SPDRP_LOCATION_INFORMATION,
												NULL,
												(PBYTE)DeviceLocation,
												size,
												NULL);
        if (!Status)
		{
			TCHAR Message[MAX_PATH] = {0};

			_stprintf_s(Message, MAX_PATH, L"SetupDiGetDeviceRegistryProperty failed, Error: %u", GetLastError());
            LogMessage(Message);

			free(DeviceLocation);

			Status = 1;
            return Status;
        }

        //
        // Update the device information.
        //
		TCHAR Message[4*MAX_PATH] = {0};

		_tcscpy_s(DeviceDataInfo[i].DeviceLocation, MAX_PATH, DeviceLocation);
		_tcscpy_s(DeviceDataInfo[i].DeviceName, MAX_PATH, DeviceName);
		_tcscpy_s(DeviceDataInfo[i].DevicePath, MAX_PATH, pDeviceInterfaceDetail->DevicePath);

		_stprintf_s(Message, 4*MAX_PATH, L"[%d]    [%s]    [%s]", i, DeviceName, DeviceLocation);
		SelDeviceComboCtrl.AddString(Message);

		if (pDeviceInterfaceDetail)
		{
			free(pDeviceInterfaceDetail);
			pDeviceInterfaceDetail = NULL;
		}

		if (DeviceLocation)
		{
			free(DeviceName);
			DeviceName = NULL;
		}

		if (DeviceLocation)
		{
			free(DeviceLocation);
			DeviceLocation = NULL;
		}

        i++; // Cycle through the available devices.
    }

	return Status;
}

void CMCAPAPPGUIDlg::OnCbnSelchangeComboDevsel()
{
	int Selection = SelDeviceComboCtrl.GetCurSel();
	if(Selection < 0)
	{
		AfxMessageBox(L"Please Select the device", MB_ICONERROR);
		return;
	}

	PopulatePCIConfigRegs(DeviceDataInfo[Selection].DevicePath);
	PopulateMCAPRegs(DeviceDataInfo[Selection].DevicePath);
	ReadFPGARegisters();
}

// Populates the PCI Config Registers for the Given Device
void CMCAPAPPGUIDlg::PopulatePCIConfigRegs(PTCHAR DevicePath)
{
	ULONG Status = 0;
	CString Text;

	if(!DevicePath)
	{
		TCHAR Message[MAX_PATH] = {0};

		_stprintf_s(Message, MAX_PATH, L"DevicePath is NULL");
        LogMessage(Message);
		return;
	}

	PCI_COMMON_CONFIG Buffer = {0};

	Status = ReadPCIConfigSpace(
				DevicePath,
				FIELD_OFFSET(PCI_COMMON_CONFIG, VendorID), 
				sizeof(PCI_COMMON_CONFIG),
				&Buffer);
	if(!Status)
	{
		CString str;

		Text.Format(L"\t\tPCI Configuration Space\t\t\r\n");
		str+=Text;
		Text.Format(L"\r\n Vendor ID:\t%04x", Buffer.VendorID);
		str+=Text;
		Text.Format(L"\t Device ID:\t%04x", Buffer.DeviceID);
		str+=Text;
		Text.Format(L"\r\n Command:\t%04x", Buffer.Command);
		str+=Text;
		Text.Format(L"\t Status:\t\t%04x", Buffer.Status);
		str+=Text;
		Text.Format(L"\r\n Revision ID:\t%02x", Buffer.RevisionID);
		str+=Text;
		Text.Format(L"\t Base Class:\t%02x", Buffer.BaseClass);
		str+=Text;
		Text.Format(L"\r\n Sub Class:\t%02x", Buffer.SubClass);
		str+=Text;
		Text.Format(L"\t ProgIf:\t\t%02x", Buffer.ProgIf);
		str+=Text;
		Text.Format(L"\r\n Cache Line Size:\t%02x", Buffer.CacheLineSize);
		str+=Text;
		Text.Format(L"\t Latency Timer:\t%02x", Buffer.LatencyTimer);
		str+=Text;
		Text.Format(L"\r\n Header Type:\t%02x", Buffer.HeaderType);
		str+=Text;
		Text.Format(L"\t BIST:\t\t%02x", Buffer.BIST);
		str+=Text;
		Text.Format(L"\r\n Interrupt Line:\t%02x", Buffer.u.type0.InterruptLine);
		str+=Text;
		Text.Format(L"\t Interrupt Pin:\t%02x", Buffer.u.type0.InterruptPin);
		str+=Text;
		Text.Format(L"\r\n Minimum Grant:\t%02x", Buffer.u.type0.MinimumGrant);
		str+=Text;
		Text.Format(L"\t Maximum Latency:\t%02x", Buffer.u.type0.MaximumLatency);
		str+=Text;
		Text.Format(L"\r\n ROM Base Addr:\t%08x", Buffer.u.type0.ROMBaseAddress);
		str+=Text;
		Text.Format(L"\r\n BAR 0:\t%08x", Buffer.u.type0.BaseAddresses[0]);
		str+=Text;
		Text.Format(L"\t\t BAR 1:\t%08x", Buffer.u.type0.BaseAddresses[1]);
		str+=Text;
		Text.Format(L"\r\n BAR 2:\t%08x", Buffer.u.type0.BaseAddresses[2]);
		str+=Text;
		Text.Format(L"\t BAR 3:\t%08x", Buffer.u.type0.BaseAddresses[3]);
		str+=Text;
		Text.Format(L"\r\n BAR 4:\t%08x", Buffer.u.type0.BaseAddresses[4]);
		str+=Text;
		Text.Format(L"\t BAR 5:\t%08x", Buffer.u.type0.BaseAddresses[5]);
		str+=Text;
		Text.Format(L"\r\n Rsvd:\t%08x", Buffer.u.type0.Reserved1[0]);
		str+=Text;
		Text.Format(L"\t Rsvd:\t%08x", Buffer.u.type0.Reserved1[1]);
		str+=Text;
		Text.Format(L"\r\n Rsvd:\t%08x", Buffer.u.type0.Reserved2[0]);
		str+=Text;
		Text.Format(L"\t Rsvd:\t%08x", Buffer.u.type0.Reserved2[1]);
		str+=Text;

		GetDlgItem(IDC_EDIT_PCIINFO)->SetWindowTextW(str);
	}
	else
	{
		CString str;

		Text.Format(L"\t\tPCI Configuration Space\t\t\r\n");
		str+=Text;
		Text.Format(L"\n\r\t\tINVALID DATA\t\t\r\n");
		str+=Text;

		GetDlgItem(IDC_EDIT_PCIINFO)->SetWindowTextW(str);
		ReadFPGARegisters();
	}
}

// This will populate the MCAP Register of the given Device
void CMCAPAPPGUIDlg::PopulateMCAPRegs(PTCHAR DevicePath)
{
	ULONG Status;

	if(!DevicePath)
	{
		TCHAR Message[MAX_PATH] = {0};

		_stprintf_s(Message, MAX_PATH, L"DevicePath is NULL");
        LogMessage(Message);
		return;
	}

	MCAP_REGS MCAPRegsBuffer = {0};
	for(DWORD i = 0;i < MCAP_REGISTERS_COUNT;i++)
	{
		Status = ReadMCAPReg(DevicePath, i, &MCAPRegsBuffer.mcapregvals[i]);
		if(Status)
		{
			ReadFPGARegisters();
		}
	}

	CString Text;

	Text.Format(L"%08x", MCAPRegsBuffer.mcapregvals[PEC_REG_INDEX]);
	GetDlgItem(IDC_EDIT_MCAP_PECH)->SetWindowTextW(Text);

	Text.Format(L"%08x", MCAPRegsBuffer.mcapregvals[VSH_REG_INDEX]);
	GetDlgItem(IDC_EDIT_MCAP_VSH)->SetWindowTextW(Text);

	Text.Format(L"%08x", MCAPRegsBuffer.mcapregvals[FJI_REG_INDEX]);
	GetDlgItem(IDC_EDIT_MCAP_JTI)->SetWindowTextW(Text);

	Text.Format(L"%08x", MCAPRegsBuffer.mcapregvals[FBSV_REG_INDEX]);
	GetDlgItem(IDC_EDIT_MCAP_FBSV)->SetWindowTextW(Text);

	Text.Format(L"%08x", MCAPRegsBuffer.mcapregvals[STAT_REG_INDEX]);
	GetDlgItem(IDC_EDIT_MCAP_STATUS)->SetWindowTextW(Text);

	Text.Format(L"%08x", MCAPRegsBuffer.mcapregvals[CTRL_REG_INDEX]);
	GetDlgItem(IDC_EDIT_MCAP_CTRL)->SetWindowTextW(Text);

	Text.Format(L"%08x", MCAPRegsBuffer.mcapregvals[DATA_REG_INDEX]);
	GetDlgItem(IDC_EDIT_MCAP_DATAREG)->SetWindowTextW(Text);

	Text.Format(L"%08x", MCAPRegsBuffer.mcapregvals[REGRD1_REG_INDEX]);
	GetDlgItem(IDC_EDIT_MCAP_RDR1)->SetWindowTextW(Text);

	Text.Format(L"%08x", MCAPRegsBuffer.mcapregvals[REGRD2_REG_INDEX]);
	GetDlgItem(IDC_EDIT_MCAP_RDR2)->SetWindowTextW(Text);

	Text.Format(L"%08x", MCAPRegsBuffer.mcapregvals[REGRD3_REG_INDEX]);
	GetDlgItem(IDC_EDIT_MCAP_RDR3)->SetWindowTextW(Text);

	Text.Format(L"%08x", MCAPRegsBuffer.mcapregvals[REGRD4_REG_INDEX]);
	GetDlgItem(IDC_EDIT_MCAP_RDR4)->SetWindowTextW(Text);
}

void CMCAPAPPGUIDlg::OnBnClickedButtonRefresh()
{
	int Selection = SelDeviceComboCtrl.GetCurSel();
	if(Selection < 0)
	{
		AfxMessageBox(L"Please Select the device", MB_ICONERROR);
		return;
	}

	PopulateMCAPRegs(DeviceDataInfo[Selection].DevicePath);
}

void CMCAPAPPGUIDlg::OnBnClickedButtonSelfile()
{
	TCHAR szFilters[]= _T("BitStream Files (*.bin;*bit;*.rbt)|*.bin;*bit;*.rbt|All Files (*.*)|*.*|");

	CFileDialog FileDialog(TRUE, // Open File Dialog
							_T("bin"), // File Extension
							NULL, // Initial File Name
							OFN_FILEMUSTEXIST, // Flags
							szFilters, // Filters
							this, // Parent
							0, // Size
							TRUE); // Vista

	if(FileDialog.DoModal() == IDOK)
	{
		// Selected a File
		CString FullFolderPath;

		FullFolderPath = FileDialog.GetPathName();
		GetDlgItem(IDC_EDIT_BITSTREAMFILE)->SetWindowTextW(FullFolderPath);
	}
}

UINT RunMyThread(void *pParam){
	ULONG Status = 0;
	CMCAPAPPGUIDlg* pThis = (CMCAPAPPGUIDlg*)pParam;
	Status = pThis->ProgramBin();	
	return 0;
}

ULONG CMCAPAPPGUIDlg::ProgramBin(){
	CString ClearFullFolderPath;
	CString ProgramFullFolderPath;
	int Selection = SelDeviceComboCtrl.GetCurSel();
	ULONG Status = 0;
	if (GetDlgItem(IDC_EDIT_CLEARSTREAMFILE)->IsWindowEnabled()){
		GetDlgItem(IDC_EDIT_BITSTREAMFILE)->GetWindowTextW(ProgramFullFolderPath);
		GetDlgItem(IDC_EDIT_CLEARSTREAMFILE)->GetWindowTextW(ClearFullFolderPath);
		Status = MCAPWriteBinFile(DeviceDataInfo[Selection].DevicePath, ClearFullFolderPath.GetBuffer(), ProgramFullFolderPath.GetBuffer());
	}
	else{
		GetDlgItem(IDC_EDIT_BITSTREAMFILE)->GetWindowTextW(ProgramFullFolderPath);
		Status = MCAPWriteBinFile(DeviceDataInfo[Selection].DevicePath, NULL, ProgramFullFolderPath.GetBuffer());
	}
	
	GetDlgItem(IDC_BUTTON_PROGBIN)->EnableWindow(TRUE);
	if (Status == 0){
		AfxMessageBox(L"Stage-2 FPGA Configuration Successful", MB_ICONINFORMATION);
	}
	else{
		AfxMessageBox(L"Stage-2 FPGA Configuration Failed", MB_ICONERROR);
	}
	if (Status)
	{
		ReadFPGARegisters();
	}

	PopulateMCAPRegs(DeviceDataInfo[Selection].DevicePath);
	return Status;
}
// This function programs the selected file.
void CMCAPAPPGUIDlg::OnBnClickedButtonProgbin()
{
	CString ClearFullFolderPath = NULL;
	CString ProgramFullFolderPath;
	ULONG Status = 0;

	if (GetDlgItem(IDC_EDIT_CLEARSTREAMFILE)->IsWindowEnabled()){
		GetDlgItem(IDC_EDIT_CLEARSTREAMFILE)->GetWindowTextW(ClearFullFolderPath);
		// Check whether program bin file is also selected
		GetDlgItem(IDC_EDIT_BITSTREAMFILE)->GetWindowTextW(ProgramFullFolderPath);
		if (ProgramFullFolderPath.GetLength() && ClearFullFolderPath.GetLength())
		{
			// Program the Bin File
			int Selection = SelDeviceComboCtrl.GetCurSel();
			if (Selection < 0)
			{
				AfxMessageBox(L"Please Select the device", MB_ICONERROR);
				return;
			}
			GetDlgItem(IDC_BUTTON_PROGBIN)->EnableWindow(FALSE);
			//AfxBeginThread(RunMyThread, this);
			//openDialog();
			Status = ProgramBin();
		}
		else
		{
			AfxMessageBox(_T("Make sure you select both Bitstream files (.bin/.bit/.rbt)"), MB_OK | MB_ICONERROR);
		}
	}
	else{
		GetDlgItem(IDC_EDIT_BITSTREAMFILE)->GetWindowTextW(ProgramFullFolderPath);

		if (ProgramFullFolderPath.GetLength())
		{
			// Program the Bin File
			int Selection = SelDeviceComboCtrl.GetCurSel();
			if (Selection < 0)
			{
				AfxMessageBox(L"Please Select the device", MB_ICONERROR);
				return;
			}
			GetDlgItem(IDC_BUTTON_PROGBIN)->EnableWindow(FALSE);
			//AfxBeginThread(RunMyThread, this);
			//openDialog();
			Status = ProgramBin();
		}
		else
		{
			AfxMessageBox(_T("Please Select Partial Bitstream File (.bin/.bit/.rbt)"), MB_OK | MB_ICONERROR);
		}
	}
}

// This function writes the MCAP Register to the specified control and Data registers
void CMCAPAPPGUIDlg::OnBnClickedButtonApply()
{
	CString CtrlReg, DataReg;
	DWORD dwCtrlReg = 0, dwDataReg = 0;
	ULONG Status;

	GetDlgItem(IDC_EDIT_MCAP_DATAREG)->GetWindowTextW(DataReg);
	if(!DataReg.GetLength())
	{
		AfxMessageBox(L"Data Register is Empty", MB_ICONERROR);
		return;
	}

	for(int i=0;i<DataReg.GetLength();i++)
	{
		if(!_istxdigit(DataReg.GetAt(i)))
		{
			CString Message = L" is not a Hex Value";
			AfxMessageBox(DataReg+Message, MB_ICONERROR);
			return;
		}
	}
	dwDataReg = wcstoul(DataReg.GetBuffer(), NULL, 16);

	GetDlgItem(IDC_EDIT_MCAP_CTRL)->GetWindowTextW(CtrlReg);
	if(!CtrlReg.GetLength())
	{
		AfxMessageBox(L"Control Register is Empty", MB_ICONERROR);
		return;
	}

	for(int i=0;i<CtrlReg.GetLength();i++)
	{
		if(!_istxdigit(CtrlReg.GetAt(i)))
		{
			CString Message = L" is not a Hex Value";
			AfxMessageBox(CtrlReg+Message, MB_ICONERROR);
			return;
		}
	}
	dwCtrlReg = wcstoul(CtrlReg.GetBuffer(), NULL, 16);

	int Selection = SelDeviceComboCtrl.GetCurSel();
	if(Selection < 0)
	{
		AfxMessageBox(L"Please Select the device", MB_ICONERROR);
		return;
	}

	Status = WriteMCAPReg(DeviceDataInfo[Selection].DevicePath, CTRL_REG_INDEX, dwCtrlReg);
	if(Status)
	{
		ReadFPGARegisters();
	}

	Status = WriteMCAPReg(DeviceDataInfo[Selection].DevicePath, DATA_REG_INDEX, dwDataReg);
	if(Status)
	{
		ReadFPGARegisters();
	}

	// Updaate the MCAP Regs
	PopulateMCAPRegs(DeviceDataInfo[Selection].DevicePath);
}

// This function send the reset to the device
void CMCAPAPPGUIDlg::OnBnClickedButtonReset()
{
	ULONG Status;

	int Selection = SelDeviceComboCtrl.GetCurSel();
	if(Selection < 0)
	{
		AfxMessageBox(L"Please Select the device", MB_ICONERROR);
		return;
	}

	Status = MCAPReset(DeviceDataInfo[Selection].DevicePath);
	if(Status)
	{
		ReadFPGARegisters();
	}

	return;
}

// This function send the module reset to the device
void CMCAPAPPGUIDlg::OnBnClickedButtonModreset()
{
	ULONG Status;

	int Selection = SelDeviceComboCtrl.GetCurSel();
	if(Selection < 0)
	{
		AfxMessageBox(L"Please Select the device", MB_ICONERROR);
		return;
	}

	Status = MCAPModuleReset(DeviceDataInfo[Selection].DevicePath);
	if(Status)
	{
		ReadFPGARegisters();
	}

	return;
}

// This functions sends the full reset to the device
void CMCAPAPPGUIDlg::OnBnClickedButtonFullreset()
{
	ULONG Status;

	int Selection = SelDeviceComboCtrl.GetCurSel();
	if(Selection < 0)
	{
		AfxMessageBox(L"Please Select the device", MB_ICONERROR);
		return;
	}

	Status = MCAPFullReset(DeviceDataInfo[Selection].DevicePath);
	if(Status)
	{
		ReadFPGARegisters();
	}

	return;
}

// This function will enable the log.
void CMCAPAPPGUIDlg::OnBnClickedCheckGenlog()
{
	IsLogEnabled = ((CButton*)GetDlgItem(IDC_CHECK_GENLOG))->GetCheck();
}

// This function reads the PCI Config Data from the specified register
void CMCAPAPPGUIDlg::OnBnClickedButtonPciconfigGet()
{
	CString szRegIndex, szRegValue, szLength;
	DWORD RegIndex = 0, RegValue = 0, RegLength = 0;
	ULONG Status = 0;
	PVOID pPciData = NULL;

	int Selection = SelDeviceComboCtrl.GetCurSel();
	if(Selection < 0)
	{
		AfxMessageBox(L"Please Select the device", MB_ICONERROR);
		return;
	}

	GetDlgItem(IDC_EDIT_PCICONFIG_OFFSET)->GetWindowTextW(szRegIndex);
	if(!szRegIndex.GetLength())
	{
		AfxMessageBox(L"Register Offset is Empty", MB_ICONERROR);
		return;
	}

	for(int i=0;i<szRegIndex.GetLength();i++)
	{
		if(!_istxdigit(szRegIndex.GetAt(i)))
		{
			CString Message = L" is not a Hex Value";
			AfxMessageBox(szRegIndex+Message, MB_ICONERROR);
			return;
		}
	}
	RegIndex = wcstoul(szRegIndex.GetBuffer(), NULL, 16);

	GetDlgItem(IDC_EDIT_PCICONFIG_LEN)->GetWindowTextW(szLength);
	if(!szLength.GetLength())
	{
		AfxMessageBox(L"Data Length is Empty", MB_ICONERROR);
		return;
	}

	for(int i=0;i<szLength.GetLength();i++)
	{
		if(!_istxdigit(szLength.GetAt(i)))
		{
			CString Message = L" is not a Hex Value";
			AfxMessageBox(szLength+Message, MB_ICONERROR);
			return;
		}
	}
	RegLength = wcstoul(szLength.GetBuffer(), NULL, 16);

	if(!RegLength)
	{
		CString Message;
		Message.Format(L"Data Length cannot be ZERO(0)");
		AfxMessageBox(Message, MB_ICONERROR);
		return;
	}

	pPciData = malloc(RegLength);
	if(!pPciData)
	{
		CString Message;
		Message.Format(L"Unable to Allocate Memory for (0x%x)%d Bytes", RegLength, RegLength);
		AfxMessageBox(Message, MB_ICONERROR);
		return;
	}

	Status = ReadPCIConfigSpace(
				DeviceDataInfo[Selection].DevicePath,
				RegIndex, 
				RegLength,
				pPciData);

	PopulatePCIConfigRegs(DeviceDataInfo[Selection].DevicePath);
	GetDlgItem(IDC_EDIT_PCIINFO)->GetWindowTextW(szRegValue);

	if(!Status)
	{
		DWORD Counter = 0;
		PBYTE PByBuffer = (PBYTE)pPciData;

		szRegValue.AppendFormat(L"\r\n\r\n Offset  \t Value    ");
		for(Counter = 0; Counter < RegLength;Counter++)
		{
			if(!(Counter % 4))
			{
				szRegValue.AppendFormat(L"  ");
			}

			if(!(Counter % 8))
			{
				szRegValue.AppendFormat(L"\r\n %04x: ", RegIndex+Counter);
			}
			szRegValue.AppendFormat(L" %02x", *PByBuffer++);
		}
		szRegValue.AppendFormat(L"\r\n");
	}
	else
	{
		szRegValue.AppendFormat(L"INVALID DATA");
		ReadFPGARegisters();
	}

	if(pPciData)
	{
		free(pPciData);
	}

	GetDlgItem(IDC_EDIT_PCIINFO)->SetWindowTextW(szRegValue);
}

// This function writes the PCI Config Data to the specified register
void CMCAPAPPGUIDlg::OnBnClickedButtonPciconfigSet()
{
	CString szRegIndex, szRegValue;
	DWORD RegIndex = 0, RegValue = 0;
	ULONG Status;

	int Selection = SelDeviceComboCtrl.GetCurSel();
	if(Selection < 0)
	{
		AfxMessageBox(L"Please Select the device", MB_ICONERROR);
		return;
	}

	GetDlgItem(IDC_EDIT_PCICONFIG_OFFSET)->GetWindowTextW(szRegIndex);
	if(!szRegIndex.GetLength())
	{
		AfxMessageBox(L"Register Offset is Empty", MB_ICONERROR);
		return;
	}

	for(int i=0;i<szRegIndex.GetLength();i++)
	{
		if(!_istxdigit(szRegIndex.GetAt(i)))
		{
			CString Message = L" is not a Hex Value";
			AfxMessageBox(szRegIndex+Message, MB_ICONERROR);
			return;
		}
	}
	RegIndex = wcstoul(szRegIndex.GetBuffer(), NULL, 16);

	GetDlgItem(IDC_EDIT_PCICONFIG_VALUE)->GetWindowTextW(szRegValue);
	if(!szRegValue.GetLength())
	{
		AfxMessageBox(L"Register Value is Empty", MB_ICONERROR);
		return;
	}

	for(int i=0;i<szRegValue.GetLength();i++)
	{
		if(!_istxdigit(szRegValue.GetAt(i)))
		{
			CString Message = L" is not a Hex Value";
			AfxMessageBox(szRegValue+Message, MB_ICONERROR);
			return;
		}
	}
	RegValue = wcstoul(szRegValue.GetBuffer(), NULL, 16);

	Status = WritePCIConfigSpace(
				DeviceDataInfo[Selection].DevicePath,
				RegIndex, 
				sizeof(BYTE),
				&RegValue);
	if(Status)
	{
		ReadFPGARegisters();
	}

	PopulatePCIConfigRegs(DeviceDataInfo[Selection].DevicePath);
}

void CMCAPAPPGUIDlg::OnBnClickedButtonReadfpga()
{
	ReadFPGARegisters();
}

void CMCAPAPPGUIDlg::openDialog(){
	cDlg = new CConfigStatusDialog(this);
	/*EnableWindow(FALSE);
	cDlg->Create(CConfigStatusDialog::IDD, this);
	EnableWindow(TRUE);
	cDlg->ShowWindow(SW_SHOW);*/
	cDlg->DoModal();
	return;
}

void CMCAPAPPGUIDlg::closeDialog(){
	cDlg->DestroyWindow();
}


void CMCAPAPPGUIDlg::ReadFPGARegisters(void)
{
	ULONG Status = 0;
	DWORD RegIndex = 0;
	DWORD RegValue = 0;
	CString szRegIndex;
	CString szRegValue;
	CString FPGAInfo;

	CString array[32] = {
		_T("CRC"), //0
		_T("FAR"), //1
		_T("FDRI"),//2 
		_T("FDRO"),//3
		_T("CMD"),//4
		_T("CTL0"),//5
		_T("MASK"),//6
		_T("STAT"),//7
		_T("LOUT"),//8
		_T("COR0"),//9
		_T("MFWR"),//10
		_T("CBC"),//11
		_T("IDCODE"),//12
		_T("AXSS"),//13
		_T("COR1"),//14
		_T(""), //15
		_T("WBSTAR"), //16
		_T("TIMER"), //17
		_T(""), //18
		_T(""), //19
		_T(""), //20
		_T(""), //21
		_T("BOOTSTS"), //22
		_T(""), //23
		_T("CTL1"), //24
		_T(""), //25
		_T(""), //26
		_T(""), //27
		_T(""), //28
		_T(""), //29
		_T(""), //30
		_T("BSPI") //31
	};
	

	int Selection = SelDeviceComboCtrl.GetCurSel();
	if(Selection < 0)
	{
		AfxMessageBox(L"Please Select the device", MB_ICONERROR);
		return;
	}

	/*GetDlgItem(IDC_EDIT_REAADFPGA_OFFSET)->GetWindowTextW(szRegIndex);
	if(szRegIndex.GetLength())
	{
		for(int i=0;i<szRegIndex.GetLength();i++)
		{
			if(!_istxdigit(szRegIndex.GetAt(i)))
			{
				CString Message = L" is not a Hex Value";
				AfxMessageBox(szRegIndex+Message, MB_ICONERROR);
				return;
			}
		}
		RegIndex = wcstoul(szRegIndex.GetBuffer(), NULL, 16);

		Status = ReadFPGAReg(DeviceDataInfo[Selection].DevicePath, RegIndex, &RegValue);
		if(!Status)
		{
			szRegValue.Format(L"\r\n %02x:%08x", RegIndex, RegValue);
			FPGAInfo+=szRegValue;
		}
		else
		{
			szRegValue.Format(L"\r\n %02x:INV DATA", RegIndex);
			FPGAInfo+=szRegValue;
		}
	}*/
	
	// According to UG570 documentation the register numbers are from 0-14, 16, 17, 22, 24, 31
	for(RegIndex = 0; RegIndex < 15;RegIndex++)
	{
		Status = ReadFPGAReg(DeviceDataInfo[Selection].DevicePath, RegIndex, &RegValue);
		if(!Status)
		{
			/*if(!(RegIndex%2))
			{
				szRegValue.Format(L"\r\n %s:\t%08x", array[RegIndex], RegValue);
			}
			else
			{
				szRegValue.Format(L" %s:\t%08x", array[RegIndex], RegValue);
			}*/
			szRegValue.Format(L"%s:\t%08x \r\n", array[RegIndex], RegValue);
			FPGAInfo+=szRegValue;
		}
		else
		{
			szRegValue.Format(L"\r\n %02x: INV DATA", RegIndex);
			FPGAInfo+=szRegValue;
		}
	}

	Status = ReadFPGAReg(DeviceDataInfo[Selection].DevicePath, 16, &RegValue);
	if (!Status){
		szRegValue.Format(L"%s:\t%08x \r\n", array[16], RegValue);
		FPGAInfo+=szRegValue;
	}
	else{
		szRegValue.Format(L"\r\n %02x: INV DATA", 16);
		FPGAInfo+=szRegValue;
	}

	Status = ReadFPGAReg(DeviceDataInfo[Selection].DevicePath, 17, &RegValue);
	if (!Status){
		szRegValue.Format(L"%s:\t%08x \r\n", array[17], RegValue);
		FPGAInfo+=szRegValue;
	}
	else{
		szRegValue.Format(L"\r\n %02x: INV DATA", 17);
		FPGAInfo+=szRegValue;
	}

	Status = ReadFPGAReg(DeviceDataInfo[Selection].DevicePath, 22, &RegValue);
	if (!Status){
		szRegValue.Format(L"%s:\t%08x \r\n", array[22], RegValue);
		FPGAInfo+=szRegValue;
	}
	else{
		szRegValue.Format(L"\r\n %02x: INV DATA", 22);
		FPGAInfo+=szRegValue;
	}
	
	Status = ReadFPGAReg(DeviceDataInfo[Selection].DevicePath, 24, &RegValue);
	if (!Status){
		szRegValue.Format(L"%s:\t%08x \r\n", array[24], RegValue);
		FPGAInfo+=szRegValue;
	}
	else{
		szRegValue.Format(L"\r\n %02x: INV DATA", 24);
		FPGAInfo+=szRegValue;
	}

	Status = ReadFPGAReg(DeviceDataInfo[Selection].DevicePath, 31, &RegValue);
	if (!Status){
		szRegValue.Format(L"%s:\t%08x \r\n", array[31], RegValue);
		FPGAInfo+=szRegValue;
	}
	else{
		szRegValue.Format(L"\r\n %02x: INV DATA", 31);
		FPGAInfo+=szRegValue;
	}	

	GetDlgItem(IDC_EDIT_FPGAINFO)->SetWindowTextW(FPGAInfo);
}

//void CMCAPAPPGUIDlg::OnBnClickedButtonIobarGet()
//{
//	CString szRegIndex, szRegValue;
//	DWORD RegIndex = 0, RegValue = 0;
//	ULONG Status = 0;
//
//	int Selection = SelDeviceComboCtrl.GetCurSel();
//	if(Selection < 0)
//	{
//		AfxMessageBox(L"Please Select the device", MB_ICONERROR);
//		return;
//	}
//
//	GetDlgItem(IDC_EDIT_IOBAR_OFFSET)->GetWindowTextW(szRegIndex);
//	if(!szRegIndex.GetLength())
//	{
//		AfxMessageBox(L"Register Offset is Empty", MB_ICONERROR);
//		return;
//	}
//
//	Status = ReadMCAPIOBARReg(
//				DeviceDataInfo[Selection].DevicePath,
//				RegIndex, 
//				&RegValue);
//
//	szRegValue.Format(L"%08x", RegValue);
//	GetDlgItem(IDC_EDIT_IOBAR_VAL)->SetWindowTextW(szRegValue);
//}

//void CMCAPAPPGUIDlg::OnBnClickedButtonIobarSet()
//{
//	CString szRegIndex, szRegValue;
//	DWORD RegIndex = 0, RegValue = 0;
//	ULONG Status;
//
//	int Selection = SelDeviceComboCtrl.GetCurSel();
//	if(Selection < 0)
//	{
//		AfxMessageBox(L"Please Select the device", MB_ICONERROR);
//		return;
//	}
//
//	GetDlgItem(IDC_EDIT_IOBAR_OFFSET)->GetWindowTextW(szRegIndex);
//	if(!szRegIndex.GetLength())
//	{
//		AfxMessageBox(L"Register Offset is Empty", MB_ICONERROR);
//		return;
//	}
//
//	for(int i=0;i<szRegIndex.GetLength();i++)
//	{
//		if(!_istxdigit(szRegIndex.GetAt(i)))
//		{
//			CString Message = L" is not a Hex Value";
//			AfxMessageBox(szRegIndex+Message, MB_ICONERROR);
//			return;
//		}
//	}
//	RegIndex = wcstoul(szRegIndex.GetBuffer(), NULL, 16);
//
//	GetDlgItem(IDC_EDIT_IOBAR_VAL)->GetWindowTextW(szRegValue);
//	if(!szRegValue.GetLength())
//	{
//		AfxMessageBox(L"Register Value is Empty", MB_ICONERROR);
//		return;
//	}
//
//	for(int i=0;i<szRegValue.GetLength();i++)
//	{
//		if(!_istxdigit(szRegValue.GetAt(i)))
//		{
//			CString Message = L" is not a Hex Value";
//			AfxMessageBox(szRegValue+Message, MB_ICONERROR);
//			return;
//		}
//	}
//	RegValue = wcstoul(szRegValue.GetBuffer(), NULL, 16);
//
//	Status = WriteMCAPIOBARReg(
//				DeviceDataInfo[Selection].DevicePath,
//				RegIndex, 
//				RegValue);
//}

//void CMCAPAPPGUIDlg::OnBnClickedButtonMembarGet()
//{
//	CString szRegIndex, szRegValue;
//	DWORD RegIndex = 0, RegValue = 0;
//	ULONG Status = 0;
//
//	int Selection = SelDeviceComboCtrl.GetCurSel();
//	if(Selection < 0)
//	{
//		AfxMessageBox(L"Please Select the device", MB_ICONERROR);
//		return;
//	}
//
//	GetDlgItem(IDC_EDIT_MEMBAR_OFFSET)->GetWindowTextW(szRegIndex);
//	if(!szRegIndex.GetLength())
//	{
//		AfxMessageBox(L"Register Offset is Empty", MB_ICONERROR);
//		return;
//	}
//
//	Status = ReadMCAPMEMBARReg(
//				DeviceDataInfo[Selection].DevicePath,
//				RegIndex, 
//				&RegValue);
//
//	szRegValue.Format(L"%08x", RegValue);
//	GetDlgItem(IDC_EDIT_MEMBAR_VAL)->SetWindowTextW(szRegValue);
//}

//void CMCAPAPPGUIDlg::OnBnClickedButtonMembarSet()
//{
//{
//	CString szRegIndex, szRegValue;
//	DWORD RegIndex = 0, RegValue = 0;
//	ULONG Status;
//
//	int Selection = SelDeviceComboCtrl.GetCurSel();
//	if(Selection < 0)
//	{
//		AfxMessageBox(L"Please Select the device", MB_ICONERROR);
//		return;
//	}
//
//	GetDlgItem(IDC_EDIT_MEMBAR_OFFSET)->GetWindowTextW(szRegIndex);
//	if(!szRegIndex.GetLength())
//	{
//		AfxMessageBox(L"Register Offset is Empty", MB_ICONERROR);
//		return;
//	}
//
//	for(int i=0;i<szRegIndex.GetLength();i++)
//	{
//		if(!_istxdigit(szRegIndex.GetAt(i)))
//		{
//			CString Message = L" is not a Hex Value";
//			AfxMessageBox(szRegIndex+Message, MB_ICONERROR);
//			return;
//		}
//	}
//	RegIndex = wcstoul(szRegIndex.GetBuffer(), NULL, 16);
//
//	GetDlgItem(IDC_EDIT_MEMBAR_VAL)->GetWindowTextW(szRegValue);
//	if(!szRegValue.GetLength())
//	{
//		AfxMessageBox(L"Register Value is Empty", MB_ICONERROR);
//		return;
//	}
//
//	for(int i=0;i<szRegValue.GetLength();i++)
//	{
//		if(!_istxdigit(szRegValue.GetAt(i)))
//		{
//			CString Message = L" is not a Hex Value";
//			AfxMessageBox(szRegValue+Message, MB_ICONERROR);
//			return;
//		}
//	}
//	RegValue = wcstoul(szRegValue.GetBuffer(), NULL, 16);
//
//	Status = WriteMCAPMEMBARReg(
//				DeviceDataInfo[Selection].DevicePath,
//				RegIndex, 
//				RegValue);
//}}


void CMCAPAPPGUIDlg::OnBnClickedRadioPcie()
{
	// TODO: Add your control notification handler code here
	CButton * pButton = ((CButton *)GetDlgItem(IDC_RADIO_PCIE));
	if (pButton->GetCheck() == BST_CHECKED){
		//disable clear select file
		GetDlgItem(IDC_EDIT_CLEARSTREAMFILE)->EnableWindow(false);
		GetDlgItem(IDC_BUTTON_CLEARSELFILE)->EnableWindow(false);
		((CButton *)GetDlgItem(IDC_RADIO_FIELDSET))->SetCheck(false);
	}
	else{
		((CButton *)GetDlgItem(IDC_RADIO_FIELDSET))->SetCheck(true);
	}
}


void CMCAPAPPGUIDlg::OnBnClickedRadioFieldset()
{
	// TODO: Add your control notification handler code here
	CButton * pButton = ((CButton *)GetDlgItem(IDC_RADIO_FIELDSET));
	if (pButton->GetCheck() == BST_CHECKED){
		((CButton *)GetDlgItem(IDC_RADIO_PCIE))->SetCheck(false);
		//enable clear select file
		GetDlgItem(IDC_EDIT_CLEARSTREAMFILE)->EnableWindow(true);
		GetDlgItem(IDC_BUTTON_CLEARSELFILE)->EnableWindow(true);
	}
	else{
		((CButton *)GetDlgItem(IDC_RADIO_PCIE))->SetCheck(true);
	}
}


void CMCAPAPPGUIDlg::OnBnClickedButtonClearselfile()
{
	// TODO: Add your control notification handler code here
	TCHAR szFilters[] = _T("BitStream Files (*.bin;*bit;*.rbt)|*.bin;*bit;*.rbt|All Files (*.*)|*.*|");

	CFileDialog FileDialog(TRUE, // Open File Dialog
		_T("bin"), // File Extension
		NULL, // Initial File Name
		OFN_FILEMUSTEXIST, // Flags
		szFilters, // Filters
		this, // Parent
		0, // Size
		TRUE); // Vista

	if (FileDialog.DoModal() == IDOK)
	{
		// Selected a File
		CString FullFolderPath;

		FullFolderPath = FileDialog.GetPathName();
		GetDlgItem(IDC_EDIT_CLEARSTREAMFILE)->SetWindowTextW(FullFolderPath);
	}
}
