
// DlgProxy.cpp : implementation file
//

#include "stdafx.h"
#include "MCAPAPPGUI.h"
#include "DlgProxy.h"
#include "MCAPAPPGUIDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMCAPAPPGUIDlgAutoProxy

IMPLEMENT_DYNCREATE(CMCAPAPPGUIDlgAutoProxy, CCmdTarget)

CMCAPAPPGUIDlgAutoProxy::CMCAPAPPGUIDlgAutoProxy()
{
	EnableAutomation();
	
	// To keep the application running as long as an automation 
	//	object is active, the constructor calls AfxOleLockApp.
	AfxOleLockApp();

	// Get access to the dialog through the application's
	//  main window pointer.  Set the proxy's internal pointer
	//  to point to the dialog, and set the dialog's back pointer to
	//  this proxy.
	ASSERT_VALID(AfxGetApp()->m_pMainWnd);
	if (AfxGetApp()->m_pMainWnd)
	{
		ASSERT_KINDOF(CMCAPAPPGUIDlg, AfxGetApp()->m_pMainWnd);
		if (AfxGetApp()->m_pMainWnd->IsKindOf(RUNTIME_CLASS(CMCAPAPPGUIDlg)))
		{
			m_pDialog = reinterpret_cast<CMCAPAPPGUIDlg*>(AfxGetApp()->m_pMainWnd);
			m_pDialog->m_pAutoProxy = this;
		}
	}
}

CMCAPAPPGUIDlgAutoProxy::~CMCAPAPPGUIDlgAutoProxy()
{
	// To terminate the application when all objects created with
	// 	with automation, the destructor calls AfxOleUnlockApp.
	//  Among other things, this will destroy the main dialog
	if (m_pDialog != NULL)
		m_pDialog->m_pAutoProxy = NULL;
	AfxOleUnlockApp();
}

void CMCAPAPPGUIDlgAutoProxy::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}

BEGIN_MESSAGE_MAP(CMCAPAPPGUIDlgAutoProxy, CCmdTarget)
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CMCAPAPPGUIDlgAutoProxy, CCmdTarget)
END_DISPATCH_MAP()

// Note: we add support for IID_IMCAPAPPGUI to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .IDL file.

// {ACEE1939-E898-4B8B-A973-471249917B40}
static const IID IID_IMCAPAPPGUI =
{ 0xACEE1939, 0xE898, 0x4B8B, { 0xA9, 0x73, 0x47, 0x12, 0x49, 0x91, 0x7B, 0x40 } };

BEGIN_INTERFACE_MAP(CMCAPAPPGUIDlgAutoProxy, CCmdTarget)
	INTERFACE_PART(CMCAPAPPGUIDlgAutoProxy, IID_IMCAPAPPGUI, Dispatch)
END_INTERFACE_MAP()

// The IMPLEMENT_OLECREATE2 macro is defined in StdAfx.h of this project
// {9722178B-4B64-47AF-88A6-ED1A7F4723D2}
IMPLEMENT_OLECREATE2(CMCAPAPPGUIDlgAutoProxy, "MCAPAPPGUI.Application", 0x9722178b, 0x4b64, 0x47af, 0x88, 0xa6, 0xed, 0x1a, 0x7f, 0x47, 0x23, 0xd2)


// CMCAPAPPGUIDlgAutoProxy message handlers
