//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MCAPAPPGUI.rc
//
#define IDP_OLE_INIT_FAILED             100
#define IDD_MCAPAPPGUI_DIALOG           101
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     132
#define IDD_STATUS_DIALOG               132
#define IDC_COMBO_DEVSEL                1000
#define IDC_EDIT_MCAP_PECH              1028
#define IDC_EDIT_MCAP_VSH               1029
#define IDC_EDIT_MCAP_JTI               1030
#define IDC_EDIT_MCAP_FBSV              1031
#define IDC_EDIT_MCAP_STATUS            1032
#define IDC_EDIT_MCAP_CTRL              1033
#define IDC_EDIT_MCAP_DATAREG           1034
#define IDC_EDIT_MCAP_RDR1              1035
#define IDC_EDIT_MCAP_RDR2              1036
#define IDC_EDIT_MCAP_RDR3              1037
#define IDC_EDIT_MCAP_RDR4              1038
#define IDC_BUTTON_REFRESH              1039
#define IDC_BUTTON_APPLY                1040
#define IDC_BUTTON_SELFILE              1041
#define IDC_BUTTON_PROGBIN              1042
#define IDC_EDIT_BITSTREAMFILE          1043
#define IDC_BUTTON_RESET                1044
#define IDC_BUTTON_MODRESET             1045
#define IDC_BUTTON_FULLRESET            1046
#define IDC_CHECK_GENLOG                1047
#define IDC_EDIT_PCICONFIG_OFFSET       1049
#define IDC_EDIT_PCICONFIG_VALUE        1050
#define IDC_BUTTON_PCICONFIG_SET        1051
#define IDC_BUTTON_PCICONFIG_GET        1052
#define IDC_BUTTON_READFPGA             1053
#define IDC_EDIT_REAADFPGA_OFFSET       1054
#define IDC_EDIT_READFPGA_VALUE         1055
#define IDC_EDIT_PCIINFO                1056
#define IDC_EDIT_FPGAINFO               1057
#define IDC_EDIT_PCICONFIG_LEN          1081
#define IDC_EDIT_IOBAR_OFFSET           1082
#define IDC_EDIT_IOBAR_VAL              1083
#define IDC_EDIT_MEMBAR_OFFSET          1084
#define IDC_EDIT_MEMBAR_VAL             1085
#define IDC_BUTTON_IOBAR_GET            1086
#define IDC_BUTTON_IOBAR_SET            1087
#define IDC_BUTTON_MEMBAR_GET           1088
#define IDC_BUTTON_MEMBAR_SET           1089
#define IDC_EDIT_CLEARSTREAMFILE        1089
#define IDC_BUTTON_CLEARSELFILE         1090
#define IDC_RADIO_PCIE                  1091
#define IDC_RADIO_FIELDSET              1092

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1093
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
