#pragma once


// CConfigStatusDialog dialog

class CConfigStatusDialog : public CDialog
{
	DECLARE_DYNAMIC(CConfigStatusDialog)

public:
	CConfigStatusDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CConfigStatusDialog();

// Dialog Data
	enum { IDD = IDD_STATUS_DIALOG };
	void PostNcDestroy();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	
	DECLARE_MESSAGE_MAP()
};
