
// MCAPAPPGUIDlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "ConfigStatusDialog.h"

#define UWM_THREAD_START (WM_USER + 100)
#define UWM_THREAD_STOP (WM_USER + 200)

class CMCAPAPPGUIDlgAutoProxy;

struct _DeviceDataInfo_{
	TCHAR DevicePath[MAX_PATH];
	TCHAR DeviceLocation[MAX_PATH];
	TCHAR DeviceName[MAX_PATH];
};

static UINT RunMyThread(void *);

// CMCAPAPPGUIDlg dialog
class CMCAPAPPGUIDlg : public CDialog
{
	DECLARE_DYNAMIC(CMCAPAPPGUIDlg);
	friend class CMCAPAPPGUIDlgAutoProxy;

// Construction
public:
	CMCAPAPPGUIDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CMCAPAPPGUIDlg();

// Dialog Data
	enum { IDD = IDD_MCAPAPPGUI_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

private:
	struct _DeviceDataInfo_ *DeviceDataInfo;

// Implementation
protected:
	CMCAPAPPGUIDlgAutoProxy* m_pAutoProxy;
	HICON m_hIcon;
	CConfigStatusDialog *cDlg;

	// Select Devices Combo Control Variable
	CComboBox SelDeviceComboCtrl;

	BOOL CanExit();

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	DECLARE_MESSAGE_MAP()
private:
	// Populates the MCAP Devices Available in the system
	int PopulateMCAPDevices();

	// Populates the PCI Config Registers for the Given Device
	void PopulatePCIConfigRegs(PTCHAR DevicePath);

	// This will populate the MCAP Register of the given Device
	void PopulateMCAPRegs(PTCHAR DevicePath);

public:
	afx_msg void OnBnClickedButtonRefresh();
	afx_msg void OnCbnSelchangeComboDevsel();
	afx_msg void OnBnClickedButtonSelfile();
	afx_msg void OnBnClickedButtonProgbin();
	afx_msg void OnBnClickedButtonApply();
	afx_msg void OnBnClickedButtonReset();
	afx_msg void OnBnClickedButtonModreset();
	afx_msg void OnBnClickedButtonFullreset();
	afx_msg void OnBnClickedCheckGenlog();
	afx_msg void OnBnClickedButtonPciconfigGet();
	afx_msg void OnBnClickedButtonPciconfigSet();
public:
	afx_msg void OnBnClickedButtonReadfpga();
	afx_msg void OnBnClickedRadioPciset();
	afx_msg void OnBnClickedRadioPciget();
	void openDialog();
	void closeDialog();
	void ReadFPGARegisters(void);
	ULONG ProgramBin();
//	afx_msg void OnBnClickedButtonIobarGet();
//	afx_msg void OnBnClickedButtonIobarSet();
//	afx_msg void OnBnClickedButtonMembarGet();
//	afx_msg void OnBnClickedButtonMembarSet();
	afx_msg void OnBnClickedRadioPcie();
	afx_msg void OnBnClickedRadioFieldset();
	afx_msg void OnBnClickedButtonClearselfile();
};
