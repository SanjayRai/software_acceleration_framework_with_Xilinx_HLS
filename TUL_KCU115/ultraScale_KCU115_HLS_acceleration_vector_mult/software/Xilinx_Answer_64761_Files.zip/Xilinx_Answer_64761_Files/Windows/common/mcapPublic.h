/********************************************************************
*Copyright (C) 2014 � 2015 Xilinx, Inc.  All rights reserved.
*
*Permission is hereby granted, free of charge, to any person obtaining
*a copy of this software and associated documentation files (the
*"Software"), to deal in the Software without restriction, including
*without limitation the rights to use, copy, modify, merge, publish,
*distribute, sublicense, and/or sell copies of the Software, and to
*permit persons to whom the Software is furnished to do so, subject to
*the following conditions:
*
*The above copyright notice and this permission notice shall be 
*included in all copies or substantial portions of the Software.
*
*Use of the Software is limited solely to applications: (a) running 
*on a Xilinx device, or (b) that interact with a Xilinx device 
*through a bus or interconnect.  
*
*THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*NONINFRINGEMENT. IN NO EVENT SHALL XILINX BE LIABLE FOR ANY CLAIM, 
*DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
*OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
*OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*Except as contained in this notice, the name of the Xilinx shall
*not be used in advertising or otherwise to promote the sale, use or
*other dealings in this Software without prior written authorization
*from Xilinx.
*********************************************************************/
/*++
Module Name:

    mcapPublic.h

Abstract:

    This module contains the common declarations shared by driver
    and user applications.

Environment:

    user and kernel

--*/

#ifndef _MCAPPUBLIC_H_
#define _MCAPPUBLIC_H_

//
// {67DCB6A5-3649-4777-9CEC-A254EF1CE080}
DEFINE_GUID(GUID_MCAP_INTERFACE, 
   0x67dcb6a5, 0x3649, 0x4777, 0x9c, 0xec, 0xa2, 0x54, 0xef, 0x1c, 0xe0, 0x80);

//
//
#define FILEIO_TYPE FILE_DEVICE_UNKNOWN
//
// The IOCTL function codes from 0x800 to 0xFFF are for customer use.
//
#define FUNCTION_CODE	0x800 

#define IOCTL_READ_PCI_CONFIG_REG \
    CTL_CODE( FILEIO_TYPE, FUNCTION_CODE+0, METHOD_BUFFERED, FILE_ANY_ACCESS  )

#define IOCTL_WRITE_PCI_CONFIG_REG \
    CTL_CODE( FILEIO_TYPE, FUNCTION_CODE+1, METHOD_BUFFERED, FILE_ANY_ACCESS  )

#define IOCTL_READ_MCAP_REG \
    CTL_CODE( FILEIO_TYPE, FUNCTION_CODE+2, METHOD_BUFFERED, FILE_ANY_ACCESS  )

#define IOCTL_WRITE_MCAP_REG \
    CTL_CODE( FILEIO_TYPE, FUNCTION_CODE+3, METHOD_BUFFERED, FILE_ANY_ACCESS  )

#define IOCTL_WRITE_CONTROL_REG \
    CTL_CODE( FILEIO_TYPE, FUNCTION_CODE+4, METHOD_BUFFERED, FILE_ANY_ACCESS  )

#define IOCTL_READ_CONTROL_REG \
    CTL_CODE( FILEIO_TYPE, FUNCTION_CODE+5, METHOD_BUFFERED, FILE_ANY_ACCESS  )

#define IOCTL_READ_STATUS_REG \
    CTL_CODE( FILEIO_TYPE, FUNCTION_CODE+6, METHOD_BUFFERED, FILE_ANY_ACCESS  )

#define IOCTL_MCAP_RESET \
    CTL_CODE( FILEIO_TYPE, FUNCTION_CODE+7, METHOD_BUFFERED, FILE_ANY_ACCESS  )

#define IOCTL_MCAP_MODULE_RESET \
    CTL_CODE( FILEIO_TYPE, FUNCTION_CODE+8, METHOD_BUFFERED, FILE_ANY_ACCESS  )

#define IOCTL_MCAP_FULL_RESET \
    CTL_CODE( FILEIO_TYPE, FUNCTION_CODE+9, METHOD_BUFFERED, FILE_ANY_ACCESS  )

#define IOCTL_READ_IOBAR_REG \
    CTL_CODE( FILEIO_TYPE, FUNCTION_CODE+10, METHOD_BUFFERED, FILE_ANY_ACCESS  )

#define IOCTL_WRITE_IOBAR_REG \
    CTL_CODE( FILEIO_TYPE, FUNCTION_CODE+11, METHOD_BUFFERED, FILE_ANY_ACCESS  )

#define IOCTL_READ_MEMBAR_REG \
    CTL_CODE( FILEIO_TYPE, FUNCTION_CODE+12, METHOD_BUFFERED, FILE_ANY_ACCESS  )

#define IOCTL_WRITE_MEMBAR_REG \
    CTL_CODE( FILEIO_TYPE, FUNCTION_CODE+13, METHOD_BUFFERED, FILE_ANY_ACCESS  )


typedef union _MCAP_IOCTL_REQ_RES_
{
	// Structures
	union
	{
		// No Input Buffer for IOCTL_MCAP_FULL_RESET

		// No Input Buffer for IOCTL_MCAP_MODULE_RESET

		// No Input Buffer for IOCTL_MCAP_RESET

		// No Input Buffer for IOCTL_READ_STATUS_REG

		// No Input Buffer for IOCTL_READ_CONTROL_REG

		// IOCTL_WRITE_CONTROL_REG
		struct
		{
			ULONG RegValue;
		}mcapwritectrlreg;

		// IOCTL_WRITE_MCAP_REG
		struct
		{
			ULONG RegIndex;
			ULONG RegValue;
		}mcapwritereg;

		// IOCTL_READ_MCAP_REG
		struct
		{
			ULONG RegIndex;
		}mcapreadreg;

		// IOCTL_WRITE_PCI_CONFIG_REG
		struct
		{
			ULONG RegIndex;
			ULONG Length;
			ULONG Buffer[0];
		}pciconfigwrite;

		// IOCTL_READ_PCI_CONFIG_REG
		struct
		{
			ULONG RegIndex;
			ULONG Length;
		}pciconfigread;

		// IOCTL_WRITE_IOBAR_REG
		struct
		{
			ULONG RegIndex;
			ULONG RegValue;
		}mcapwriteiobarreg;

		// IOCTL_READ_IOBAR_REG
		struct
		{
			ULONG RegIndex;
		}mcapreadiobarreg;

		// IOCTL_WRITE_MEMBAR_REG
		struct
		{
			ULONG RegIndex;
			ULONG RegValue;
		}mcapwritemembarreg;

		// IOCTL_READ_MEMBAR_REG
		struct
		{
			ULONG RegIndex;
		}mcapreadmembarreg;

	}mcapreq;

	union
	{
		// No Output Buffer for IOCTL_MCAP_FULL_RESET

		// No Output Buffer for IOCTL_MCAP_MODULE_RESET

		// No Output Buffer for IOCTL_MCAP_RESET

		// IOCTL_READ_STATUS_REG
		struct
		{
			ULONG RegValue;
		}mcapreadstatreg;

		// IOCTL_READ_CONTROL_REG
		struct
		{
			ULONG RegValue;
		}mcapreadctrlreg;

		// No Output Buffer for IOCTL_WRITE_CONTROL_REG

		// No Output Buffer for IOCTL_WRITE_MCAP_REG

		// IOCTL_READ_MCAP_REG
		struct
		{
			ULONG RegValue;
		}mcapreadreg;

		// No Output Buffer for IOCTL_WRITE_PCI_CONFIG_REG

		// IOCTL_READ_PCI_CONFIG_REG
		struct
		{
			ULONG RegIndex;
			ULONG Length;
			ULONG Buffer[0];
		}pciconfigread;

		// IOCTL_READ_IOBAR_REG
		struct
		{
			ULONG RegValue;
		}mcapreadiobarreg;

		// IOCTL_READ_MEMBAR_REG
		struct
		{
			ULONG RegValue;
		}mcapreadmembarreg;

	}mcapres;

}MCAP_IOCTL_REQ_RES, *PMCAP_IOCTL_REQ_RES;

#endif //_MCAPPUBLIC_H_