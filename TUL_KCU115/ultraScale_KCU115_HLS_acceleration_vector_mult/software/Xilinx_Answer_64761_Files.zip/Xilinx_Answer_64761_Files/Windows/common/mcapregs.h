/********************************************************************
*Copyright (C) 2014 � 2015 Xilinx, Inc.  All rights reserved.
*
*Permission is hereby granted, free of charge, to any person obtaining
*a copy of this software and associated documentation files (the
*"Software"), to deal in the Software without restriction, including
*without limitation the rights to use, copy, modify, merge, publish,
*distribute, sublicense, and/or sell copies of the Software, and to
*permit persons to whom the Software is furnished to do so, subject to
*the following conditions:
*
*The above copyright notice and this permission notice shall be 
*included in all copies or substantial portions of the Software.
*
*Use of the Software is limited solely to applications: (a) running 
*on a Xilinx device, or (b) that interact with a Xilinx device 
*through a bus or interconnect.  
*
*THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*NONINFRINGEMENT. IN NO EVENT SHALL XILINX BE LIABLE FOR ANY CLAIM, 
*DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT 
*OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
*OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*Except as contained in this notice, the name of the Xilinx shall
*not be used in advertising or otherwise to promote the sale, use or
*other dealings in this Software without prior written authorization
*from Xilinx.
*********************************************************************/
#ifndef _MCAPREGS_H_
#define _MCAPREGS_H_

//*****************************************************************************
//  
//  File Name: mcapregs.h
// 
//  Description:  This file defines all the MCAP Registers.
// 
//
//*****************************************************************************

//-----------------------------------------------------------------------------   
// PCI Device/Vendor Ids.
//-----------------------------------------------------------------------------   
#define MCAP_PCI_VENDOR_ID               0x10EE
#define MCAP_PCI_DEVICE_ID               0x506F

//-----------------------------------------------------------------------------   
// Define the PCIe Extended Capability Register (PECR)
//-----------------------------------------------------------------------------   
typedef struct _PEC_REG_BITS_ {
    unsigned long  PCIeExtendedCapabilityId    : 16;  //RD ONLY // bit 0-15
    unsigned long  CapabilityVersion           : 4;   //RD ONLY // bit 16-19
    unsigned long  NextCapabilityOffset        : 12;  //RD ONLY // bit 20-31

} PEC_REG_BITS;

typedef union _PEC_REG_ {
	PEC_REG_BITS bits;
	unsigned long regval;

}PEC_REG;

//-----------------------------------------------------------------------------   
// Define the Vendor Specific Header Register (VSHR)
//-----------------------------------------------------------------------------   
typedef struct _VSH_REG_BITS_ {
    unsigned long  VSECId                      : 16;  //RD ONLY // bit 0-15
    unsigned long  VSECRevision                : 4;   //RD ONLY // bit 16-19
    unsigned long  VSECLength                  : 12;  //RD ONLY // bit 20-31

} VSH_REG_BITS;

typedef union _VSH_REG_ {
	VSH_REG_BITS bits;
	unsigned long regval;

}VSH_REG;

//-----------------------------------------------------------------------------   
// Define the FPGA JTAG ID Register (FJIR)
//-----------------------------------------------------------------------------   
typedef struct _FJI_REG_BITS_ {
    unsigned long  FPGAJTAGId                  : 32;  //RD ONLY // bit 0-31

} FJI_REG_BITS;

typedef union _FJI_REG_ {
	FJI_REG_BITS bits;
	unsigned long regval;

}FJI_REG;

//-----------------------------------------------------------------------------   
// Define the FPGA Bit Stream Version Register (FBSVR)
//-----------------------------------------------------------------------------   
typedef struct _FBSV_REG_BITS_ {
    unsigned long  FPGAStreamVersion           : 32;  //RD ONLY // bit 0-31

} FBSV_REG_BITS;

typedef union _FBSV_REG_ {
	FBSV_REG_BITS bits;
	unsigned long regval;

}FBSV_REG;

//-----------------------------------------------------------------------------   
// Define the Status Register (STATR)
//-----------------------------------------------------------------------------   
typedef struct _STAT_REG_BITS_ {
    unsigned long  MCAPError                  : 1;  //RD ONLY // bit 0
	unsigned long  MCAPEOS                    : 1;  //RD ONLY // bit 1
    unsigned long  RSVD1                      : 2;  //RD ONLY // bit 2-3
    unsigned long  MCAPRegReadComplete        : 1;  //RD ONLY // bit 4
    unsigned long  MCAPRegReadCount           : 3;  //RD ONLY // bit 5-7
    unsigned long  MCAPWriteFifoOverflow      : 1;  //RD ONLY // bit 8
    unsigned long  RSVD2                      : 3;  //RD ONLY // bit 9-11
    unsigned long  MCAPWriteFifoOccupancy     : 4;  //RD ONLY // bit 12-15
    unsigned long  RSVD3                      : 8;  //RD ONLY // bit 16-23
    unsigned long  CfgMCAPRequestByCfg        : 1;  //RD ONLY // bit 24
    unsigned long  RSVD4                      : 7;  //RD ONLY // bit 25-31

} STAT_REG_BITS;

typedef union _STAT_REG_ {
	STAT_REG_BITS bits;
	unsigned long regval;

}STAT_REG;

//-----------------------------------------------------------------------------   
// Define the Control Register (CTRLR)
//-----------------------------------------------------------------------------   
typedef struct _CTRL_REG_BITS_ {
    unsigned long  MCAPMode                  : 1;  //RD-WR // bit 0
	unsigned long  MCAPRegisterRead          : 1;  //RD-WR // bit 1
    unsigned long  RSVD1                     : 2;  //RD ONLY // bit 2-3
    unsigned long  MCAPReset                 : 1;  //RD-WR // bit 4
	unsigned long  MCAPModuleReset           : 1;  //RD-WR // bit 5
    unsigned long  RSVD2                     : 2;  //RD ONLY // bit 6-7
	unsigned long  CfgMCAPInUseByPCIe        : 1;  //RD-WR // bit 8
    unsigned long  RSVD3                     : 3;  //RD ONLY // bit 9-11
	unsigned long  CfgMCAPDesignSwitch       : 1;  //RD-WR // bit 12
    unsigned long  RSVD4                     : 3;  //RD ONLY // bit 13-15
	unsigned long  DataRegisterProtect       : 1;  //RD-WR // bit 16
	unsigned long  RSVD5                     : 15; //RD ONLY // bit 17-31

} CTRL_REG_BITS;

typedef union _CTRL_REG_ {
	CTRL_REG_BITS bits;
	unsigned long regval;

}CTRL_REG;

//-----------------------------------------------------------------------------   
// Define the Data Register (DATAR)
//-----------------------------------------------------------------------------   
typedef struct _DATA_REG_BITS_ {
    unsigned long  MCAPDataRegister          : 32;  //RD-WR // bit 0-31

} DATA_REG_BITS;

typedef union _DATA_REG_ {
	DATA_REG_BITS bits;
	unsigned long regval;

}DATA_REG;

//-----------------------------------------------------------------------------   
// Define the Register Read Register (REGRDR)
//-----------------------------------------------------------------------------   
typedef struct _REGRD_REG_BITS_ {
    unsigned long  MCAPRegisterReadData      : 32;  //RD ONLY // bit 0-31

} REGRD_REG_BITS;

typedef union _REGRD_REG_ {
	REGRD_REG_BITS bits;
	unsigned long regval;

}REGRD_REG;


#pragma warning(default:4214) 
//-----------------------------------------------------------------------------   
// MCAP_REGS structure
//-----------------------------------------------------------------------------   
#define MCAP_REGISTERS_COUNT			 11 // 11 Registers
#define MCAP_REGISTER_SIZE				 04 // 4 Bytes

typedef struct _MCAP_REGISTERS_ {

    PEC_REG           PECRegister       ;  // 0x000		//RD ONLY
    VSH_REG           VSHRegister       ;  // 0x004		//RD ONLY
    FJI_REG           FJIRegister       ;  // 0x008		//RD ONLY
    FBSV_REG          FBSVRegister      ;  // 0x00C		//RD ONLY
    STAT_REG          STATRegister      ;  // 0x010		//RD ONLY
    CTRL_REG          CTRLRegister      ;  // 0x014		//RD-WR
    DATA_REG          DATARegister      ;  // 0x018		//RD-WR
    REGRD_REG         REGRDRegister1    ;  // 0x01C		//RD ONLY
    REGRD_REG         REGRDRegister2    ;  // 0x020		//RD ONLY
    REGRD_REG         REGRDRegister3    ;  // 0x024		//RD ONLY
	REGRD_REG         REGRDRegister4    ;  // 0x028		//RD ONLY

} MCAP_REGISTERS, *PMCAP_REGISTERS; 

typedef union _MCAP_REGS_ {
	MCAP_REGISTERS mcapregs;
	unsigned long mcapregvals[MCAP_REGISTERS_COUNT];

}MCAP_REGS, *PMCAP_REGS;

#define PEC_REG_OFFSET           FIELD_OFFSET(MCAP_REGISTERS,  PECRegister)		//  0, 0x000
#define VSH_REG_OFFSET           FIELD_OFFSET(MCAP_REGISTERS,  VSHRegister)		//  4, 0x004
#define FJI_REG_OFFSET           FIELD_OFFSET(MCAP_REGISTERS,  FJIRegister)		//  8, 0x008
#define FBSV_REG_OFFSET          FIELD_OFFSET(MCAP_REGISTERS,  FBSVRegister)	// 12, 0x00C
#define STAT_REG_OFFSET          FIELD_OFFSET(MCAP_REGISTERS,  STATRegister)	// 16, 0x010
#define CTRL_REG_OFFSET          FIELD_OFFSET(MCAP_REGISTERS,  CTRLRegister)	// 20, 0x014
#define DATA_REG_OFFSET          FIELD_OFFSET(MCAP_REGISTERS,  DATARegister)	// 24, 0x018
#define REGRD1_REG_OFFSET        FIELD_OFFSET(MCAP_REGISTERS,  REGRDRegister1)	// 28, 0x01C
#define REGRD2_REG_OFFSET        FIELD_OFFSET(MCAP_REGISTERS,  REGRDRegister2)	// 32, 0x020
#define REGRD3_REG_OFFSET        FIELD_OFFSET(MCAP_REGISTERS,  REGRDRegister3)	// 36, 0x024
#define REGRD4_REG_OFFSET        FIELD_OFFSET(MCAP_REGISTERS,  REGRDRegister4)	// 40, 0x028

#define PEC_REG_INDEX           (PEC_REG_OFFSET/MCAP_REGISTER_SIZE)      // 0x000 
#define VSH_REG_INDEX           (VSH_REG_OFFSET/MCAP_REGISTER_SIZE)      // 0x004 
#define FJI_REG_INDEX           (FJI_REG_OFFSET/MCAP_REGISTER_SIZE)      // 0x008 
#define FBSV_REG_INDEX          (FBSV_REG_OFFSET/MCAP_REGISTER_SIZE)     // 0x00C 
#define STAT_REG_INDEX          (STAT_REG_OFFSET/MCAP_REGISTER_SIZE)     // 0x010 
#define CTRL_REG_INDEX          (CTRL_REG_OFFSET/MCAP_REGISTER_SIZE)     // 0x014 
#define DATA_REG_INDEX          (DATA_REG_OFFSET/MCAP_REGISTER_SIZE)     // 0x018 
#define REGRD1_REG_INDEX        (REGRD1_REG_OFFSET/MCAP_REGISTER_SIZE)   // 0x01C 
#define REGRD2_REG_INDEX        (REGRD2_REG_OFFSET/MCAP_REGISTER_SIZE)   // 0x020 
#define REGRD3_REG_INDEX        (REGRD3_REG_OFFSET/MCAP_REGISTER_SIZE)   // 0x024 
#define REGRD4_REG_INDEX        (REGRD4_REG_OFFSET/MCAP_REGISTER_SIZE)   // 0x028 

#endif  // _MCAPREGS_H_
